import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, Receipt, AlertTriangle, Wallet, CreditCard,
  Settings, LogOut, Shield,
  Users, Bell, Download, Smartphone, Globe, FileText, Menu, X,
  PlusCircle, CreditCard as DepositIcon, TrendingUp, Lock,
  Play, Pause, Percent
} from "lucide-react";
import { usePlatformStore } from "@/context/PlatformStore";

interface MenuItem {
  name: string;
  href: string;
  icon: React.ElementType;
  badge?: string;
}

const menuItems: MenuItem[] = [
  { name: "Главная", href: "/dashboard", icon: LayoutDashboard },
  { name: "Ордеры", href: "/orders", icon: Receipt },
  { name: "Апелляции", href: "/disputes", icon: AlertTriangle },
  { name: "Баланс", href: "/wallet", icon: Wallet },
  { name: "Реквизиты", href: "/cards", icon: CreditCard },
  { name: "Методы оплаты", href: "/payment-methods", icon: PlusCircle },
  { name: "Уведомления", href: "/notifications", icon: Bell },
  { name: "Терминалы", href: "/terminals", icon: Smartphone },
  { name: "Устройства", href: "/devices", icon: Users },
  { name: "Скачать APK", href: "/download-apk", icon: Download },
  { name: "Безопасность", href: "/security", icon: Shield },
  { name: "Логи аудита", href: "/logs", icon: FileText },
  { name: "Отчёты", href: "/reports", icon: Globe },
];

const bottomNavItems: MenuItem[] = [
  { name: "Главная", href: "/dashboard", icon: LayoutDashboard },
  { name: "Ордеры", href: "/orders", icon: Receipt },
  { name: "Баланс", href: "/wallet", icon: Wallet },
  { name: "Реквизиты", href: "/cards", icon: CreditCard },
];

const SECURITY_DEPOSIT_RUB = 85000;
const USDT_TO_RUB = 85;

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [totalBalance, setTotalBalance] = useState<number | null>(null);
  const [trafficEnabled, setTrafficEnabled] = useState(false);
  const [trafficLoading, setTrafficLoading] = useState(false);
  const [sessionToken, setSessionToken] = useState<string | null>(null);

  const { activeCardCount } = usePlatformStore();

  useEffect(() => {
    const token = localStorage.getItem("sessionToken");
    if (token) setSessionToken(token);
  }, []);

  useEffect(() => {
    if (!sessionToken) return;
    const fetchBalance = async () => {
      try {
        const res = await fetch("/api/balance", {
          headers: { "x-session-token": sessionToken }
        });
        const data = await res.json();
        setTotalBalance(data.total);
      } catch (err) {
        console.error(err);
      }
    };
    const fetchTrafficStatus = async () => {
      try {
        const res = await fetch("/api/traffic/status", {
          headers: { "x-session-token": sessionToken }
        });
        const data = await res.json();
        setTrafficEnabled(data.enabled);
      } catch (err) {
        console.error(err);
      }
    };
    fetchBalance();
    fetchTrafficStatus();
    const interval = setInterval(() => {
      fetchBalance();
      fetchTrafficStatus();
    }, 15000);
    return () => clearInterval(interval);
  }, [sessionToken]);

  const toggleTraffic = async () => {
    if (!sessionToken) return;
    setTrafficLoading(true);
    try {
      const res = await fetch("/api/traffic/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-session-token": sessionToken },
        body: JSON.stringify({ enabled: !trafficEnabled })
      });
      const data = await res.json();
      setTrafficEnabled(data.enabled);
    } catch (err) {
      console.error(err);
    } finally {
      setTrafficLoading(false);
    }
  };

  const workingBalance = totalBalance !== null ? Math.max(0, totalBalance - SECURITY_DEPOSIT_RUB) : null;
  const securityBalance = totalBalance !== null ? Math.min(SECURITY_DEPOSIT_RUB, totalBalance) : null;

  const fmtRub = (v: number) =>
    new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 0 }).format(v) + " ₽";

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
    localStorage.clear();
    window.location.href = "/";
  };

  const NavItem = ({ item, onClick }: { item: MenuItem; onClick?: () => void }) => {
    const isActive = location === item.href;
    return (
      <Link key={item.href} href={item.href}>
        <div
          onClick={onClick}
          className={`flex items-center justify-between px-3 py-2.5 rounded-lg transition-all cursor-pointer group ${
            isActive
              ? "bg-[#D4AF37]/10 text-[#D4AF37] border-l-2 border-[#D4AF37]"
              : "text-gray-400 hover:bg-gray-800/50 hover:text-white"
          }`}
        >
          <div className="flex items-center gap-3">
            <item.icon className="w-4 h-4 flex-shrink-0" />
            <span className="text-sm">{item.name}</span>
          </div>
          {item.badge && (
            <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-[#D4AF37]/20 text-[#D4AF37]">
              {item.badge}
            </span>
          )}
        </div>
      </Link>
    );
  };

  const DepositButton = ({ onClick }: { onClick?: () => void }) => (
    <Link href="/wallet">
      <div
        onClick={onClick}
        className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[#D4AF37] text-black font-bold text-sm cursor-pointer hover:bg-[#c4a030] transition-colors"
      >
        <PlusCircle className="w-4 h-4 flex-shrink-0" />
        <span>Пополнить</span>
      </div>
    </Link>
  );

  const BalanceBar = () => (
    <div className="px-3 py-3 border-b border-gray-800 bg-black/30">
      <p className="text-gray-500 text-[10px] uppercase tracking-wider mb-2 font-mono">Баланс</p>
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-gray-400 text-xs">Итого</span>
          <span className="text-[#D4AF37] font-bold font-mono text-sm">
            {totalBalance !== null ? fmtRub(totalBalance) : "..."}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Lock className="w-3 h-3 text-orange-400" />
            <span className="text-gray-400 text-xs">Страховой</span>
          </div>
          <span className="text-orange-400 font-bold font-mono text-sm">
            {securityBalance !== null ? fmtRub(securityBalance) : "..."}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <TrendingUp className="w-3 h-3 text-green-400" />
            <span className="text-gray-400 text-xs">Рабочий</span>
          </div>
          <span className="text-green-400 font-bold font-mono text-sm">
            {workingBalance !== null ? fmtRub(workingBalance) : "..."}
          </span>
        </div>
      </div>
      <div className="mt-3 pt-2 border-t border-gray-700/50">
        <div className="flex items-center justify-between text-xs">
          <span className="text-gray-400">Активных карт</span>
          <span className="text-[#D4AF37] font-mono font-bold">{activeCardCount}</span>
        </div>
        <div className="flex items-center justify-between text-xs mt-1">
          <span className="text-gray-400">Комиссия платформы</span>
          <span className="text-green-400 font-mono">5%</span>
        </div>
      </div>
    </div>
  );

  const TrafficToggle = () => (
    <div className="px-3 py-2 border-b border-gray-800">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {trafficEnabled ? (
            <Play className="w-3 h-3 text-green-500" />
          ) : (
            <Pause className="w-3 h-3 text-red-500" />
          )}
          <span className="text-xs text-gray-400 font-mono">Трафик</span>
        </div>
        <button
          onClick={toggleTraffic}
          disabled={trafficLoading}
          className={`relative w-10 h-5 rounded-full transition-colors ${trafficEnabled ? "bg-[#D4AF37]" : "bg-gray-600"}`}
        >
          <span
            className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${
              trafficEnabled ? "translate-x-5" : "translate-x-0.5"
            }`}
          />
        </button>
      </div>
      <p className="text-[10px] text-gray-500 mt-1">
        {trafficEnabled ? "Приём платежей включён" : "Приём платежей остановлен"}
      </p>
    </div>
  );

  const MobileBalanceBar = () => (
    <div className="flex items-center gap-4 text-xs bg-black/50 px-4 py-2 border-b border-gray-800 overflow-x-auto">
      <div className="flex items-center gap-1.5 flex-shrink-0">
        <span className="text-gray-500">Итого:</span>
        <span className="text-[#D4AF37] font-mono font-bold text-sm">
          {totalBalance !== null ? fmtRub(totalBalance) : "..."}
        </span>
      </div>
      <div className="flex items-center gap-1.5 flex-shrink-0">
        <Lock className="w-3 h-3 text-orange-400" />
        <span className="text-orange-400 font-mono font-bold text-sm">
          {securityBalance !== null ? fmtRub(securityBalance) : "..."}
        </span>
      </div>
      <div className="flex items-center gap-1.5 flex-shrink-0">
        <TrendingUp className="w-3 h-3 text-green-400" />
        <span className="text-green-400 font-mono font-bold text-sm">
          {workingBalance !== null ? fmtRub(workingBalance) : "..."}
        </span>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-black">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex w-64 border-r border-gray-800 bg-black/50 backdrop-blur-sm flex-col flex-shrink-0">
        <div className="flex items-center gap-2 px-4 py-5 border-b border-gray-800">
          <div className="w-8 h-8 bg-[#D4AF37] rounded-md shadow-md shadow-[#D4AF37]/30 flex-shrink-0" />
          <span className="text-white font-bold tracking-wider font-mono text-sm">PLAYERS2</span>
        </div>
        <BalanceBar />
        <TrafficToggle />
        <div className="px-3 pt-3 pb-1">
          <DepositButton />
        </div>
        <nav className="flex-1 overflow-y-auto py-2 px-3 space-y-1 scrollbar-gold">
          {menuItems.map((item) => (
            <NavItem key={item.href} item={item} />
          ))}
        </nav>
        <div className="p-3 border-t border-gray-800">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-gray-400 hover:bg-red-500/10 hover:text-red-500 transition-all w-full"
          >
            <LogOut className="w-4 h-4" />
            <span className="text-sm">Выйти</span>
          </button>
        </div>
      </aside>

      {/* Mobile top bar */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-40 flex flex-col bg-black border-b border-gray-800">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-[#D4AF37] rounded-md" />
            <span className="text-white font-bold tracking-wider font-mono text-sm">PLAYERS2</span>
          </div>
          <button
            onClick={() => setDrawerOpen(true)}
            className="p-2 rounded-lg hover:bg-gray-800 transition-colors"
          >
            <Menu className="w-5 h-5 text-white" />
          </button>
        </div>
        <MobileBalanceBar />
      </div>

      {/* Mobile drawer overlay */}
      {drawerOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/70 z-50"
          onClick={() => setDrawerOpen(false)}
        >
          <div
            className="absolute left-0 top-0 bottom-0 w-72 bg-[#0a0a0a] border-r border-gray-800 flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-5 border-b border-gray-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-[#D4AF37] rounded-md" />
                <span className="text-white font-bold tracking-wider font-mono text-sm">PLAYERS2</span>
              </div>
              <button onClick={() => setDrawerOpen(false)} className="p-1 rounded-lg hover:bg-gray-800">
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>
            <BalanceBar />
            <TrafficToggle />
            <div className="px-3 pt-3 pb-1">
              <DepositButton onClick={() => setDrawerOpen(false)} />
            </div>
            <nav className="flex-1 overflow-y-auto py-2 px-3 space-y-1 scrollbar-gold">
              {menuItems.map((item) => (
                <NavItem key={item.href} item={item} onClick={() => setDrawerOpen(false)} />
              ))}
            </nav>
            <div className="p-3 border-t border-gray-800">
              <button
                onClick={handleLogout}
                className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-gray-400 hover:bg-red-500/10 hover:text-red-500 transition-all w-full"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm">Выйти</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main content */}
      <main className="flex-1 overflow-auto md:min-w-0">
        <div className="md:hidden h-[96px]" />
        {children}
        <div className="md:hidden h-16" />
      </main>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-black border-t border-gray-800 flex items-center justify-around px-2 py-2">
        {bottomNavItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div className={`flex flex-col items-center gap-1 px-4 py-1 rounded-lg transition-all ${
                isActive ? "text-[#D4AF37]" : "text-gray-500"
              }`}>
                <item.icon className="w-5 h-5" />
                <span className="text-[10px]">{item.name}</span>
              </div>
            </Link>
          );
        })}
        <button
          onClick={() => setDrawerOpen(true)}
          className="flex flex-col items-center gap-1 px-4 py-1 rounded-lg text-gray-500 transition-all"
        >
          <Menu className="w-5 h-5" />
          <span className="text-[10px]">Меню</span>
        </button>
      </nav>
    </div>
  );
}
