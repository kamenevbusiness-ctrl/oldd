import { useState, useEffect } from "react";
import { TrafficToggle } from "./TrafficToggle";
import { Bell } from "lucide-react";

interface TopNavProps {
  traderName: string;
  todayVolume: number;
}

export function TopNav({ traderName, todayVolume }: TopNavProps) {
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [trafficEnabled, setTrafficEnabled] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("sessionToken");
    if (token) setSessionToken(token);
    fetchTrafficStatus();
  }, []);

  const fetchTrafficStatus = async () => {
    const token = localStorage.getItem("sessionToken");
    if (!token) return;
    try {
      const res = await fetch("/api/traffic/status", {
        headers: { "x-session-token": token }
      });
      const data = await res.json();
      setTrafficEnabled(data.enabled);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800 bg-black/50 backdrop-blur-sm sticky top-0 z-30">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 px-3 py-1.5 bg-gray-900 rounded-full">
          <span className="text-xs text-gray-400 hidden sm:inline">Трафик</span>
          <TrafficToggle />
          <span className={`text-xs ${trafficEnabled ? "text-green-500" : "text-red-500"}`}>
            {trafficEnabled ? "Вкл" : "Выкл"}
          </span>
        </div>

        <div className="hidden sm:block">
          <div className="text-[10px] text-gray-500">Оборот сегодня</div>
          <div className="text-white font-mono font-bold text-sm">${todayVolume.toLocaleString()}</div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button className="p-2 rounded-lg hover:bg-gray-800 transition-colors relative">
          <Bell className="w-5 h-5 text-gray-400" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#8B6914] flex items-center justify-center flex-shrink-0">
            <span className="text-black text-sm font-bold">{traderName[0]?.toUpperCase()}</span>
          </div>
          <span className="text-white text-sm hidden sm:inline">{traderName}</span>
        </div>
      </div>
    </div>
  );
}
