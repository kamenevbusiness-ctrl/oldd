import { useState } from "react";
import { X } from "lucide-react";

interface CardForm {
  type: string;
  currency: string;
  details: string;
  bank?: string;
  minAmount: number;
  maxAmount: number;
  dailyLimit: number;
  minuteLimit: number;
  intervalMin: number;
  intervalMax: number;
  scheduleEnabled: boolean;
  scheduleStart: string;
  scheduleEnd: string;
}

interface AddCardModalProps {
  onClose: () => void;
  onSave: (card: CardForm) => Promise<void>;
}

const empty: CardForm = {
  type: "card",
  currency: "RUB",
  details: "",
  bank: "",
  minAmount: 100,
  maxAmount: 100000,
  dailyLimit: 100000,
  minuteLimit: 5,
  intervalMin: 30,
  intervalMax: 60,
  scheduleEnabled: false,
  scheduleStart: "00:00",
  scheduleEnd: "23:59",
};

export function AddCardModal({ onClose, onSave }: AddCardModalProps) {
  const [form, setForm] = useState<CardForm>(empty);
  const [loading, setLoading] = useState(false);

  const set = (field: keyof CardForm) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm((prev) => ({ ...prev, [field]: e.target.type === "number" ? Number(e.target.value) : e.target.value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onSave(form);
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50" onClick={onClose}>
      <div
        className="bg-[#0f0f0f] border border-[#D4AF37]/20 rounded-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-xl font-bold text-white">Добавить реквизит</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-xs text-gray-400 mb-1">Тип</label>
            <select
              value={form.type}
              onChange={set("type")}
              className="w-full p-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white focus:outline-none focus:border-[#D4AF37]"
            >
              <option value="card">Карта РФ</option>
              <option value="card_tj">Карта Таджикистан</option>
              <option value="card_uz">Карта Узбекистан</option>
              <option value="card_kz">Карта Казахстан</option>
              <option value="card_ge">Карта Грузия</option>
              <option value="card_kg">Карта Киргизия</option>
              <option value="card_am">Карта Армения</option>
              <option value="card_ar">Карта Аргентина</option>
              <option value="sbp">СБП</option>
              <option value="mobile">Мобильная коммерция</option>
              <option value="collection">Сбор</option>
              <option value="bt">Белые треугольники (P2P)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs text-gray-400 mb-1">Реквизиты</label>
            <input
              required
              placeholder={form.type === "sbp" ? "Номер телефона" : form.type === "collection" ? "Номер сбора" : "Номер карты / счёт"}
              value={form.details}
              onChange={set("details")}
              className="w-full p-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-[#D4AF37]"
            />
          </div>

          {(form.type === "card" || form.type === "card_tj" || form.type === "card_uz" || form.type === "card_kz" || form.type === "card_ge" || form.type === "card_kg" || form.type === "card_am" || form.type === "card_ar") && (
            <div>
              <label className="block text-xs text-gray-400 mb-1">Банк</label>
              <input
                placeholder="Название банка"
                value={form.bank}
                onChange={set("bank")}
                className="w-full p-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white focus:outline-none focus:border-[#D4AF37]"
              />
            </div>
          )}

          <div>
            <label className="block text-xs text-gray-400 mb-1">Валюта</label>
            <select
              value={form.currency}
              onChange={set("currency")}
              className="w-full p-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white focus:outline-none focus:border-[#D4AF37]"
            >
              <option value="RUB">RUB</option>
              <option value="USDT">USDT</option>
              <option value="UZS">UZS</option>
              <option value="TJS">TJS</option>
              <option value="KZT">KZT</option>
              <option value="GEL">GEL</option>
              <option value="KGS">KGS</option>
              <option value="AMD">AMD</option>
              <option value="ARS">ARS</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Мин. сумма</label>
              <input type="number" value={form.minAmount} onChange={set("minAmount")}
                className="w-full p-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Макс. сумма</label>
              <input type="number" value={form.maxAmount} onChange={set("maxAmount")}
                className="w-full p-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
            </div>
          </div>

          <div>
            <label className="block text-xs text-gray-400 mb-1">Дневной лимит (₽)</label>
            <input type="number" value={form.dailyLimit} onChange={set("dailyLimit")}
              className="w-full p-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Платежей/мин</label>
              <input type="number" value={form.minuteLimit} onChange={set("minuteLimit")}
                className="w-full p-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Интервал (сек)</label>
              <div className="flex gap-2">
                <input type="number" placeholder="мин" value={form.intervalMin} onChange={set("intervalMin")}
                  className="w-1/2 p-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
                <input type="number" placeholder="макс" value={form.intervalMax} onChange={set("intervalMax")}
                  className="w-1/2 p-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.scheduleEnabled}
              onChange={(e) => setForm({ ...form, scheduleEnabled: e.target.checked })}
              className="w-4 h-4 accent-[#D4AF37]"
            />
            <label className="text-sm text-gray-300">Использовать расписание</label>
          </div>

          {form.scheduleEnabled && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-gray-400 mb-1">Начало</label>
                <input type="time" value={form.scheduleStart} onChange={set("scheduleStart")}
                  className="w-full p-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">Конец</label>
                <input type="time" value={form.scheduleEnd} onChange={set("scheduleEnd")}
                  className="w-full p-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
              </div>
            </div>
          )}

          <button type="submit" disabled={loading}
            className="w-full mt-2 py-3 bg-[#D4AF37] text-black rounded-lg font-bold hover:bg-[#c4a030] transition-all disabled:opacity-50">
            {loading ? "Сохранение..." : "Добавить"}
          </button>
        </form>
      </div>
    </div>
  );
}
