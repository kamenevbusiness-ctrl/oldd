import { AlertTriangle, X } from "lucide-react";

interface ConfirmDialogProps {
  open: boolean;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export function ConfirmDialog({
  open,
  title,
  message,
  confirmText = "Подтвердить",
  cancelText = "Отмена",
  danger = false,
  onConfirm,
  onCancel,
}: ConfirmDialogProps) {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 bg-black/80 flex items-center justify-center z-[9998] p-4"
      onClick={onCancel}
    >
      <div
        className="bg-[#0f0f0f] rounded-2xl p-6 w-full max-w-sm border border-gray-800 shadow-2xl"
        style={{ boxShadow: "0 24px 64px rgba(0,0,0,0.8)" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start gap-4 mb-5">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${danger ? "bg-red-500/10" : "bg-[#D4AF37]/10"}`}>
            <AlertTriangle className={`w-5 h-5 ${danger ? "text-red-500" : "text-[#D4AF37]"}`} />
          </div>
          <div className="flex-1">
            <h3 className="text-white font-bold text-base mb-1">{title}</h3>
            <p className="text-gray-400 text-sm leading-relaxed">{message}</p>
          </div>
          <button onClick={onCancel} className="text-gray-600 hover:text-gray-300 transition-colors flex-shrink-0">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 bg-gray-800 hover:bg-gray-700 text-white rounded-xl text-sm font-medium transition-colors"
          >
            {cancelText}
          </button>
          <button
            onClick={() => { onConfirm(); }}
            className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-colors ${
              danger
                ? "bg-red-500/90 hover:bg-red-500 text-white"
                : "bg-[#D4AF37] hover:bg-[#c4a030] text-black"
            }`}
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
}
