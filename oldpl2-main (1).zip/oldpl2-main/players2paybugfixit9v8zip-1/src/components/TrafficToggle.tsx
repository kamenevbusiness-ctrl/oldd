import { useState, useEffect } from "react";

interface TrafficToggleProps {
  onToggle?: (enabled: boolean) => void;
}

export function TrafficToggle({ onToggle }: TrafficToggleProps) {
  const [enabled, setEnabled] = useState(false);
  const [loading, setLoading] = useState(false);
  const [sessionToken, setSessionToken] = useState<string | null>(null);

  useEffect(() => {
    const token = localStorage.getItem("sessionToken");
    if (token) setSessionToken(token);
  }, []);

  const fetchStatus = async () => {
    if (!sessionToken) return;
    try {
      const res = await fetch("/api/traffic/status", {
        headers: { "x-session-token": sessionToken }
      });
      const data = await res.json();
      setEnabled(data.enabled);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, [sessionToken]);

  const handleToggle = async () => {
    if (!sessionToken) return;
    setLoading(true);
    try {
      const res = await fetch("/api/traffic/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-session-token": sessionToken },
        body: JSON.stringify({ enabled: !enabled }),
      });
      if (res.ok) {
        const data = await res.json();
        setEnabled(data.enabled);
        onToggle?.(data.enabled);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      onClick={handleToggle}
      disabled={loading}
      className={`relative w-14 h-7 rounded-full transition-all duration-300 ${
        enabled ? "bg-[#D4AF37]" : "bg-gray-700"
      } ${loading ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
    >
      <div
        className={`absolute top-1 w-5 h-5 rounded-full bg-white transition-all duration-300 ${
          enabled ? "right-1" : "left-1"
        }`}
      />
    </button>
  );
}
