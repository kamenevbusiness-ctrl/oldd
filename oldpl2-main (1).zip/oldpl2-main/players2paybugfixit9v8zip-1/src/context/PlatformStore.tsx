import { createContext, useContext, useState, ReactNode } from "react";

// ── Cards (Реквизиты) ─────────────────────────────────────────────────────

export interface Rekvizit {
  id: number;
  type: "card" | "sbp" | "mobile" | "collection" | "card_tj" | "card_uz" | "card_kz" | "card_ge" | "card_kg" | "card_am" | "card_ar" | "bt";
  name: string;
  details: string;
  currency: "RUB" | "USDT" | "UZS" | "TJS" | "KZT" | "GEL" | "KGS" | "AMD" | "ARS";
  bank?: string;
  sbpBank?: string;
  collectionBank?: string;
  minAmount: number;
  maxAmount: number;
  dailyLimit: number;
  usedDaily: number;
  minuteLimit: number;
  intervalMin: number;
  intervalMax: number;
  scheduleEnabled: boolean;
  scheduleStart: string;
  scheduleEnd: string;
  isActive: boolean;
  icon: string;
  cardNumber?: string;
  holderName?: string;
  phone?: string;
  collectionId?: string;
  operator?: string;
}

// Демо-данные (будут заменены реальными API)
const defaultCards: Rekvizit[] = [
  {
    id: 1, type: "card", name: "Тинькофф", details: "****4832", currency: "RUB", bank: "Тинькофф",
    minAmount: 100, maxAmount: 150000, dailyLimit: 1000000, usedDaily: 125000,
    minuteLimit: 5, intervalMin: 30, intervalMax: 60, scheduleEnabled: false,
    scheduleStart: "00:00", scheduleEnd: "23:59", isActive: true, icon: "💳",
    cardNumber: "4832", holderName: "IVAN IVANOV",
  },
  {
    id: 2, type: "sbp", name: "СБП • Сбербанк", details: "+7 999 123-45-67", currency: "RUB", sbpBank: "Сбербанк",
    minAmount: 10, maxAmount: 100000, dailyLimit: 500000, usedDaily: 50000,
    minuteLimit: 10, intervalMin: 15, intervalMax: 30, scheduleEnabled: false,
    scheduleStart: "00:00", scheduleEnd: "23:59", isActive: true, icon: "🔵",
    phone: "+7 999 123-45-67",
  },
  {
    id: 3, type: "collection", name: "Сбор • Сбербанк", details: "Сбор #12345", currency: "RUB", collectionBank: "Сбербанк",
    minAmount: 100, maxAmount: 50000, dailyLimit: 200000, usedDaily: 25000,
    minuteLimit: 20, intervalMin: 10, intervalMax: 20, scheduleEnabled: true,
    scheduleStart: "10:00", scheduleEnd: "20:00", isActive: true, icon: "🎯",
    collectionId: "12345",
  },
  {
    id: 4, type: "bt", name: "Белые треугольники (P2P)", details: "+7 999 888-77-66", currency: "USDT",
    minAmount: 50, maxAmount: 50000, dailyLimit: 100000, usedDaily: 0,
    minuteLimit: 3, intervalMin: 60, intervalMax: 120, scheduleEnabled: false,
    scheduleStart: "00:00", scheduleEnd: "23:59", isActive: true, icon: "🔄",
    phone: "+7 999 888-77-66",
  },
];

// ── Devices ────────────────────────────────────────────────────────────────

export interface Device {
  id: string;
  name: string;
  brand: string;
  model: string;
  lastActive: Date;
  isActive: boolean;
  registeredAt: Date;
  battery?: number;
  network?: string;
}

const defaultDevices: Device[] = [
  {
    id: "1",
    name: "Samsung A115F",
    brand: "Samsung",
    model: "Galaxy A12",
    lastActive: new Date(Date.now() - 2 * 60 * 1000),
    registeredAt: new Date(2026, 4, 20, 18, 32),
    isActive: true,
    battery: 87,
    network: "Wi-Fi",
  },
  {
    id: "2",
    name: "Xiaomi Pad 5",
    brand: "Xiaomi",
    model: "Pad 5",
    lastActive: new Date(2026, 4, 25, 22, 15),
    registeredAt: new Date(2026, 4, 25, 10, 0),
    isActive: false,
    battery: 12,
    network: "4G",
  },
];

// ── Context ────────────────────────────────────────────────────────────────

interface PlatformCtx {
  cards: Rekvizit[];
  setCards: React.Dispatch<React.SetStateAction<Rekvizit[]>>;
  activeCardCount: number;

  devices: Device[];
  setDevices: React.Dispatch<React.SetStateAction<Device[]>>;
  activeDeviceCount: number;
  totalDeviceCount: number;
  offlineDeviceCount: number;
}

const Ctx = createContext<PlatformCtx | null>(null);

export function PlatformStoreProvider({ children }: { children: ReactNode }) {
  const [cards, setCards] = useState<Rekvizit[]>(defaultCards);
  const [devices, setDevices] = useState<Device[]>(defaultDevices);

  const activeCardCount = cards.filter(c => c.isActive).length;
  const activeDeviceCount = devices.filter(d => d.isActive).length;
  const totalDeviceCount = devices.length;
  const offlineDeviceCount = devices.filter(d => !d.isActive).length;

  return (
    <Ctx.Provider value={{
      cards, setCards, activeCardCount,
      devices, setDevices, activeDeviceCount, totalDeviceCount, offlineDeviceCount,
    }}>
      {children}
    </Ctx.Provider>
  );
}

export function usePlatformStore(): PlatformCtx {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("usePlatformStore must be used inside PlatformStoreProvider");
  return ctx;
}
