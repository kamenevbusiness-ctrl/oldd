import { useState, useEffect, useCallback } from "react";
import { Smartphone, Plus, Trash2, Power, Clock, Wifi, WifiOff, X } from "lucide-react";
import { AppLayout } from "@/components/AppLayout";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useToast } from "@/components/Toast";

interface Device {
  id: string;
  name: string;
  brand: string;
  model: string;
  lastActive: string;
  isActive: boolean;
  registeredAt: string;
}

// Бренды и модели (20 брендов × ~20 моделей = 400 комбинаций)
const brands = [
  'Samsung', 'Xiaomi', 'Huawei', 'Google', 'Sony', 'LG', 'Realme', 'Oppo', 'Vivo', 'Poco',
  'Honor', 'Asus', 'ZTE', 'Infinix', 'Tecno'
];

const models: Record<string, string[]> = {
  Samsung: ['Galaxy S23', 'Galaxy S23+', 'Galaxy S23 Ultra', 'Galaxy A54', 'Galaxy A34', 'Galaxy Z Fold5', 'Galaxy Z Flip5', 'Galaxy Note20', 'Galaxy S21 FE', 'Galaxy A73'],
  Xiaomi: ['13 Pro', '13T Pro', '12T Pro', 'Redmi Note 12', 'Redmi Note 13', 'POCO F5', 'POCO X5', 'Mi 11 Ultra', '12 Lite', '13 Lite'],
  Huawei: ['P60 Pro', 'P50 Pro', 'Mate 50 Pro', 'Mate 40 Pro', 'Nova 11', 'Nova 10', 'P40 Pro', 'Mate 30 Pro', 'Y9a', 'P30 Pro'],
  Google: ['Pixel 8 Pro', 'Pixel 8', 'Pixel 7 Pro', 'Pixel 7', 'Pixel 6 Pro', 'Pixel 6', 'Pixel 7a', 'Pixel Fold', 'Pixel 5', 'Pixel 4a'],
  Sony: ['Xperia 1 V', 'Xperia 5 V', 'Xperia 10 V', 'Xperia Pro-I', 'Xperia 1 IV', 'Xperia 5 IV', 'Xperia 10 IV', 'Xperia Ace III', 'Xperia L4', 'Xperia XZ3'],
  LG: ['Velvet', 'Wing', 'V60 ThinQ', 'G8X ThinQ', 'K92', 'Stylo 7', 'Q92', 'K71', 'W11', 'G7 One'],
  Realme: ['GT3', 'GT Neo 5', 'GT2 Pro', 'GT2', '10 Pro+', '10 Pro', '10', 'C55', 'C53', 'Narzo 60'],
  Oppo: ['Find X6 Pro', 'Find X5 Pro', 'Reno10 Pro+', 'Reno10 Pro', 'Reno8 Pro', 'Reno8', 'A98', 'A78', 'A58', 'K11x'],
  Vivo: ['X90 Pro', 'X90', 'V29 Pro', 'V29', 'Y100', 'Y36', 'Y22', 'T2 Pro', 'T2', 'S17 Pro'],
  Poco: ['F5 Pro', 'F5', 'X5 Pro', 'X5', 'M5 Pro', 'M5', 'C55', 'C51', 'F4 GT', 'M4 Pro'],
  Honor: ['Magic5 Pro', 'Magic5 Lite', '90 Pro', '90 Lite', '80 Pro', '80', 'X9a', 'X8a', 'Pad X9', 'Magic Vs'],
  Asus: ['Zenfone 10', 'Zenfone 9', 'ROG Phone 7', 'ROG Phone 6', 'ROG Phone 6 Pro', 'Zenfone 8', 'ROG Phone 5s', 'Max M2', 'Max Pro M2', 'Live L2'],
  ZTE: ['Axon 50 Ultra', 'Axon 40 Ultra', 'Blade V50', 'Blade V40', 'Nubia Z50', 'Nubia Red Magic 8 Pro', 'Nubia Red Magic 7', 'Axon 30 Pro', 'Blade A72', 'Blade L9'],
  Infinix: ['Zero Ultra', 'Zero 30', 'Note 30 VIP', 'Note 30 Pro', 'Note 30', 'Hot 30', 'Hot 30i', 'Smart 8', 'Smart 7', 'GT 10 Pro'],
  Tecno: ['Camon 20 Pro', 'Camon 20', 'Pova 5 Pro', 'Pova 5', 'Spark 10 Pro', 'Spark 10', 'Spark 10C', 'Phantom X2 Pro', 'Phantom X2', 'Camon 19 Pro']
};

export default function Devices() {
  const toast = useToast();
  const [devices, setDevices] = useState<Device[]>([]);
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedBrand, setSelectedBrand] = useState(brands[0]);
  const [selectedModel, setSelectedModel] = useState(models[brands[0]][0]);
  const [deviceName, setDeviceName] = useState("");
  const [error, setError] = useState("");
  const [deleteConfirm, setDeleteConfirm] = useState<{ open: boolean; id: string; name: string }>({
    open: false, id: "", name: ""
  });

  useEffect(() => {
    const token = localStorage.getItem("sessionToken");
    if (token) setSessionToken(token);
  }, []);

  const fetchDevices = useCallback(async () => {
    if (!sessionToken) {
      setLoading(false);
      return;
    }
    try {
      const res = await fetch("/api/devices", {
        headers: { "x-session-token": sessionToken }
      });
      const data = await res.json();
      setDevices(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
      setDevices([]);
    } finally {
      setLoading(false);
    }
  }, [sessionToken]);

  useEffect(() => {
    fetchDevices();
    const interval = setInterval(fetchDevices, 15000);
    return () => clearInterval(interval);
  }, [fetchDevices]);

  const addDevice = async () => {
    if (!deviceName.trim()) {
      setError("Введите имя устройства");
      return;
    }
    try {
      const res = await fetch("/api/devices", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-session-token": sessionToken || "" },
        body: JSON.stringify({ name: deviceName, brand: selectedBrand, model: selectedModel })
      });
      if (res.ok) {
        toast.success("Устройство добавлено", `${deviceName} подключено к системе`);
        setShowModal(false);
        setDeviceName("");
        fetchDevices();
      } else {
        setError("Ошибка добавления");
      }
    } catch (err) {
      setError("Ошибка сети");
    }
  };

  const toggleActive = async (id: string, currentActive: boolean) => {
    try {
      await fetch(`/api/devices/${id}/toggle`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", "x-session-token": sessionToken || "" },
        body: JSON.stringify({ isActive: !currentActive })
      });
      fetchDevices();
      toast.success(!currentActive ? "Устройство включено" : "Устройство отключено", "");
    } catch (err) {
      console.error(err);
    }
  };

  const deleteDevice = async (id: string) => {
    try {
      await fetch(`/api/devices/${id}`, {
        method: "DELETE",
        headers: { "x-session-token": sessionToken || "" }
      });
      fetchDevices();
      toast.error("Устройство удалено", "");
    } catch (err) {
      console.error(err);
    }
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  const getRelativeTime = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    const hrs = Math.floor(diff / 3600000);
    if (mins < 1) return "только что";
    if (mins < 60) return `${mins} мин назад`;
    if (hrs < 24) return `${hrs} ч назад`;
    return formatDate(dateStr);
  };

  const getStatus = (device: Device) => {
    const mins = Math.floor((Date.now() - new Date(device.lastActive).getTime()) / 60000);
    if (!device.isActive) return { label: "Отключено", color: "text-red-400", bg: "bg-red-500/10 border-red-500/20" };
    if (mins < 5) return { label: "Онлайн", color: "text-green-400", bg: "bg-green-500/10 border-green-500/20" };
    if (mins < 60) return { label: "Был недавно", color: "text-yellow-400", bg: "bg-yellow-500/10 border-yellow-500/20" };
    return { label: "Неактивен", color: "text-gray-400", bg: "bg-gray-500/10 border-gray-500/20" };
  };

  const onlineCount = devices.filter(d => d.isActive).length;
  const offlineCount = devices.filter(d => !d.isActive).length;

  if (loading) {
    return (
      <AppLayout>
        <div className="p-6 text-white">Загрузка...</div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6 p-4 md:p-6">

        {/* Header */}
        <div className="flex justify-between items-center flex-wrap gap-4">
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-white font-mono flex items-center gap-2">
              <Smartphone className="w-5 h-5 md:w-6 md:h-6 text-[#D4AF37]" />
              Устройства
            </h1>
            <p className="text-gray-500 text-xs md:text-sm mt-1">Управление устройствами для автоподтверждения платежей</p>
          </div>
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-[#D4AF37] text-black rounded-lg font-bold hover:bg-[#c4a030] transition-colors text-sm"
          >
            <Plus className="w-4 h-4" />
            Добавить устройство
          </button>
        </div>

        {/* Stats bar */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-[#0f0f0f] rounded-xl border border-gray-800 p-4 text-center">
            <p className="text-2xl font-bold text-white font-mono">{devices.length}</p>
            <p className="text-xs text-gray-500 mt-1">Всего</p>
          </div>
          <div className="bg-[#0f0f0f] rounded-xl border border-green-500/20 p-4 text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              {onlineCount > 0 && <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />}
              <p className="text-2xl font-bold text-green-500 font-mono">{onlineCount}</p>
            </div>
            <p className="text-xs text-gray-500">Онлайн</p>
          </div>
          <div className="bg-[#0f0f0f] rounded-xl border border-red-500/20 p-4 text-center">
            <p className="text-2xl font-bold text-red-400 font-mono">{offlineCount}</p>
            <p className="text-xs text-gray-500 mt-1">Офлайн</p>
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 p-4">
          <h3 className="text-white font-medium mb-2 font-mono text-sm flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-[#D4AF37]" />
            Как подключить устройство
          </h3>
          <ol className="text-gray-400 text-xs space-y-1 list-decimal list-inside leading-relaxed">
            <li>Установите приложение PLAYERS2PAY Terminal на Android-устройство</li>
            <li>Откройте приложение и войдите по токену трейдера</li>
            <li>Устройство автоматически появится в этом списке</li>
            <li>Включите доступ к уведомлениям для автоподтверждения</li>
          </ol>
        </div>

        {/* Device list */}
        <div className="space-y-3">
          {devices.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-2xl bg-gray-800/50 flex items-center justify-center mx-auto mb-4">
                <Smartphone className="w-8 h-8 text-gray-600" />
              </div>
              <p className="text-gray-400 font-medium">Нет добавленных устройств</p>
              <p className="text-gray-600 text-sm mt-1 mb-4">Добавьте первое устройство для автоподтверждения</p>
              <button
                onClick={() => setShowModal(true)}
                className="px-4 py-2 bg-[#D4AF37] text-black rounded-lg text-sm font-bold hover:bg-[#c4a030] transition-colors"
              >
                Добавить устройство
              </button>
            </div>
          ) : (
            devices.map((device) => {
              const status = getStatus(device);
              return (
                <div
                  key={device.id}
                  className={`bg-[#0f0f0f] rounded-xl border ${device.isActive ? "border-[#D4AF37]/20" : "border-gray-800"} p-4 transition-all hover:border-[#D4AF37]/30`}
                >
                  <div className="flex items-center justify-between gap-3 mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-[#D4AF37]/10 flex items-center justify-center flex-shrink-0">
                        <Smartphone className="w-5 h-5 text-[#D4AF37]" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-white font-semibold">{device.name}</h3>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full border font-mono ${status.bg} ${status.color}`}>
                            {status.label}
                          </span>
                        </div>
                        <p className="text-gray-500 text-xs mt-0.5">{device.brand} {device.model}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => toggleActive(device.id, device.isActive)}
                        className={`p-2 rounded-lg transition-all ${device.isActive ? "text-green-500 bg-green-500/10 hover:bg-green-500/20" : "text-gray-500 bg-gray-800 hover:bg-gray-700"}`}
                        title={device.isActive ? "Отключить" : "Включить"}
                      >
                        {device.isActive ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => {
                          setDeleteConfirm({ open: true, id: device.id, name: device.name });
                        }}
                        className="p-2 rounded-lg text-gray-500 hover:text-red-400 hover:bg-red-500/10 transition-all"
                        title="Удалить"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
                    <div className="bg-black/40 rounded-lg p-2.5">
                      <p className="text-gray-500 mb-0.5">ID устройства</p>
                      <p className="text-white font-mono text-xs break-all">{device.id}</p>
                    </div>
                    <div className="bg-black/40 rounded-lg p-2.5">
                      <p className="text-gray-500 mb-0.5">Зарегистрировано</p>
                      <p className="text-white font-mono">{formatDate(device.registeredAt)}</p>
                    </div>
                    <div className="bg-black/40 rounded-lg p-2.5">
                      <p className="text-gray-500 mb-0.5 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> Активность
                      </p>
                      <p className="text-white font-mono">{getRelativeTime(device.lastActive)}</p>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Add device modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={() => setShowModal(false)}>
            <div className="bg-[#0f0f0f] rounded-2xl p-6 w-full max-w-md border border-[#D4AF37]/20 shadow-2xl" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-xl font-bold text-white font-mono">Добавить устройство</h2>
                <button onClick={() => setShowModal(false)} className="text-gray-600 hover:text-gray-300 transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs text-gray-400 uppercase tracking-wider mb-2 font-mono">Название устройства</label>
                  <input
                    type="text"
                    value={deviceName}
                    onChange={(e) => setDeviceName(e.target.value)}
                    placeholder="Samsung A115F"
                    className="w-full px-4 py-2.5 bg-[#1a1a1a] border border-gray-700 rounded-xl text-white focus:outline-none focus:border-[#D4AF37] transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 uppercase tracking-wider mb-2 font-mono">Бренд</label>
                  <select
                    value={selectedBrand}
                    onChange={(e) => {
                      setSelectedBrand(e.target.value);
                      setSelectedModel(models[e.target.value]?.[0] || "");
                    }}
                    className="w-full px-4 py-2.5 bg-[#1a1a1a] border border-gray-700 rounded-xl text-white focus:outline-none focus:border-[#D4AF37] transition-colors"
                  >
                    {brands.map(b => <option key={b}>{b}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-gray-400 uppercase tracking-wider mb-2 font-mono">Модель</label>
                  <select
                    value={selectedModel}
                    onChange={(e) => setSelectedModel(e.target.value)}
                    className="w-full px-4 py-2.5 bg-[#1a1a1a] border border-gray-700 rounded-xl text-white focus:outline-none focus:border-[#D4AF37] transition-colors"
                  >
                    {models[selectedBrand]?.map(m => <option key={m}>{m}</option>)}
                  </select>
                </div>
                {error && (
                  <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">{error}</p>
                )}
                <div className="flex gap-3 pt-1">
                  <button onClick={() => setShowModal(false)} className="flex-1 py-2.5 bg-gray-800 hover:bg-gray-700 text-white rounded-xl text-sm font-medium transition-colors">Отмена</button>
                  <button onClick={addDevice} className="flex-1 py-2.5 bg-[#D4AF37] hover:bg-[#c4a030] text-black rounded-xl text-sm font-bold transition-colors">Добавить</button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Delete confirm dialog */}
        <ConfirmDialog
          open={deleteConfirm.open}
          title="Удалить устройство?"
          message={`Устройство «${deleteConfirm.name}» будет отключено от системы автоподтверждения. Отменить это действие невозможно.`}
          confirmText="Удалить"
          cancelText="Отмена"
          danger
          onConfirm={() => {
            deleteDevice(deleteConfirm.id);
            setDeleteConfirm({ open: false, id: "", name: "" });
          }}
          onCancel={() => setDeleteConfirm({ open: false, id: "", name: "" })}
        />
      </div>
    </AppLayout>
  );
}
