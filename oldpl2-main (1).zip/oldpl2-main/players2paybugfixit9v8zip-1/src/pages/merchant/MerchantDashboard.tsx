import { useState, useEffect, useCallback } from "react";
import { ShoppingBag, Copy, Check, Plus, Trash2, Eye, Download, Key } from "lucide-react";

interface Order {
  id: string;
  orderId: string;
  amount: number;
  currency: string;
  status: "pending" | "completed" | "failed";
  createdAt: string;
}

interface ApiKey {
  id: string;
  name: string;
  key: string;
  createdAt: string;
  lastUsed?: string;
}

export default function MerchantDashboard() {
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [merchantName, setMerchantName] = useState("");
  const [balance, setBalance] = useState(0);
  const [orders, setOrders] = useState<Order[]>([]);
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [activeTab, setActiveTab] = useState<"orders" | "api-keys">("orders");
  const [searchQuery, setSearchQuery] = useState("");
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [showCreateKeyModal, setShowCreateKeyModal] = useState(false);
  const [newKeyName, setNewKeyName] = useState("");
  const [orderAmount, setOrderAmount] = useState("");
  const [orderCurrency, setOrderCurrency] = useState("RUB");
  const [createOrderLoading, setCreateOrderLoading] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("sessionToken");
    if (token) setSessionToken(token);
    fetchData();
  }, []);

  const fetchData = async () => {
    if (!sessionToken) {
      setLoading(false);
      return;
    }
    try {
      const [merchantRes, ordersRes, keysRes] = await Promise.all([
        fetch("/api/merchant/profile", { headers: { "x-session-token": sessionToken } }),
        fetch("/api/merchant/orders", { headers: { "x-session-token": sessionToken } }),
        fetch("/api/merchant/api-keys", { headers: { "x-session-token": sessionToken } })
      ]);
      const merchantData = await merchantRes.json();
      const ordersData = await ordersRes.json();
      const keysData = await keysRes.json();
      setMerchantName(merchantData.name || "Мерчант");
      setBalance(merchantData.balance || 0);
      setOrders(Array.isArray(ordersData) ? ordersData : []);
      setApiKeys(Array.isArray(keysData) ? keysData : []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const createApiKey = async () => {
    if (!newKeyName.trim()) return;
    try {
      const res = await fetch("/api/merchant/api-keys", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-session-token": sessionToken || "" },
        body: JSON.stringify({ name: newKeyName })
      });
      if (res.ok) {
        const data = await res.json();
        setApiKeys([data, ...apiKeys]);
        setNewKeyName("");
        setShowCreateKeyModal(false);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const deleteApiKey = async (id: string) => {
    if (confirm("Удалить API-ключ?")) {
      try {
        await fetch(`/api/merchant/api-keys/${id}`, {
          method: "DELETE",
          headers: { "x-session-token": sessionToken || "" }
        });
        setApiKeys(apiKeys.filter(k => k.id !== id));
      } catch (err) {
        console.error(err);
      }
    }
  };

  const createOrder = async () => {
    const amount = parseFloat(orderAmount);
    if (isNaN(amount) || amount <= 0) {
      alert("Введите сумму");
      return;
    }
    setCreateOrderLoading(true);
    try {
      const res = await fetch("/api/merchant/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-session-token": sessionToken || "" },
        body: JSON.stringify({ amount, currency: orderCurrency })
      });
      if (res.ok) {
        const newOrder = await res.json();
        setOrders([newOrder, ...orders]);
        setOrderAmount("");
        alert("Заказ создан!");
      } else {
        alert("Ошибка создания заказа");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setCreateOrderLoading(false);
    }
  };

  const exportToCSV = () => {
    const headers = ["ID заказа", "Сумма", "Валюта", "Статус", "Дата"];
    const rows = orders.map(o => [o.orderId, o.amount, o.currency, o.status === "completed" ? "Выполнен" : o.status === "pending" ? "Ожидание" : "Ошибка", new Date(o.createdAt).toLocaleString()]);
    const csv = [headers, ...rows].map(row => row.join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `merchant_orders_${new Date().toISOString()}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
  };

  const filteredOrders = orders.filter(o => o.orderId.toLowerCase().includes(searchQuery.toLowerCase()));

  if (loading) {
    return (
      <div className="min-h-screen bg-black p-6 text-white">Загрузка...</div>
    );
  }

  return (
    <div className="min-h-screen bg-black p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono uppercase flex items-center gap-2 text-white">
            <ShoppingBag className="w-6 h-6 text-[#D4AF37]" />
            Мерчант панель
          </h1>
          <p className="text-sm text-gray-400 mt-1">Добро пожаловать, {merchantName}</p>
        </div>
        <button
          onClick={() => {
            localStorage.removeItem("sessionToken");
            window.location.href = "/merchant/login";
          }}
          className="px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors"
        >
          Выйти
        </button>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="bg-gradient-to-r from-[#D4AF37]/10 to-transparent rounded-2xl p-6 border border-[#D4AF37]/20">
          <p className="text-gray-400 text-sm">Баланс</p>
          <p className="text-3xl font-bold text-[#D4AF37]">{balance.toLocaleString()} ₽</p>
        </div>
        <div className="bg-[#0f0f0f] rounded-2xl p-6 border border-gray-800">
          <p className="text-gray-400 text-sm">Всего заказов</p>
          <p className="text-3xl font-bold text-white">{orders.length}</p>
          <p className="text-green-500 text-sm">Выполнено: {orders.filter(o => o.status === "completed").length}</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-gray-800">
        <button
          onClick={() => setActiveTab("orders")}
          className={`px-4 py-2 text-sm font-medium transition-all ${activeTab === "orders" ? "text-[#D4AF37] border-b-2 border-[#D4AF37]" : "text-gray-500 hover:text-gray-300"}`}
        >
          Заказы
        </button>
        <button
          onClick={() => setActiveTab("api-keys")}
          className={`px-4 py-2 text-sm font-medium transition-all ${activeTab === "api-keys" ? "text-[#D4AF37] border-b-2 border-[#D4AF37]" : "text-gray-500 hover:text-gray-300"}`}
        >
          API-ключи
        </button>
      </div>

      {/* Orders Tab */}
      {activeTab === "orders" && (
        <div>
          <div className="bg-[#0f0f0f] rounded-xl p-4 border border-gray-800 mb-6">
            <h3 className="text-white font-medium mb-3">Создать заказ</h3>
            <div className="flex flex-wrap gap-3">
              <input
                type="number"
                value={orderAmount}
                onChange={(e) => setOrderAmount(e.target.value)}
                placeholder="Сумма"
                className="px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white w-32"
              />
              <select
                value={orderCurrency}
                onChange={(e) => setOrderCurrency(e.target.value)}
                className="px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white"
              >
                <option value="RUB">RUB</option>
                <option value="USDT">USDT</option>
              </select>
              <button
                onClick={createOrder}
                disabled={createOrderLoading}
                className="px-4 py-2 bg-[#D4AF37] text-black rounded-lg font-bold hover:bg-[#c4a030]"
              >
                {createOrderLoading ? "Создание..." : "Создать"}
              </button>
              <button
                onClick={exportToCSV}
                className="px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                CSV
              </button>
            </div>
          </div>

          <div className="relative mb-4">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Поиск по ID заказа..."
              className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm"
            />
          </div>

          <div className="space-y-2">
            {filteredOrders.length === 0 ? (
              <p className="text-center text-gray-500 py-8">Нет заказов</p>
            ) : (
              filteredOrders.map(order => (
                <div key={order.id} className="bg-[#0f0f0f] rounded-xl border border-gray-800 p-4">
                  <div className="flex justify-between items-center flex-wrap gap-3">
                    <div>
                      <p className="text-white font-mono text-sm">{order.orderId}</p>
                      <p className="text-gray-500 text-xs">{new Date(order.createdAt).toLocaleString()}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-bold">{order.amount.toLocaleString()} {order.currency}</p>
                      <p className={`text-xs px-2 py-0.5 rounded-full inline-block ${
                        order.status === "completed" ? "bg-green-500/20 text-green-500" :
                        order.status === "pending" ? "bg-yellow-500/20 text-yellow-500" : "bg-red-500/20 text-red-500"
                      }`}>
                        {order.status === "completed" ? "Выполнен" : order.status === "pending" ? "Ожидание" : "Ошибка"}
                      </p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* API Keys Tab */}
      {activeTab === "api-keys" && (
        <div>
          <button
            onClick={() => setShowCreateKeyModal(true)}
            className="mb-4 flex items-center gap-2 px-4 py-2 bg-[#D4AF37] text-black rounded-lg font-bold hover:bg-[#c4a030]"
          >
            <Plus className="w-4 h-4" />
            Создать API-ключ
          </button>

          <div className="space-y-3">
            {apiKeys.length === 0 ? (
              <p className="text-center text-gray-500 py-8">Нет API-ключей</p>
            ) : (
              apiKeys.map(key => (
                <div key={key.id} className="bg-[#0f0f0f] rounded-xl border border-gray-800 p-4">
                  <div className="flex justify-between items-start flex-wrap gap-3">
                    <div>
                      <h3 className="text-white font-medium">{key.name}</h3>
                      <p className="text-gray-500 text-xs font-mono break-all">{key.key}</p>
                      <p className="text-gray-500 text-xs mt-1">Создан: {new Date(key.createdAt).toLocaleString()}</p>
                      {key.lastUsed && <p className="text-gray-500 text-xs">Последнее использование: {new Date(key.lastUsed).toLocaleString()}</p>}
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => copyToClipboard(key.key, key.id)} className="p-2 rounded-lg hover:bg-gray-700">
                        {copiedKey === key.id ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4 text-gray-500" />}
                      </button>
                      <button onClick={() => deleteApiKey(key.id)} className="p-2 rounded-lg hover:bg-red-500/20">
                        <Trash2 className="w-4 h-4 text-gray-500 hover:text-red-500" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="mt-6 bg-blue-500/10 border border-blue-500/50 rounded-xl p-4">
            <p className="text-blue-400 text-sm">📘 Как использовать API-ключ?</p>
            <p className="text-gray-400 text-xs mt-1">
              Передавайте ключ в заголовке <code className="bg-gray-800 px-1 rounded">X-API-Key</code> при запросе к <code className="bg-gray-800 px-1 rounded">/api/merchant/create-order</code>
            </p>
          </div>
        </div>
      )}

      {/* Create API Key Modal */}
      {showCreateKeyModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={() => setShowCreateKeyModal(false)}>
          <div className="bg-[#0f0f0f] rounded-2xl p-6 w-full max-w-md border border-[#D4AF37]/20" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-bold text-white mb-4">Создать API-ключ</h2>
            <input
              type="text"
              value={newKeyName}
              onChange={(e) => setNewKeyName(e.target.value)}
              placeholder="Название ключа (например, Магазин №1)"
              className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white mb-4"
              autoFocus
            />
            <div className="flex gap-3">
              <button onClick={() => setShowCreateKeyModal(false)} className="flex-1 py-2 bg-gray-800 text-white rounded-lg">Отмена</button>
              <button onClick={createApiKey} className="flex-1 py-2 bg-[#D4AF37] text-black rounded-lg font-bold">Создать</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
