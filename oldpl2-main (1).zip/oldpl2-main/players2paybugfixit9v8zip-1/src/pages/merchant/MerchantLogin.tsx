import { useState } from "react";
import { useLocation } from "wouter";

export default function MerchantLogin() {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [, navigate] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ login, password, token }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Ошибка входа");

      if (data.requiresTwoFactor) {
        // Здесь можно добавить 2FA, пока просто ошибка
        setError("2FA требуется. Используйте основную страницу входа.");
        setLoading(false);
        return;
      }

      localStorage.setItem("sessionToken", data.sessionToken);
      localStorage.setItem("userRole", data.role);
      navigate("/merchant/dashboard");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <div className="glass-premium rounded-2xl p-8 w-full max-w-md">
        <h1 className="text-2xl font-bold font-mono text-white mb-6 text-center">Вход для мерчантов</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            placeholder="Логин"
            value={login}
            onChange={e => setLogin(e.target.value)}
            className="w-full bg-gray-800 text-white rounded-lg px-4 py-3 outline-none border border-gray-700 focus:border-[#D4AF37]"
            required
          />
          <input
            type="password"
            placeholder="Пароль"
            value={password}
            onChange={e => setPassword(e.target.value)}
            className="w-full bg-gray-800 text-white rounded-lg px-4 py-3 outline-none border border-gray-700 focus:border-[#D4AF37]"
            required
          />
          <input
            type="text"
            placeholder="Токен доступа"
            value={token}
            onChange={e => setToken(e.target.value)}
            className="w-full bg-gray-800 text-white rounded-lg px-4 py-3 outline-none border border-gray-700 focus:border-[#D4AF37] font-mono"
            required
          />
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full gradient-btn py-3 rounded-lg font-bold disabled:opacity-50"
          >
            {loading ? "Проверка..." : "Войти"}
          </button>
        </form>
      </div>
    </div>
  );
}
