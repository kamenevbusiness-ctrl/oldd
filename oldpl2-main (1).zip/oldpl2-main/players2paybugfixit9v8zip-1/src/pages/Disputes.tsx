import { useState, useEffect, useCallback } from "react";
import { AppLayout } from "@/components/AppLayout";
import { 
  AlertTriangle, Clock, CheckCircle, XCircle, 
  Search, Eye, Volume2, VolumeX
} from "lucide-react";

interface Dispute {
  id: string;
  orderId: string;
  amount: number;
  currency: string;
  cardLast4: string;
  cardBank: string;
  customerName: string;
  reason: string;
  createdAt: string;
  timeLeft: number;
  status: "pending" | "resolved_trader" | "resolved_client";
  resolution?: string;
}

export default function Disputes() {
  const [disputes, setDisputes] = useState<Dispute[]>([]);
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"pending" | "history">("pending");
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [selectedDispute, setSelectedDispute] = useState<Dispute | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [resolving, setResolving] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [newDisputeAlert, setNewDisputeAlert] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("sessionToken");
    if (token) setSessionToken(token);
  }, []);

  const playSound = (type: "newDispute" | "timeout" | "resolved") => {
    if (!soundEnabled) return;
    const audio = new Audio();
    if (type === "newDispute") {
      audio.src = "https://www.soundjay.com/misc/sounds/bell-ringing-05.mp3";
    } else if (type === "timeout") {
      audio.src = "https://www.soundjay.com/misc/sounds/failed-01.mp3";
    } else {
      audio.src = "https://www.soundjay.com/misc/sounds/approved-01.mp3";
    }
    audio.volume = 0.5;
    audio.play().catch(e => console.log("Audio play failed", e));
  };

  const fetchDisputes = useCallback(async () => {
    if (!sessionToken) {
      setLoading(false);
      return;
    }
    try {
      const res = await fetch(`/api/disputes?status=${activeTab}`, {
        headers: { "x-session-token": sessionToken }
      });
      const data = await res.json();
      setDisputes(Array.isArray(data) ? data : []);
      
      // Проверка новых споров
      const pendingCount = data.filter((d: Dispute) => d.status === "pending").length;
      if (pendingCount > 0 && soundEnabled) {
        setNewDisputeAlert(true);
        playSound("newDispute");
        setTimeout(() => setNewDisputeAlert(false), 5000);
      }
    } catch (err) {
      console.error(err);
      setDisputes([]);
    } finally {
      setLoading(false);
    }
  }, [sessionToken, activeTab, soundEnabled]);

  useEffect(() => {
    fetchDisputes();
    const interval = setInterval(fetchDisputes, 30000);
    return () => clearInterval(interval);
  }, [fetchDisputes]);

  // Таймер обратного отсчёта (обновляется каждую секунду)
  useEffect(() => {
    const timer = setInterval(() => {
      setDisputes(prev => prev.map(dispute => {
        if (dispute.status !== "pending") return dispute;
        const newTimeLeft = dispute.timeLeft - 1;
        if (newTimeLeft <= 0) {
          playSound("timeout");
          return { 
            ...dispute, 
            status: "resolved_client", 
            timeLeft: 0,
            resolution: "Автоматически решён в пользу клиента по истечении 15 минут"
          };
        }
        return { ...dispute, timeLeft: newTimeLeft };
      }));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const resolveForClient = async (disputeId: string, amount: number, currency: string) => {
    setResolving(true);
    try {
      const res = await fetch("/api/disputes/resolve", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-session-token": sessionToken || "" },
        body: JSON.stringify({ disputeId, inFavorOf: "client" })
      });
      if (res.ok) {
        playSound("resolved");
        fetchDisputes();
        setShowDetails(false);
        alert(`Спор закрыт в пользу клиента. Сумма ${amount} ${currency} списана с вашего баланса.`);
      } else {
        alert("Ошибка при закрытии спора");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setResolving(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  const filteredDisputes = disputes.filter(d =>
    d.orderId.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.customerName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const pendingCount = disputes.filter(d => d.status === "pending").length;

  if (loading) {
    return (
      <AppLayout>
        <div className="p-6 text-white">Загрузка...</div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-4 p-4 md:p-6">
        <div className="flex justify-between items-center gap-3">
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-white font-mono flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 md:w-6 md:h-6 text-[#D4AF37]" />
              Апелляции
              {pendingCount > 0 && (
                <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                  {pendingCount}
                </span>
              )}
            </h1>
            <p className="text-gray-500 text-xs md:text-sm mt-0.5">
              На решение апелляции даётся 15 минут. При проигрыше сумма списывается с баланса.
            </p>
          </div>
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-2 rounded-lg transition-colors ${soundEnabled ? "bg-[#D4AF37]/20 text-[#D4AF37]" : "bg-gray-800 text-gray-500"}`}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>

        {newDisputeAlert && (
          <div className="bg-red-500/20 border border-red-500 rounded-lg p-3 animate-pulse">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-500" />
              <span className="text-white text-sm">Новая апелляция! Требуется внимание.</span>
            </div>
          </div>
        )}

        <div className="flex gap-2 border-b border-gray-800">
          <button
            onClick={() => setActiveTab("pending")}
            className={`px-4 py-2 text-sm font-medium transition-all ${activeTab === "pending" ? "text-[#D4AF37] border-b-2 border-[#D4AF37]" : "text-gray-500 hover:text-gray-300"}`}
          >
            Активные
            {pendingCount > 0 && (
              <span className="ml-2 bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded-full">
                {pendingCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab("history")}
            className={`px-4 py-2 text-sm font-medium transition-all ${activeTab === "history" ? "text-[#D4AF37] border-b-2 border-[#D4AF37]" : "text-gray-500 hover:text-gray-300"}`}
          >
            История
          </button>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Поиск по ID заказа, плательщику..."
            className="pl-9 pr-4 py-2.5 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm w-full focus:outline-none focus:border-[#D4AF37]"
          />
        </div>

        <div className="space-y-2">
          {filteredDisputes.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">Нет апелляций</p>
            </div>
          ) : (
            filteredDisputes.map((dispute) => (
              <div
                key={dispute.id}
                className={`bg-[#0f0f0f] rounded-xl border p-3 md:p-4 transition-all ${
                  dispute.status === "pending" 
                    ? "border-yellow-500/50 hover:border-[#D4AF37]/30" 
                    : dispute.status === "resolved_trader" 
                      ? "border-green-500/30" 
                      : "border-red-500/30"
                }`}
              >
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className={`w-2 h-2 rounded-full ${
                      dispute.status === "pending" ? "bg-yellow-500 animate-pulse" :
                      dispute.status === "resolved_trader" ? "bg-green-500" : "bg-red-500"
                    }`} />
                    <div>
                      <p className="text-white font-mono text-sm">{dispute.orderId}</p>
                      <p className="text-gray-500 text-xs hidden md:block">
                        {dispute.customerName} • {dispute.cardBank} ••{dispute.cardLast4}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <p className="text-white font-bold text-sm">{dispute.amount} {dispute.currency}</p>
                      <p className="text-gray-500 text-xs hidden sm:block">{formatDate(dispute.createdAt)}</p>
                    </div>
                    {dispute.status === "pending" && (
                      <div className="bg-yellow-500/20 text-yellow-500 text-xs px-2 py-1 rounded-full flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatTime(dispute.timeLeft)}
                      </div>
                    )}
                    {dispute.status === "resolved_trader" && (
                      <div className="bg-green-500/20 text-green-500 text-xs px-2 py-1 rounded-full hidden sm:block">
                        Решён в пользу трейдера
                      </div>
                    )}
                    {dispute.status === "resolved_client" && (
                      <div className="bg-red-500/20 text-red-500 text-xs px-2 py-1 rounded-full hidden sm:block">
                        Решён в пользу клиента
                      </div>
                    )}
                    <button
                      onClick={() => {
                        setSelectedDispute(dispute);
                        setShowDetails(true);
                      }}
                      className="p-1.5 hover:bg-gray-800 rounded-lg transition-colors"
                    >
                      <Eye className="w-4 h-4 text-gray-500 hover:text-[#D4AF37]" />
                    </button>
                  </div>
                </div>
                
                {/* Mobile additional info */}
                <div className="sm:hidden flex justify-between items-center mt-2 pt-2 border-t border-gray-800/50">
                  <p className="text-gray-500 text-xs">{dispute.customerName} • {dispute.cardBank} ••{dispute.cardLast4}</p>
                  {dispute.status === "resolved_trader" && (
                    <span className="text-green-500 text-xs">Решён в пользу трейдера</span>
                  )}
                  {dispute.status === "resolved_client" && (
                    <span className="text-red-500 text-xs">Решён в пользу клиента</span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {showDetails && selectedDispute && (
          <div className="fixed inset-0 bg-black/80 flex items-end sm:items-center justify-center z-50 p-0 sm:p-4" onClick={() => setShowDetails(false)}>
            <div className="bg-[#0f0f0f] rounded-t-2xl sm:rounded-2xl p-6 w-full sm:max-w-md border border-[#D4AF37]/20 max-h-[85vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
              <div className="w-10 h-1 bg-gray-700 rounded-full mx-auto mb-4 sm:hidden" />
              <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-[#D4AF37]" />
                Детали апелляции
              </h2>
              <div className="space-y-3">
                <div className="flex justify-between"><span className="text-gray-500">Заказ:</span><span className="text-white font-mono">{selectedDispute.orderId}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Сумма:</span><span className="text-white font-bold">{selectedDispute.amount} {selectedDispute.currency}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Карта:</span><span className="text-white">{selectedDispute.cardBank} ••{selectedDispute.cardLast4}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Плательщик:</span><span className="text-white">{selectedDispute.customerName}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Создана:</span><span className="text-white">{formatDate(selectedDispute.createdAt)}</span></div>
                {selectedDispute.status === "pending" && (
                  <div className="flex justify-between"><span className="text-gray-500">Осталось:</span><span className="text-yellow-500 font-mono">{formatTime(selectedDispute.timeLeft)}</span></div>
                )}
                <div className="border-t border-gray-800 pt-2">
                  <p className="text-gray-500 text-sm mb-1">Причина:</p>
                  <p className="text-white text-sm">{selectedDispute.reason}</p>
                </div>
                {selectedDispute.resolution && (
                  <div className="border-t border-gray-800 pt-2">
                    <p className="text-gray-500 text-sm mb-1">Решение:</p>
                    <p className="text-white text-sm">{selectedDispute.resolution}</p>
                  </div>
                )}
              </div>
              {selectedDispute.status === "pending" && (
                <button
                  onClick={() => resolveForClient(selectedDispute.id, selectedDispute.amount, selectedDispute.currency)}
                  disabled={resolving}
                  className="w-full mt-6 py-3 bg-red-500/20 text-red-500 rounded-lg font-bold hover:bg-red-500/30 transition-colors"
                >
                  {resolving ? "Обработка..." : "Закрыть в пользу клиента"}
                </button>
              )}
              <button onClick={() => setShowDetails(false)} className="w-full mt-3 py-3 bg-gray-800 text-white rounded-lg font-bold">Закрыть</button>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
