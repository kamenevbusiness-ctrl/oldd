import { useState } from "react";
import { AppLayout } from "@/components/AppLayout";
import { Copy, Check, Coins, TrendingUp } from "lucide-react";

const USDT_TO_RUB_RATE = 85;
const MIN_DEPOSIT_USDT = 50;

export default function PaymentMethods() {
  const [amountUSDT, setAmountUSDT] = useState("");
  const [loading, setLoading] = useState(false);
  const [showWallet, setShowWallet] = useState(false);
  const [copied, setCopied] = useState(false);

  const usdtWallet = "TX5RqLHJbXkLrsrG6YoXkzPRLgfMsVcQKh"; // Замени на свой кошелёк

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const amount = parseFloat(amountUSDT);
    if (isNaN(amount) || amount < MIN_DEPOSIT_USDT) {
      alert(`Минимальная сумма пополнения ${MIN_DEPOSIT_USDT} USDT`);
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setShowWallet(true);
      setLoading(false);
    }, 1000);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const rubAmount = parseFloat(amountUSDT) * USDT_TO_RUB_RATE;
  const formattedRubAmount = isNaN(rubAmount) ? 0 : rubAmount.toLocaleString();

  return (
    <AppLayout>
      <div className="space-y-6 p-6">
        <div className="border-b border-gray-800 pb-4">
          <h1 className="text-2xl font-bold tracking-tight font-mono text-white flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-[#D4AF37]" />
            Пополнение баланса
          </h1>
          <p className="text-sm text-gray-400 mt-1">
            Пополнение через USDT TRC-20. Курс: 1 USDT = {USDT_TO_RUB_RATE} ₽
          </p>
        </div>

        <div className="glass-premium rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 rounded-lg bg-[#D4AF37]/10">
              <Coins className="w-6 h-6 text-[#D4AF37]" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">USDT (TRC-20)</h2>
              <p className="text-xs text-gray-400">Пополнение через USDT в сети TRC-20</p>
            </div>
          </div>

          {!showWallet ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Сумма пополнения (USDT)
                </label>
                <input
                  type="number"
                  value={amountUSDT}
                  onChange={(e) => setAmountUSDT(e.target.value)}
                  placeholder={`Минимум ${MIN_DEPOSIT_USDT} USDT`}
                  min={MIN_DEPOSIT_USDT}
                  step={1}
                  className="w-full px-4 py-3 bg-gray-900 border border-gray-700 rounded-lg text-white placeholder:text-gray-500 focus:outline-none focus:border-[#D4AF37] transition-colors"
                  required
                />
                {amountUSDT && parseFloat(amountUSDT) >= MIN_DEPOSIT_USDT && (
                  <div className="mt-2 p-2 bg-[#D4AF37]/10 rounded-lg">
                    <p className="text-sm text-gray-300">
                      Вы получите: <span className="text-[#D4AF37] font-bold">{formattedRubAmount} ₽</span>
                    </p>
                    <p className="text-xs text-gray-500">Курс: 1 USDT = {USDT_TO_RUB_RATE} ₽</p>
                  </div>
                )}
                <p className="text-xs text-gray-500 mt-1">
                  Минимальная сумма: {MIN_DEPOSIT_USDT} USDT | Максимальная: 10 000 USDT
                </p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-[#D4AF37] text-black font-bold rounded-lg hover:bg-[#FFD700] transition-colors disabled:opacity-50"
              >
                {loading ? "Обработка..." : "Продолжить"}
              </button>
            </form>
          ) : (
            <div className="space-y-4">
              <div className="p-4 bg-green-500/10 border border-green-500 rounded-lg">
                <p className="text-green-400 text-sm text-center">
                  ✅ Заявка на пополнение создана!
                </p>
                <p className="text-gray-400 text-xs text-center mt-1">
                  Сумма к зачислению: <span className="text-[#D4AF37] font-bold">{formattedRubAmount} ₽</span>
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Кошелёк для перевода (USDT TRC-20)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={usdtWallet}
                    readOnly
                    className="flex-1 px-4 py-3 bg-gray-900 border border-gray-700 rounded-lg text-white font-mono text-sm"
                  />
                  <button
                    onClick={() => copyToClipboard(usdtWallet)}
                    className="p-3 rounded-lg bg-gray-800 text-[#D4AF37] hover:bg-gray-700 transition-colors"
                  >
                    {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Отправьте <span className="text-[#D4AF37] font-bold">{amountUSDT} USDT</span> на указанный кошелёк.
                  После получения баланс пополнится автоматически.
                </p>
              </div>

              <div className="p-3 bg-yellow-500/10 border border-yellow-500/50 rounded-lg">
                <p className="text-yellow-400 text-xs">
                  ⚠️ Отправляйте ТОЛЬКО USDT (TRC-20). Переводы в других сетях приведут к потере средств.
                </p>
              </div>

              <button
                onClick={() => { setShowWallet(false); setAmountUSDT(""); }}
                className="w-full py-2 text-gray-500 hover:text-gray-300 text-sm transition-colors"
              >
                ← Новая заявка
              </button>
            </div>
          )}
        </div>

        <div className="glass-premium rounded-xl p-4">
          <h3 className="text-sm font-semibold text-white mb-2">📈 Курс конвертации</h3>
          <p className="text-xs text-gray-400">
            Актуальный курс: <span className="text-[#D4AF37]">1 USDT = {USDT_TO_RUB_RATE} ₽</span>
          </p>
        </div>
      </div>
    </AppLayout>
  );
}
