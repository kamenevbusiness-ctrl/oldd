import { useState } from "react";
import { AppLayout } from "@/components/AppLayout";
import {
  CreditCard,
  Plus, Trash2, Search, Clock,
  DollarSign, X
} from "lucide-react";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useToast } from "@/components/Toast";
import { usePlatformStore } from "@/context/PlatformStore";
import type { Rekvizit } from "@/context/PlatformStore";

const methodTypes = [
  { value: "card",       label: "Карты РФ",            icon: "💳", color: "bg-blue-500/10",   borderColor: "border-blue-500/30" },
  { value: "card_tj",    label: "Карты Таджикистан",    icon: "🇹🇯", color: "bg-red-500/10",    borderColor: "border-red-500/30" },
  { value: "card_uz",    label: "Карты Узбекистан",     icon: "🇺🇿", color: "bg-green-500/10",  borderColor: "border-green-500/30" },
  { value: "card_kz",    label: "Карты Казахстан",      icon: "🇰🇿", color: "bg-blue-500/10",   borderColor: "border-blue-500/30" },
  { value: "card_ge",    label: "Карты Грузия",         icon: "🇬🇪", color: "bg-red-500/10",    borderColor: "border-red-500/30" },
  { value: "card_kg",    label: "Карты Киргизия",       icon: "🇰🇬", color: "bg-green-500/10",  borderColor: "border-green-500/30" },
  { value: "card_am",    label: "Карты Армения",        icon: "🇦🇲", color: "bg-purple-500/10", borderColor: "border-purple-500/30" },
  { value: "card_ar",    label: "Карты Аргентина",      icon: "🇦🇷", color: "bg-sky-500/10",    borderColor: "border-sky-500/30" },
  { value: "sbp",        label: "СБП",                  icon: "🔵", color: "bg-blue-500/10",   borderColor: "border-blue-500/30" },
  { value: "mobile",     label: "Мобильная коммерция",  icon: "📱", color: "bg-purple-500/10", borderColor: "border-purple-500/30" },
  { value: "collection", label: "Сбор",                 icon: "🎯", color: "bg-yellow-500/10", borderColor: "border-yellow-500/30" },
  { value: "bt",         label: "Белые треугольники (P2P)", icon: "🔄", color: "bg-indigo-500/10", borderColor: "border-indigo-500/30" },
];

// Банки РФ для карт
const russianBanks = ["Сбербанк","Тинькофф","Альфа-Банк","ВТБ","Газпромбанк","Райффайзенбанк","Россельхозбанк","Открытие","МКБ","Совкомбанк","Промсвязьбанк","Почта Банк","Юникредит","Росбанк","Хоум Кредит","Банк Санкт-Петербург","Абсолют Банк","МТС-Банк","Уралсиб","Зенит","ДОМ.РФ","РНКБ","Экспобанк","Локо-Банк","СДМ-Банк"];

// Банки для СБП
const sbpBanks = ["Сбербанк","Тинькофф","Альфа-Банк","ВТБ","Газпромбанк","Райффайзенбанк","Россельхозбанк","Открытие","МКБ","Совкомбанк","Промсвязьбанк","Почта Банк","МТС-Банк","Уралсиб","Росбанк"];

// Банки для сборов
const collectionBanks = ["Сбербанк","Тинькофф","Альфа-Банк","ВТБ","Газпромбанк","Райффайзенбанк","Россельхозбанк"];

// Банки Таджикистана
const tajikBanks = ["Амонатбонк","Эсхата","Ориёнбанк","Таджиксодиротбанк","Халкбонк","Банк Арванд","ТЧ-Банк","Корти Милли","Душанбе Сити"];

// Банки Узбекистана
const uzbekBanks = ["Humo","Uzcard","Kapitalbank","Hamkorbank","Ipak Yuli","Asaka Bank","Xalq Banki"];

// Банки Казахстана
const kazakhBanks = ["Kaspi Bank","Halyk Bank","Jusan Bank","ForteBank","Bank RBK","Altyn Bank","Home Credit Bank"];

// Банки Грузии
const georgiaBanks = ["TBC Bank","Bank of Georgia","Credo Bank","Liberty Bank","Cartu Bank","Basis Bank"];

// Банки Киргизии
const kyrgyzBanks = ["РСК Банк","Айыл Банк","Банк Азии","Кыргызстан Банк","Демир Банк","КИКБ"];

// Банки Армении
const armeniaBanks = ["Ameriabank","Ardshinbank","Inecobank","Converse Bank","ACBA Bank","Armbusinessbank"];

// Банки Аргентины
const argentinaBanks = ["BBVA Argentina","Banco Galicia","Banco Macro","Santander Argentina","ICBC Argentina","Supervielle","Brubank","Rebanking","Wilobank","Banco Ciudad"];

// Мобильные операторы
const mobileOperators = ["МТС","Билайн","МегаФон","Теле2","Yota","Билайн Таджикистан","МегаФон Таджикистан","Ucell (Узбекистан)"];

export default function MyCards() {
  const toast = useToast();
  const { cards: rekvizits, setCards: setRekvizits } = usePlatformStore();
  const [showModal, setShowModal] = useState(false);
  const [selectedType, setSelectedType] = useState("card");
  const [searchQuery, setSearchQuery] = useState("");
  const [error, setError] = useState("");
  const [step, setStep] = useState(1);

  const [deleteConfirm, setDeleteConfirm] = useState<{ open: boolean; id: number; name: string }>({
    open: false, id: 0, name: ""
  });

  const [newRekvizit, setNewRekvizit] = useState({
    type: "card", currency: "RUB", bank: "", sbpBank: "", collectionBank: "",
    phone: "", operator: "", cardNumber: "", holderName: "", collectionId: "",
    minAmount: 100, maxAmount: 100000, dailyLimit: 100000,
    minuteLimit: 5, intervalMin: 30, intervalMax: 60,
    scheduleEnabled: false, scheduleStart: "00:00", scheduleEnd: "23:59"
  });

  const handleAdd = () => { setShowModal(true); setStep(1); setError(""); };

  const nextStep = () => {
    if (step === 1 && !selectedType) { setError("Выберите тип метода"); return; }
    if (step === 2) {
      if ((selectedType === "card" || selectedType === "card_tj" || selectedType === "card_uz" || selectedType === "card_kz" || selectedType === "card_ge" || selectedType === "card_kg" || selectedType === "card_am" || selectedType === "card_ar") && (!newRekvizit.bank || !newRekvizit.cardNumber || !newRekvizit.holderName)) {
        setError("Заполните все поля карты"); return;
      }
      if (selectedType === "sbp" && (!newRekvizit.phone || !newRekvizit.sbpBank)) { setError("Выберите банк и введите номер телефона"); return; }
      if (selectedType === "mobile" && (!newRekvizit.operator || !newRekvizit.phone)) { setError("Выберите оператора и введите номер"); return; }
      if (selectedType === "collection" && (!newRekvizit.collectionId || !newRekvizit.collectionBank)) { setError("Введите номер сбора и выберите банк"); return; }
      if (selectedType === "bt" && !newRekvizit.phone) { setError("Введите номер телефона для P2P"); return; }
    }
    setError("");
    setStep(step + 1);
  };

  const prevStep = () => { setStep(step - 1); setError(""); };

  const getBankListForType = (type: string) => {
    if (type === "card_tj") return tajikBanks;
    if (type === "card_uz") return uzbekBanks;
    if (type === "card_kz") return kazakhBanks;
    if (type === "card_ge") return georgiaBanks;
    if (type === "card_kg") return kyrgyzBanks;
    if (type === "card_am") return armeniaBanks;
    if (type === "card_ar") return argentinaBanks;
    return russianBanks;
  };

  const saveRekvizit = () => {
    const newId = Math.max(0, ...rekvizits.map(r => r.id)) + 1;
    let details = "", name = "", icon = "";
    
    if (selectedType === "card" || selectedType === "card_tj" || selectedType === "card_uz" || selectedType === "card_kz" || selectedType === "card_ge" || selectedType === "card_kg" || selectedType === "card_am" || selectedType === "card_ar") {
      name = newRekvizit.bank;
      details = `****${newRekvizit.cardNumber.slice(-4)}`;
      const countryMap: Record<string, string> = {
        card_tj: "🇹🇯", card_uz: "🇺🇿", card_kz: "🇰🇿", card_ge: "🇬🇪",
        card_kg: "🇰🇬", card_am: "🇦🇲", card_ar: "🇦🇷"
      };
      icon = countryMap[selectedType] || "💳";
    } else if (selectedType === "sbp") {
      name = `СБП • ${newRekvizit.sbpBank}`;
      details = newRekvizit.phone;
      icon = "🔵";
    } else if (selectedType === "collection") {
      name = `Сбор • ${newRekvizit.collectionBank}`;
      details = `Сбор #${newRekvizit.collectionId}`;
      icon = "🎯";
    } else if (selectedType === "mobile") {
      name = newRekvizit.operator;
      details = newRekvizit.phone;
      icon = "📱";
    } else if (selectedType === "bt") {
      name = "Белые треугольники (P2P)";
      details = newRekvizit.phone;
      icon = "🔄";
    }

    const newItem: Rekvizit = {
      id: newId, type: selectedType as any, name, details, icon,
      currency: newRekvizit.currency as any,
      minAmount: newRekvizit.minAmount, maxAmount: newRekvizit.maxAmount,
      dailyLimit: newRekvizit.dailyLimit, usedDaily: 0,
      minuteLimit: newRekvizit.minuteLimit,
      intervalMin: newRekvizit.intervalMin, intervalMax: newRekvizit.intervalMax,
      scheduleEnabled: newRekvizit.scheduleEnabled,
      scheduleStart: newRekvizit.scheduleStart, scheduleEnd: newRekvizit.scheduleEnd,
      isActive: true,
      cardNumber: newRekvizit.cardNumber, holderName: newRekvizit.holderName,
      phone: newRekvizit.phone, collectionId: newRekvizit.collectionId,
      collectionBank: newRekvizit.collectionBank, operator: newRekvizit.operator, bank: newRekvizit.bank, sbpBank: newRekvizit.sbpBank,
    };

    setRekvizits([...rekvizits, newItem]);
    setShowModal(false);
    setStep(1);
    setNewRekvizit({
      type: "card", currency: "RUB", bank: "", sbpBank: "", collectionBank: "",
      phone: "", operator: "", cardNumber: "", holderName: "", collectionId: "",
      minAmount: 100, maxAmount: 100000, dailyLimit: 100000,
      minuteLimit: 5, intervalMin: 30, intervalMax: 60,
      scheduleEnabled: false, scheduleStart: "00:00", scheduleEnd: "23:59"
    });
    toast.success("Реквизит добавлен", `${name} готов к приёму платежей`);
  };

  const toggleActive = (id: number) => {
    const item = rekvizits.find(r => r.id === id);
    if (!item) return;
    const willBeActive = !item.isActive;
    setRekvizits(rekvizits.map(r => r.id === id ? { ...r, isActive: willBeActive } : r));
    if (willBeActive) {
      toast.success("Реквизит активирован", `${item.name} принимает платежи`);
    } else {
      toast.warning("Реквизит остановлен", `${item.name} не принимает платежи`);
    }
  };

  const requestDelete = (item: Rekvizit) => {
    setDeleteConfirm({ open: true, id: item.id, name: item.name });
  };

  const confirmDelete = () => {
    const name = deleteConfirm.name;
    setRekvizits(rekvizits.filter(r => r.id !== deleteConfirm.id));
    setDeleteConfirm({ open: false, id: 0, name: "" });
    toast.error("Реквизит удалён", `${name} удалён из системы`);
  };

  const getUsagePercent = (used: number, total: number) => Math.min(100, (used / total) * 100);

  const getTypeName = (type: string) => {
    const found = methodTypes.find(m => m.value === type);
    return found?.label ?? type;
  };

  const filteredRekvizits = rekvizits.filter(r =>
    !searchQuery || r.name.toLowerCase().includes(searchQuery.toLowerCase()) || r.details.includes(searchQuery)
  );

  const inputCls = "w-full px-4 py-2.5 bg-[#1a1a1a] border border-gray-700 rounded-xl text-white focus:outline-none focus:border-[#D4AF37] transition-colors text-sm";
  const selectCls = "w-full px-4 py-2.5 bg-[#1a1a1a] border border-gray-700 rounded-xl text-white focus:outline-none focus:border-[#D4AF37] transition-colors text-sm";
  const labelCls = "block text-xs text-gray-400 uppercase tracking-wider mb-1.5 font-mono";

  return (
    <AppLayout>
      <div className="space-y-4 p-4 md:p-6">

        {/* Header */}
        <div className="flex justify-between items-center gap-3">
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-white font-mono">Реквизиты</h1>
            <p className="text-gray-500 text-xs md:text-sm mt-0.5">Управление методами приёма платежей</p>
          </div>
          <button
            onClick={handleAdd}
            className="flex items-center gap-1.5 px-3 md:px-4 py-2 bg-[#D4AF37] text-black rounded-lg font-bold hover:bg-[#c4a030] transition-colors text-sm flex-shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Добавить реквизит</span>
            <span className="sm:hidden">Добавить</span>
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Поиск реквизитов..."
            className="w-full pl-9 pr-4 py-2 bg-[#0f0f0f] border border-gray-800 rounded-lg text-white text-sm focus:outline-none focus:border-[#D4AF37]"
          />
        </div>

        {/* Rekvizit list */}
        <div className="space-y-3">
          {filteredRekvizits.map((item) => (
            <div
              key={item.id}
              className={`bg-[#0f0f0f] rounded-xl border ${item.isActive ? "border-[#D4AF37]/25" : "border-gray-800"} p-4 transition-all hover:border-[#D4AF37]/40`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 flex items-center justify-center text-xl flex-shrink-0">
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="text-white font-semibold">{item.name}</h3>
                    <p className="text-gray-500 text-xs">{getTypeName(item.type)} &bull; {item.details}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => toggleActive(item.id)}
                    className={`px-2.5 py-1 text-[10px] font-mono rounded-lg border transition-all ${
                      item.isActive
                        ? "bg-green-500/10 border-green-500/30 text-green-400 hover:bg-green-500/20"
                        : "bg-red-500/10 border-red-500/30 text-red-400 hover:bg-red-500/20"
                    }`}
                  >
                    {item.isActive ? "Активен" : "Неактивен"}
                  </button>
                  <button
                    onClick={() => requestDelete(item)}
                    className="p-1.5 hover:bg-red-500/10 rounded-lg transition-colors text-gray-500 hover:text-red-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs mb-3">
                <div className="bg-black/40 rounded-lg p-2.5">
                  <p className="text-gray-500 mb-0.5 flex items-center gap-1"><DollarSign className="w-3 h-3" /> Лимит суммы</p>
                  <p className="text-white font-mono">{item.minAmount.toLocaleString()} – {item.maxAmount.toLocaleString()} ₽</p>
                </div>
                <div className="bg-black/40 rounded-lg p-2.5">
                  <p className="text-gray-500 mb-0.5">Дневной лимит</p>
                  <p className="text-white font-mono">{item.dailyLimit.toLocaleString()} ₽</p>
                </div>
                <div className="bg-black/40 rounded-lg p-2.5">
                  <p className="text-gray-500 mb-0.5">Платежей/мин</p>
                  <p className="text-white font-mono">{item.minuteLimit}</p>
                </div>
                <div className="bg-black/40 rounded-lg p-2.5">
                  <p className="text-gray-500 mb-0.5">Интервал</p>
                  <p className="text-white font-mono">{item.intervalMin}–{item.intervalMax} сек</p>
                </div>
              </div>

              {item.scheduleEnabled && (
                <div className="flex items-center gap-2 text-xs text-gray-400 mb-3 bg-black/30 rounded-lg px-3 py-1.5">
                  <Clock className="w-3 h-3 text-[#D4AF37]" />
                  <span className="font-mono">Расписание: {item.scheduleStart} – {item.scheduleEnd}</span>
                </div>
              )}

              <div className="space-y-1">
                <div className="progress-bar h-1.5">
                  <div
                    className="progress-bar-fill h-full"
                    style={{
                      width: `${getUsagePercent(item.usedDaily, item.dailyLimit)}%`,
                      background: getUsagePercent(item.usedDaily, item.dailyLimit) > 80
                        ? "linear-gradient(90deg, #ef4444, #dc2626)"
                        : "linear-gradient(90deg, #D4AF37, #c4a030)"
                    }}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <p className="text-[10px] text-gray-600 font-mono">{item.usedDaily.toLocaleString()} / {item.dailyLimit.toLocaleString()} ₽</p>
                  <p className="text-[10px] text-gray-600 font-mono">{getUsagePercent(item.usedDaily, item.dailyLimit).toFixed(0)}%</p>
                </div>
              </div>
            </div>
          ))}

          {filteredRekvizits.length === 0 && (
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-2xl bg-gray-800/50 flex items-center justify-center mx-auto mb-4">
                <CreditCard className="w-8 h-8 text-gray-600" />
              </div>
              <p className="text-gray-400 font-medium">{searchQuery ? "Ничего не найдено" : "Нет реквизитов"}</p>
              {!searchQuery && (
                <button onClick={handleAdd} className="mt-3 px-4 py-2 bg-[#D4AF37] text-black rounded-lg text-sm font-bold hover:bg-[#c4a030] transition-colors">
                  Добавить первый реквизит
                </button>
              )}
            </div>
          )}
        </div>

        {/* Add modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={() => setShowModal(false)}>
            <div className="bg-[#0f0f0f] rounded-2xl p-6 w-full max-w-lg border border-[#D4AF37]/20 max-h-[90vh] overflow-y-auto shadow-2xl" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h2 className="text-xl font-bold text-white font-mono">Добавить реквизит</h2>
                  <p className="text-gray-500 text-xs mt-0.5">Шаг {step} из 3</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex gap-1.5">
                    {[1,2,3].map(s => (
                      <div key={s} className={`h-1.5 rounded-full transition-all ${step >= s ? "bg-[#D4AF37] w-6" : "bg-gray-700 w-3"}`} />
                    ))}
                  </div>
                  <button onClick={() => setShowModal(false)} className="text-gray-600 hover:text-gray-300 transition-colors">
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Step 1: Type */}
              {step === 1 && (
                <div>
                  <p className="text-gray-400 text-sm mb-4">Выберите тип метода для приёма платежей</p>
                  <div className="grid grid-cols-2 gap-3 mb-6">
                    {methodTypes.map((type) => (
                      <button
                        key={type.value}
                        onClick={() => setSelectedType(type.value)}
                        className={`p-4 rounded-xl text-center transition-all border ${
                          selectedType === type.value
                            ? `${type.color} border-[#D4AF37]`
                            : "bg-gray-800/50 border-gray-700 hover:border-gray-600"
                        }`}
                      >
                        <div className="text-3xl mb-2">{type.icon}</div>
                        <p className="text-white text-sm font-medium">{type.label}</p>
                      </button>
                    ))}
                  </div>
                  {error && <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2 mb-3">{error}</p>}
                  <button onClick={nextStep} className="w-full py-3 bg-[#D4AF37] text-black rounded-xl font-bold hover:bg-[#c4a030] transition-colors">Далее →</button>
                </div>
              )}

              {/* Step 2: Details */}
              {step === 2 && (
                <div className="space-y-3">
                  <p className="text-gray-400 text-sm mb-1">Введите реквизиты для приёма платежей</p>

                  {/* Карты (все страны) */}
                  {(selectedType === "card" || selectedType === "card_tj" || selectedType === "card_uz" || selectedType === "card_kz" || selectedType === "card_ge" || selectedType === "card_kg" || selectedType === "card_am" || selectedType === "card_ar") && (
                    <>
                      <div>
                        <label className={labelCls}>Банк</label>
                        <select value={newRekvizit.bank} onChange={(e) => setNewRekvizit({ ...newRekvizit, bank: e.target.value })} className={selectCls}>
                          <option value="">Выберите банк</option>
                          {getBankListForType(selectedType).map(bank => <option key={bank}>{bank}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className={labelCls}>Номер карты</label>
                        <input type="text" value={newRekvizit.cardNumber} onChange={(e) => setNewRekvizit({ ...newRekvizit, cardNumber: e.target.value })} placeholder="1234 5678 9012 3456" className={inputCls + " font-mono"} />
                      </div>
                      <div>
                        <label className={labelCls}>Держатель</label>
                        <input type="text" value={newRekvizit.holderName} onChange={(e) => setNewRekvizit({ ...newRekvizit, holderName: e.target.value })} placeholder="IVAN IVANOV" className={inputCls + " uppercase"} />
                      </div>
                    </>
                  )}

                  {/* СБП */}
                  {selectedType === "sbp" && (
                    <>
                      <div>
                        <label className={labelCls}>Банк СБП</label>
                        <select value={newRekvizit.sbpBank} onChange={(e) => setNewRekvizit({ ...newRekvizit, sbpBank: e.target.value })} className={selectCls}>
                          <option value="">Выберите банк</option>
                          {sbpBanks.map(bank => <option key={bank}>{bank}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className={labelCls}>Номер телефона</label>
                        <input type="tel" value={newRekvizit.phone} onChange={(e) => setNewRekvizit({ ...newRekvizit, phone: e.target.value })} placeholder="+7 999 123-45-67" className={inputCls} />
                      </div>
                    </>
                  )}

                  {/* Мобильная коммерция */}
                  {selectedType === "mobile" && (
                    <>
                      <div>
                        <label className={labelCls}>Оператор</label>
                        <select value={newRekvizit.operator} onChange={(e) => setNewRekvizit({ ...newRekvizit, operator: e.target.value })} className={selectCls}>
                          <option value="">Выберите оператора</option>
                          {mobileOperators.map(op => <option key={op}>{op}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className={labelCls}>Номер телефона</label>
                        <input type="tel" value={newRekvizit.phone} onChange={(e) => setNewRekvizit({ ...newRekvizit, phone: e.target.value })} placeholder="+7 999 123-45-67" className={inputCls} />
                      </div>
                    </>
                  )}

                  {/* Сборы */}
                  {selectedType === "collection" && (
                    <>
                      <div>
                        <label className={labelCls}>Банк для сбора</label>
                        <select value={newRekvizit.collectionBank} onChange={(e) => setNewRekvizit({ ...newRekvizit, collectionBank: e.target.value })} className={selectCls}>
                          <option value="">Выберите банк</option>
                          {collectionBanks.map(bank => <option key={bank}>{bank}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className={labelCls}>Номер сбора</label>
                        <input type="text" value={newRekvizit.collectionId} onChange={(e) => setNewRekvizit({ ...newRekvizit, collectionId: e.target.value })} placeholder="12345" className={inputCls} />
                        <p className="text-gray-600 text-xs mt-1">Мерчант переводит по номеру сбора, а не по карте</p>
                      </div>
                    </>
                  )}

                  {/* Белые треугольники (P2P) — без предупреждения */}
                  {selectedType === "bt" && (
                    <>
                      <div>
                        <label className={labelCls}>Номер телефона (P2P)</label>
                        <input type="tel" value={newRekvizit.phone} onChange={(e) => setNewRekvizit({ ...newRekvizit, phone: e.target.value })} placeholder="+7 999 123-45-67" className={inputCls} />
                      </div>
                    </>
                  )}

                  {/* Валюта */}
                  <div>
                    <label className={labelCls}>Валюта</label>
                    <select value={newRekvizit.currency} onChange={(e) => setNewRekvizit({ ...newRekvizit, currency: e.target.value })} className={selectCls}>
                      <option value="RUB">Рубли (RUB)</option>
                      <option value="USDT">USDT</option>
                      <option value="UZS">Узбекский сум (UZS)</option>
                      <option value="TJS">Таджикский сомони (TJS)</option>
                      <option value="KZT">Казахстанский тенге (KZT)</option>
                      <option value="GEL">Грузинский лари (GEL)</option>
                      <option value="KGS">Киргизский сом (KGS)</option>
                      <option value="AMD">Армянский драм (AMD)</option>
                      <option value="ARS">Аргентинский песо (ARS)</option>
                    </select>
                  </div>

                  {error && <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">{error}</p>}
                  <div className="flex gap-3 pt-1">
                    <button onClick={prevStep} className="flex-1 py-2.5 bg-gray-800 hover:bg-gray-700 text-white rounded-xl text-sm font-medium transition-colors">Назад</button>
                    <button onClick={nextStep} className="flex-1 py-2.5 bg-[#D4AF37] hover:bg-[#c4a030] text-black rounded-xl text-sm font-bold transition-colors">Далее →</button>
                  </div>
                </div>
              )}

              {/* Step 3: Limits */}
              {step === 3 && (
                <div className="space-y-3">
                  <p className="text-gray-400 text-sm mb-1">Настройте лимиты и расписание приёма</p>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className={labelCls}>Мин. сумма (₽)</label>
                      <input type="number" value={newRekvizit.minAmount} onChange={(e) => setNewRekvizit({ ...newRekvizit, minAmount: parseInt(e.target.value) || 0 })} className={inputCls} />
                    </div>
                    <div>
                      <label className={labelCls}>Макс. сумма (₽)</label>
                      <input type="number" value={newRekvizit.maxAmount} onChange={(e) => setNewRekvizit({ ...newRekvizit, maxAmount: parseInt(e.target.value) || 0 })} className={inputCls} />
                    </div>
                    <div>
                      <label className={labelCls}>Дневной лимит (₽)</label>
                      <input type="number" value={newRekvizit.dailyLimit} onChange={(e) => setNewRekvizit({ ...newRekvizit, dailyLimit: parseInt(e.target.value) || 0 })} className={inputCls} />
                    </div>
                    <div>
                      <label className={labelCls}>Платежей/мин</label>
                      <input type="number" value={newRekvizit.minuteLimit} onChange={(e) => setNewRekvizit({ ...newRekvizit, minuteLimit: parseInt(e.target.value) || 0 })} className={inputCls} />
                    </div>
                    <div>
                      <label className={labelCls}>Интервал мин (сек)</label>
                      <input type="number" value={newRekvizit.intervalMin} onChange={(e) => setNewRekvizit({ ...newRekvizit, intervalMin: parseInt(e.target.value) || 0 })} className={inputCls} />
                    </div>
                    <div>
                      <label className={labelCls}>Интервал макс (сек)</label>
                      <input type="number" value={newRekvizit.intervalMax} onChange={(e) => setNewRekvizit({ ...newRekvizit, intervalMax: parseInt(e.target.value) || 0 })} className={inputCls} />
                    </div>
                  </div>

                  {/* Расписание */}
                  <div className="bg-[#1a1a1a] rounded-xl p-3 border border-gray-700">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <div
                        onClick={() => setNewRekvizit({ ...newRekvizit, scheduleEnabled: !newRekvizit.scheduleEnabled })}
                        className={`w-10 h-5 rounded-full transition-all relative cursor-pointer flex-shrink-0 ${newRekvizit.scheduleEnabled ? "bg-[#D4AF37]" : "bg-gray-700"}`}
                      >
                        <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${newRekvizit.scheduleEnabled ? "left-5" : "left-0.5"}`} />
                      </div>
                      <span className="text-sm text-gray-300 select-none">Включить расписание</span>
                    </label>
                    {newRekvizit.scheduleEnabled && (
                      <div className="grid grid-cols-2 gap-3 mt-3">
                        <div>
                          <label className={labelCls}>Начало</label>
                          <input type="time" value={newRekvizit.scheduleStart} onChange={(e) => setNewRekvizit({ ...newRekvizit, scheduleStart: e.target.value })} className={inputCls} />
                        </div>
                        <div>
                          <label className={labelCls}>Конец</label>
                          <input type="time" value={newRekvizit.scheduleEnd} onChange={(e) => setNewRekvizit({ ...newRekvizit, scheduleEnd: e.target.value })} className={inputCls} />
                        </div>
                      </div>
                    )}
                  </div>

                  {error && <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">{error}</p>}
                  <div className="flex gap-3 pt-1">
                    <button onClick={prevStep} className="flex-1 py-2.5 bg-gray-800 hover:bg-gray-700 text-white rounded-xl text-sm font-medium transition-colors">Назад</button>
                    <button onClick={saveRekvizit} className="flex-1 py-2.5 bg-[#D4AF37] hover:bg-[#c4a030] text-black rounded-xl text-sm font-bold transition-colors">Сохранить</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Delete confirm */}
        <ConfirmDialog
          open={deleteConfirm.open}
          title="Удалить реквизит?"
          message={`Реквизит «${deleteConfirm.name}» будет безвозвратно удалён. Активные ордеры на этот реквизит могут быть затронуты.`}
          confirmText="Удалить"
          cancelText="Отмена"
          danger
          onConfirm={confirmDelete}
          onCancel={() => setDeleteConfirm({ open: false, id: 0, name: "" })}
        />
      </div>
    </AppLayout>
  );
}
