import { useState } from "react";
import { AppLayout } from "@/components/AppLayout";
import { Shield, CheckCircle, Key, Copy, Check } from "lucide-react";
import { useToast } from "@/components/Toast";

export default function Security() {
  const token = localStorage.getItem("sessionToken") || "";
  const [copied, setCopied] = useState(false);
  const toast = useToast();

  const handleCopy = () => {
    navigator.clipboard.writeText(token).then(() => {
      setCopied(true);
      toast.success("Скопировано", "Токен скопирован в буфер обмена");
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <AppLayout>
      <div className="p-6 max-w-2xl space-y-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white font-mono">Безопасность</h1>
          <p className="text-gray-500 text-sm mt-1">Защита вашего аккаунта</p>
        </div>

        <div className="bg-[#0f0f0f] border border-[#D4AF37]/20 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Key className="w-4 h-4 text-[#D4AF37]" />
            <p className="text-white font-semibold text-sm">Сессионный токен</p>
          </div>
          <p className="text-gray-500 text-xs mb-3">Ваш уникальный токен для входа в систему. Никому не передавайте.</p>
          <div className="flex items-center gap-3 bg-[#1a1a1a] border border-[#D4AF37]/20 rounded-lg px-4 py-3">
            <span className="font-mono text-sm text-gray-300 flex-1 truncate">{token || "—"}</span>
            <button
              onClick={handleCopy}
              className="text-gray-500 hover:text-[#D4AF37] transition-colors flex-shrink-0"
              title="Копировать токен"
            >
              {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
          <p className="text-gray-600 text-xs mt-3">Токен привязан к вашему аккаунту и используется для входа.</p>
        </div>

        <div className="space-y-4">
          {["Двухфакторная аутентификация", "Уведомления о входе", "Список доверенных устройств"].map((item) => (
            <div key={item} className="bg-[#0f0f0f] border border-gray-800 rounded-xl p-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-gray-500" />
                <span className="text-white text-sm">{item}</span>
              </div>
              <span className="text-gray-600 text-xs">В разработке</span>
            </div>
          ))}
          <div className="bg-[#0f0f0f] border border-green-500/20 rounded-xl p-5 flex items-center gap-3">
            <CheckCircle className="w-5 h-5 text-green-500" />
            <span className="text-green-400 text-sm">Токен-аутентификация активна</span>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
