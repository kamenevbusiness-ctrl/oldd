import { useState, useEffect, useCallback } from "react";
import {
  Shield, Users, BarChart2, Settings, Database, Server,
  LogOut, Plus, Trash2, Ban, CheckCircle, Edit2, Download,
  Upload, Globe, Eye, EyeOff, ChevronRight, Activity,
  CreditCard, AlertTriangle, DollarSign, Clock, Key,
  RefreshCw, Search, Filter, TrendingUp, Cpu, HardDrive,
  Lock, Unlock, FileText, X, Check, AlertCircle, Power
} from "lucide-react";

const OWNER_TOKEN_KEY = "ownerToken";

// ─── Helpers ───────────────────────────────────────────────────────────────

function apiFetch(path: string, opts?: RequestInit) {
  const token = localStorage.getItem(OWNER_TOKEN_KEY) || "";
  return fetch(`/api/owner${path}`, {
    ...opts,
    headers: {
      "Content-Type": "application/json",
      "x-owner-token": token,
      ...(opts?.headers || {}),
    },
  });
}

// ─── Sub-components ────────────────────────────────────────────────────────

function StatCard({ label, value, icon, color = "gold" }: { label: string; value: string | number; icon: React.ReactNode; color?: string }) {
  return (
    <div className={`bg-[#0f0f0f] rounded-xl p-4 border ${color === "red" ? "border-red-500/30" : color === "green" ? "border-green-500/30" : "border-[#D4AF37]/20"}`}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-gray-400 text-xs">{label}</span>
        {icon}
      </div>
      <p className={`text-2xl font-bold ${color === "red" ? "text-red-400" : color === "green" ? "text-green-400" : "text-[#D4AF37]"}`}>{value}</p>
    </div>
  );
}

function SectionHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-6">
      <h2 className="text-xl font-bold text-white font-mono">{title}</h2>
      {subtitle && <p className="text-gray-500 text-sm mt-1">{subtitle}</p>}
    </div>
  );
}

// ─── Tabs ──────────────────────────────────────────────────────────────────

const tabs = [
  { id: "dashboard", label: "Обзор", icon: BarChart2 },
  { id: "admins", label: "Администраторы", icon: Users },
  { id: "traders", label: "Трейдеры", icon: Users },
  { id: "orders", label: "Ордеры", icon: CreditCard },
  { id: "cards", label: "Карты", icon: CreditCard },
  { id: "disputes", label: "Диспуты", icon: AlertTriangle },
  { id: "config", label: "Настройки", icon: Settings },
  { id: "security", label: "Безопасность", icon: Shield },
  { id: "system", label: "Система", icon: Server },
];

// ─── Dashboard Tab ─────────────────────────────────────────────────────────

function DashboardTab() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [topTraders, setTopTraders] = useState<any[]>([]);

  useEffect(() => {
    apiFetch("/stats").then(r => r.json()).then(d => { setStats(d); setLoading(false); }).catch(() => setLoading(false));
    apiFetch("/top-traders").then(r => r.json()).then(d => setTopTraders(Array.isArray(d) ? d : [])).catch(() => {});
  }, []);

  const exportTopTraders = () => {
    const csv = ["Имя,Оборот,Диспуты,Комиссия", ...topTraders.map(t => `${t.name},${t.volume},${t.disputes},${t.commission}%`)].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "top_traders.csv"; a.click();
  };

  const s = stats || {};
  return (
    <div>
      <SectionHeader title="Обзор платформы" subtitle="Статистика в реальном времени" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Трейдеров" value={loading ? "..." : s.total_traders ?? 0} icon={<Users className="w-4 h-4 text-[#D4AF37]" />} />
        <StatCard label="Оборот сегодня" value={loading ? "..." : `${Number(s.today_volume ?? 0).toLocaleString()} ₽`} icon={<TrendingUp className="w-4 h-4 text-green-400" />} color="green" />
        <StatCard label="Ордеров сегодня" value={loading ? "..." : s.today_orders ?? 0} icon={<CreditCard className="w-4 h-4 text-[#D4AF37]" />} />
        <StatCard label="Диспутов" value={loading ? "..." : s.total_disputes ?? 0} icon={<AlertTriangle className="w-4 h-4 text-red-400" />} color="red" />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Прибыль (день)" value={loading ? "..." : `${Number(s.profit_day ?? 0).toLocaleString()} ₽`} icon={<DollarSign className="w-4 h-4 text-[#D4AF37]" />} />
        <StatCard label="Прибыль (неделя)" value={loading ? "..." : `${Number(s.profit_week ?? 0).toLocaleString()} ₽`} icon={<DollarSign className="w-4 h-4 text-[#D4AF37]" />} />
        <StatCard label="Прибыль (месяц)" value={loading ? "..." : `${Number(s.profit_month ?? 0).toLocaleString()} ₽`} icon={<DollarSign className="w-4 h-4 text-[#D4AF37]" />} />
        <StatCard label="Активных трейдеров" value={loading ? "..." : s.active_traders ?? 0} icon={<Activity className="w-4 h-4 text-green-400" />} color="green" />
      </div>

      {/* Топ трейдеров */}
      <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 overflow-hidden">
        <div className="p-4 flex justify-between items-center border-b border-gray-800">
          <h3 className="font-bold text-white">Топ трейдеров по обороту</h3>
          <button onClick={exportTopTraders} className="flex items-center gap-1 px-3 py-1.5 text-xs bg-[#D4AF37]/10 text-[#D4AF37] rounded-lg hover:bg-[#D4AF37]/20">
            <Download className="w-3 h-3" /> Экспорт CSV
          </button>
        </div>
        <table className="w-full">
          <thead className="bg-gray-900/50">
            <tr className="text-xs text-gray-400 text-left">
              <th className="p-3">#</th><th className="p-3">Имя</th><th className="p-3">Оборот</th><th className="p-3">Диспуты</th><th className="p-3">Комиссия</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800">
            {topTraders.length === 0 ? (
              <tr><td colSpan={5} className="p-6 text-center text-gray-500">Нет данных</td></tr>
            ) : topTraders.slice(0, 10).map((t, i) => (
              <tr key={t.id} className="hover:bg-gray-800/30">
                <td className="p-3 text-[#D4AF37] font-bold">#{i+1}</td>
                <td className="p-3 text-white">{t.name}</td>
                <td className="p-3 text-green-400">{Number(t.volume ?? 0).toLocaleString()} ₽</td>
                <td className="p-3 text-red-400">{t.disputes ?? 0}</td>
                <td className="p-3 text-gray-300">{t.commission}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Admins Tab ────────────────────────────────────────────────────────────

function AdminsTab() {
  const [admins, setAdmins] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ login: "", name: "", role: "view", password: "", token: "" });
  const [logs, setLogs] = useState<any[]>([]);
  const [showLogs, setShowLogs] = useState(false);
  const [createdAdmin, setCreatedAdmin] = useState<any>(null);
  const [showDisputeLogs, setShowDisputeLogs] = useState(false);
  const [disputeLogs, setDisputeLogs] = useState<any[]>([]);

  const generateToken = () => "adm_" + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);

  const load = () => {
    apiFetch("/admins").then(r => r.json()).then(d => { setAdmins(Array.isArray(d) ? d : []); setLoading(false); }).catch(() => setLoading(false));
  };

  const loadLogs = () => {
    apiFetch("/admin-logs").then(r => r.json()).then(d => setLogs(Array.isArray(d) ? d : [])).catch(() => {});
    setShowLogs(true);
  };

  const loadDisputeLogs = () => {
    apiFetch("/dispute-logs").then(r => r.json()).then(d => setDisputeLogs(Array.isArray(d) ? d : [])).catch(() => {});
  };

  const exportLogs = () => {
    const csv = ["Администратор,Действие,ID ордера,В пользу,Изменение комиссии,IP,Время",
      ...logs.map(l => `${l.admin_name || l.action_by},${l.action},${l.order_id || ""},${l.favor || ""},${l.commission_change || ""},${l.ip || ""},${l.created_at}`)
    ].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "admin_logs.csv"; a.click();
  };

  useEffect(() => { load(); }, []);

  const createAdmin = async () => {
    if (!form.name || !form.login || !form.password) return alert("Заполните все поля");
    const token = form.token || generateToken();
    const payload = { ...form, token };
    const res = await apiFetch("/admins", { method: "POST", body: JSON.stringify(payload) });
    const data = await res.json();
    setCreatedAdmin({ ...data, login: form.login, password: form.password, token });
    setShowCreate(false);
    setForm({ login: "", name: "", role: "view", password: "", token: "" });
    load();
  };

  const toggleAdmin = async (id: number, is_active: boolean) => {
    await apiFetch(`/admins/${id}/toggle`, { method: "POST", body: JSON.stringify({ is_active: !is_active }) });
    load();
  };

  const deleteAdmin = async (id: number) => {
    if (!confirm("Удалить администратора?")) return;
    await apiFetch(`/admins/${id}`, { method: "DELETE" });
    load();
  };

  return (
    <div>
      <SectionHeader title="Администраторы" subtitle="Управление аккаунтами администраторов" />

      <div className="flex flex-wrap gap-3 mb-6">
        <button onClick={() => setShowCreate(true)} className="flex items-center gap-2 px-4 py-2 bg-[#D4AF37] text-black rounded-lg font-bold text-sm">
          <Plus className="w-4 h-4" /> Создать администратора
        </button>
        <button onClick={loadLogs} className="flex items-center gap-2 px-4 py-2 bg-gray-800 text-white rounded-lg text-sm">
          <FileText className="w-4 h-4" /> Логи действий
        </button>
        <button onClick={() => { setShowDisputeLogs(v => !v); if (!showDisputeLogs) loadDisputeLogs(); }} className="flex items-center gap-2 px-4 py-2 bg-purple-500/10 text-purple-400 border border-purple-500/30 rounded-lg text-sm">
          <AlertTriangle className="w-4 h-4" /> Мониторинг споров
        </button>
      </div>

      {createdAdmin && (
        <div className="bg-green-500/10 border border-green-500/50 rounded-xl p-5 mb-6">
          <div className="flex justify-between items-start mb-3">
            <h3 className="font-bold text-green-400">✅ Администратор создан</h3>
            <button onClick={() => setCreatedAdmin(null)} className="text-gray-400 hover:text-white"><X className="w-4 h-4" /></button>
          </div>
          <div className="space-y-2 text-sm font-mono">
            <div className="flex justify-between"><span className="text-gray-400">Логин (email):</span><span className="text-white">{createdAdmin.login}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">Пароль:</span><span className="text-white">{createdAdmin.password}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">Токен:</span><span className="text-[#D4AF37] text-xs break-all">{createdAdmin.token}</span></div>
          </div>
          <p className="text-yellow-400 text-xs mt-3">⚠️ Сохраните эти данные — пароль не отображается повторно</p>
        </div>
      )}

      {showCreate && (
        <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 p-5 mb-6">
          <h3 className="font-bold text-white mb-4">Создать администратора</h3>
          <div className="grid grid-cols-1 gap-3">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Логин (email)</label>
              <input type="email" value={form.login} onChange={e => setForm({...form, login: e.target.value})} placeholder="admin@example.com" className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Отображаемое имя</label>
              <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="Имя администратора" className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Пароль</label>
              <input type="text" value={form.password} onChange={e => setForm({...form, password: e.target.value})} placeholder="Придумайте пароль" className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white font-mono" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Токен (оставьте пустым для автогенерации)</label>
              <div className="flex gap-2">
                <input value={form.token} onChange={e => setForm({...form, token: e.target.value})} placeholder="adm_..." className="flex-1 px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white font-mono text-sm" />
                <button type="button" onClick={() => setForm({...form, token: generateToken()})} className="px-3 py-2 bg-gray-700 text-gray-300 rounded-lg text-xs hover:bg-gray-600">Генерировать</button>
              </div>
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Роль</label>
              <select value={form.role} onChange={e => setForm({...form, role: e.target.value})} className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white">
                <option value="view">Только просмотр</option>
                <option value="manage">Управление трейдерами</option>
                <option value="full">Полный доступ</option>
              </select>
            </div>
            <div className="flex gap-2">
              <button onClick={createAdmin} className="flex-1 py-2 bg-[#D4AF37] text-black rounded-lg font-bold">Создать</button>
              <button onClick={() => setShowCreate(false)} className="flex-1 py-2 bg-gray-800 text-white rounded-lg">Отмена</button>
            </div>
          </div>
        </div>
      )}

      {showDisputeLogs && (
        <div className="bg-[#0f0f0f] rounded-xl border border-purple-500/30 mb-6 overflow-hidden">
          <div className="p-4 flex justify-between items-center border-b border-gray-800">
            <h3 className="font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-purple-400" />
              Мониторинг разрешений споров
            </h3>
            <button onClick={() => setShowDisputeLogs(false)} className="p-1 text-gray-400 hover:text-white"><X className="w-4 h-4" /></button>
          </div>
          <div className="max-h-96 overflow-y-auto">
            {disputeLogs.length === 0 ? (
              <p className="p-6 text-center text-gray-500">Нет записей о разрешении споров</p>
            ) : (
              <table className="w-full text-sm">
                <thead className="bg-gray-900/50 sticky top-0">
                  <tr className="text-xs text-gray-400 text-left">
                    <th className="p-3">Администратор</th>
                    <th className="p-3">Ордер</th>
                    <th className="p-3">Сумма</th>
                    <th className="p-3">В пользу</th>
                    <th className="p-3">Трейдер</th>
                    <th className="p-3">Дата/Время</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {disputeLogs.map((log, i) => (
                    <tr key={i} className="hover:bg-gray-800/30">
                      <td className="p-3 text-[#D4AF37] font-medium">{log.admin_name}</td>
                      <td className="p-3 font-mono text-xs text-blue-400">{log.order_id || "—"}</td>
                      <td className="p-3 text-white">{log.amount ? `${Number(log.amount).toLocaleString()} ₽` : "—"}</td>
                      <td className="p-3 text-green-400">{log.favor || "—"}</td>
                      <td className="p-3 text-gray-300">{log.trader_name || "—"}</td>
                      <td className="p-3 text-gray-500 text-xs whitespace-nowrap">{new Date(log.created_at).toLocaleString("ru-RU")}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      {showLogs && (
        <div className="bg-[#0f0f0f] rounded-xl border border-gray-800 mb-6 overflow-hidden">
          <div className="p-4 flex justify-between items-center border-b border-gray-800">
            <h3 className="font-bold text-white">Логи действий администраторов</h3>
            <div className="flex gap-2">
              <button onClick={exportLogs} className="flex items-center gap-1 px-3 py-1.5 text-xs bg-[#D4AF37]/10 text-[#D4AF37] rounded-lg"><Download className="w-3 h-3" /> CSV</button>
              <button onClick={() => setShowLogs(false)} className="p-1 text-gray-400 hover:text-white"><X className="w-4 h-4" /></button>
            </div>
          </div>
          <div className="max-h-96 overflow-y-auto">
            {logs.length === 0 ? <p className="p-6 text-center text-gray-500">Нет логов</p> : logs.map((log, i) => (
              <div key={i} className="p-3 border-b border-gray-800 text-sm">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <span className="text-[#D4AF37] font-medium">{log.admin_name || log.action_by || "Система"}</span>
                    <span className="text-gray-400"> — {log.action}</span>
                    {log.order_id && <span className="text-blue-400 ml-1">#{log.order_id}</span>}
                    {log.favor && <span className="text-green-400 ml-1">(в пользу: {log.favor})</span>}
                    {log.commission_change && <span className="text-yellow-400 ml-1">(комиссия: {log.commission_change})</span>}
                  </div>
                  <span className="text-gray-600 text-xs whitespace-nowrap">{log.ip ? `${log.ip} • ` : ""}{new Date(log.created_at).toLocaleString("ru-RU")}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-900/50">
            <tr className="text-xs text-gray-400 text-left">
              <th className="p-3">Имя</th><th className="p-3">Роль</th><th className="p-3">Токен</th><th className="p-3">Статус</th><th className="p-3">Действия</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800">
            {loading ? (
              <tr><td colSpan={5} className="p-6 text-center text-gray-500">Загрузка...</td></tr>
            ) : admins.length === 0 ? (
              <tr><td colSpan={5} className="p-6 text-center text-gray-500">Нет администраторов</td></tr>
            ) : admins.map(admin => (
              <tr key={admin.id} className="hover:bg-gray-800/30">
                <td className="p-3 text-white font-medium">{admin.name}</td>
                <td className="p-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${admin.role === "full" ? "bg-purple-500/20 text-purple-400" : admin.role === "manage" ? "bg-blue-500/20 text-blue-400" : "bg-gray-500/20 text-gray-400"}`}>
                    {admin.role === "full" ? "Полный доступ" : admin.role === "manage" ? "Управление" : "Просмотр"}
                  </span>
                </td>
                <td className="p-3 font-mono text-xs text-gray-400">{admin.token?.slice(0, 12)}...</td>
                <td className="p-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${admin.is_active ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>
                    {admin.is_active ? "Активен" : "Заблокирован"}
                  </span>
                </td>
                <td className="p-3">
                  <div className="flex items-center gap-2">
                    <button onClick={() => toggleAdmin(admin.id, admin.is_active)} className="p-1.5 rounded-lg hover:bg-gray-700 text-gray-400">
                      {admin.is_active ? <Ban className="w-3.5 h-3.5" /> : <CheckCircle className="w-3.5 h-3.5" />}
                    </button>
                    <button onClick={() => deleteAdmin(admin.id)} className="p-1.5 rounded-lg hover:bg-red-500/10 text-gray-400 hover:text-red-400">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Traders Tab ───────────────────────────────────────────────────────────

function TradersTab() {
  const [traders, setTraders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [editId, setEditId] = useState<number | null>(null);
  const [editCommission, setEditCommission] = useState("");
  const [balanceModal, setBalanceModal] = useState<{id: number; name: string; mode: "add"|"deduct"} | null>(null);
  const [balanceAmount, setBalanceAmount] = useState("");
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [createName, setCreateName] = useState("");
  const [createCommission, setCreateCommission] = useState("5");
  const [creating, setCreating] = useState(false);
  const [createdTrader, setCreatedTrader] = useState<any>(null);

  const load = () => {
    apiFetch("/traders").then(r => r.json()).then(d => { setTraders(Array.isArray(d) ? d : []); setLoading(false); }).catch(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const toggle = async (id: number, is_active: boolean) => {
    await apiFetch(`/traders/${id}/toggle`, { method: "POST", body: JSON.stringify({ is_active: !is_active }) });
    load();
  };

  const saveCommission = async (id: number) => {
    await apiFetch(`/traders/${id}/commission`, { method: "POST", body: JSON.stringify({ commission: parseFloat(editCommission) }) });
    setEditId(null); load();
  };

  const adjustBalance = async () => {
    if (!balanceModal) return;
    await apiFetch(`/traders/${balanceModal.id}/balance`, {
      method: "POST",
      body: JSON.stringify({ amount: parseFloat(balanceAmount), mode: balanceModal.mode })
    });
    setBalanceModal(null); setBalanceAmount(""); load();
  };

  const createTrader = async () => {
    if (!createName.trim()) return;
    setCreating(true);
    try {
      const r = await apiFetch("/traders/create", {
        method: "POST",
        body: JSON.stringify({ name: createName, profit_percent: parseFloat(createCommission) || 5 }),
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Ошибка создания");
      setCreatedTrader(data);
      setCreateName("");
      setCreateCommission("5");
      load();
    } catch (e: any) {
      alert(e.message);
    } finally {
      setCreating(false);
    }
  };

  const filtered = traders.filter(t => !search || t.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <SectionHeader title="Трейдеры" subtitle="Управление трейдерами платформы" />

      {/* Create Trader button */}
      <div className="flex gap-3 mb-4">
        <button
          onClick={() => { setShowCreateForm(v => !v); setCreatedTrader(null); }}
          className="flex items-center gap-2 px-4 py-2 bg-[#D4AF37] text-black rounded-lg font-bold text-sm"
        >
          <Plus className="w-4 h-4" />
          Создать трейдера
        </button>
      </div>

      {/* Create Trader Form */}
      {showCreateForm && (
        <div className="bg-[#0f0f0f] border border-[#D4AF37]/30 rounded-xl p-5 mb-6">
          <h3 className="text-white font-bold mb-4 flex items-center gap-2">
            <Users className="w-4 h-4 text-[#D4AF37]" />
            Новый трейдер
          </h3>
          {createdTrader ? (
            <div className="space-y-3">
              <p className="text-green-400 text-sm font-semibold">✓ Трейдер создан. Сохраните учётные данные:</p>
              <div className="bg-black/60 rounded-lg p-4 space-y-2 font-mono text-sm">
                <div className="flex justify-between"><span className="text-gray-500">Имя:</span><span className="text-white">{createdTrader.name}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Логин:</span><span className="text-[#D4AF37]">{createdTrader.login}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Пароль:</span><span className="text-[#D4AF37]">{createdTrader.password}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Токен:</span><span className="text-[#D4AF37] break-all">{createdTrader.token}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Комиссия:</span><span className="text-white">{createdTrader.profit_percent}%</span></div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    const text = `Логин: ${createdTrader.login}\nПароль: ${createdTrader.password}\nТокен: ${createdTrader.token}`;
                    navigator.clipboard.writeText(text);
                  }}
                  className="flex-1 py-2 bg-[#D4AF37]/20 text-[#D4AF37] rounded-lg text-sm"
                >
                  Скопировать данные
                </button>
                <button onClick={() => { setCreatedTrader(null); setShowCreateForm(false); }} className="flex-1 py-2 bg-gray-800 text-white rounded-lg text-sm">Закрыть</button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div>
                <label className="block text-gray-400 text-xs mb-1">Имя / Никнейм</label>
                <input
                  value={createName}
                  onChange={e => setCreateName(e.target.value)}
                  placeholder="Например: Трейдер Иван"
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm"
                />
              </div>
              <div>
                <label className="block text-gray-400 text-xs mb-1">Комиссия (%)</label>
                <input
                  type="number"
                  value={createCommission}
                  onChange={e => setCreateCommission(e.target.value)}
                  min="0" max="100" step="0.5"
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm"
                />
              </div>
              <p className="text-gray-500 text-xs">Логин, пароль и токен будут сгенерированы автоматически.</p>
              <div className="flex gap-2">
                <button
                  onClick={createTrader}
                  disabled={creating || !createName.trim()}
                  className="flex-1 py-2 bg-[#D4AF37] text-black rounded-lg font-bold text-sm disabled:opacity-50"
                >
                  {creating ? "Создание..." : "Создать"}
                </button>
                <button onClick={() => setShowCreateForm(false)} className="flex-1 py-2 bg-gray-800 text-white rounded-lg text-sm">Отмена</button>
              </div>
            </div>
          )}
        </div>
      )}

      <div className="flex gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Поиск трейдера..." className="w-full pl-9 pr-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm" />
        </div>
      </div>

      <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-900/50">
              <tr className="text-xs text-gray-400 text-left">
                <th className="p-3">Имя</th><th className="p-3">Баланс</th><th className="p-3">Комиссия</th><th className="p-3">Статус</th><th className="p-3">Действия</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {loading ? (
                <tr><td colSpan={5} className="p-6 text-center text-gray-500">Загрузка...</td></tr>
              ) : filtered.map(t => (
                <tr key={t.id} className="hover:bg-gray-800/30">
                  <td className="p-3 text-white font-medium">{t.name}</td>
                  <td className="p-3 text-[#D4AF37]">{Number(t.balance ?? 0).toFixed(2)} USDT</td>
                  <td className="p-3">
                    {editId === t.id ? (
                      <div className="flex items-center gap-1">
                        <input type="number" value={editCommission} onChange={e => setEditCommission(e.target.value)} className="w-16 px-2 py-1 bg-[#1a1a1a] border border-gray-600 rounded text-white text-sm" />
                        <span className="text-gray-400 text-xs">%</span>
                        <button onClick={() => saveCommission(t.id)} className="p-1 text-green-400"><Check className="w-3 h-3" /></button>
                        <button onClick={() => setEditId(null)} className="p-1 text-red-400"><X className="w-3 h-3" /></button>
                      </div>
                    ) : (
                      <span className="cursor-pointer hover:text-[#D4AF37] text-gray-300" onClick={() => { setEditId(t.id); setEditCommission(String(t.profit_percent ?? 5)); }}>
                        {t.profit_percent ?? 5}%
                      </span>
                    )}
                  </td>
                  <td className="p-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${t.is_active ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>
                      {t.is_active ? "Активен" : "Заблокирован"}
                    </span>
                  </td>
                  <td className="p-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => toggle(t.id, t.is_active)} className={`p-1.5 rounded-lg text-xs ${t.is_active ? "bg-red-500/10 text-red-400" : "bg-green-500/10 text-green-400"}`}>
                        {t.is_active ? <Ban className="w-3.5 h-3.5" /> : <CheckCircle className="w-3.5 h-3.5" />}
                      </button>
                      <button onClick={() => { setBalanceModal({id: t.id, name: t.name, mode:"add"}); }} className="p-1.5 rounded-lg bg-green-500/10 text-green-400 text-xs">
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => { setBalanceModal({id: t.id, name: t.name, mode:"deduct"}); }} className="p-1.5 rounded-lg bg-red-500/10 text-red-400 text-xs">
                        <DollarSign className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {balanceModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
          <div className="bg-[#0f0f0f] rounded-2xl p-6 w-80 border border-[#D4AF37]/20">
            <h3 className="text-white font-bold mb-4">
              {balanceModal.mode === "add" ? "Пополнить баланс" : "Списать с баланса"} — {balanceModal.name}
            </h3>
            <input type="number" value={balanceAmount} onChange={e => setBalanceAmount(e.target.value)} placeholder="Сумма USDT" className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white mb-3" />
            <div className="flex gap-2">
              <button onClick={adjustBalance} className={`flex-1 py-2 rounded-lg font-bold ${balanceModal.mode === "add" ? "bg-green-600 text-white" : "bg-red-600 text-white"}`}>
                {balanceModal.mode === "add" ? "Пополнить" : "Списать"}
              </button>
              <button onClick={() => setBalanceModal(null)} className="flex-1 py-2 bg-gray-800 text-white rounded-lg">Отмена</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Orders Tab ────────────────────────────────────────────────────────────

function OrdersTab() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const load = () => {
    apiFetch("/orders").then(r => r.json()).then(d => { setOrders(Array.isArray(d) ? d : []); setLoading(false); }).catch(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const confirm = async (id: number) => {
    await apiFetch(`/orders/${id}/confirm`, { method: "POST" });
    load();
  };

  const reject = async (id: number) => {
    await apiFetch(`/orders/${id}/reject`, { method: "POST" });
    load();
  };

  const filtered = orders.filter(o => {
    const matchSearch = !search || o.order_id?.includes(search) || o.trader_name?.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "all" || o.status === filter;
    return matchSearch && matchFilter;
  });

  return (
    <div>
      <SectionHeader title="Все ордеры" subtitle="Просмотр и ручное управление ордерами" />
      <div className="flex gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Поиск по ID или трейдеру..." className="w-full pl-9 pr-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm" />
        </div>
        <select value={filter} onChange={e => setFilter(e.target.value)} className="px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm">
          <option value="all">Все статусы</option>
          <option value="pending">Ожидание</option>
          <option value="confirmed">Подтверждён</option>
          <option value="rejected">Отклонён</option>
        </select>
      </div>

      <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-900/50">
              <tr className="text-xs text-gray-400 text-left">
                <th className="p-3">ID</th><th className="p-3">Трейдер</th><th className="p-3">Сумма</th><th className="p-3">Статус</th><th className="p-3">Дата</th><th className="p-3">Действия</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {loading ? (
                <tr><td colSpan={6} className="p-6 text-center text-gray-500">Загрузка...</td></tr>
              ) : filtered.length === 0 ? (
                <tr><td colSpan={6} className="p-6 text-center text-gray-500">Нет ордеров</td></tr>
              ) : filtered.map(o => (
                <tr key={o.id} className="hover:bg-gray-800/30">
                  <td className="p-3 font-mono text-xs text-gray-300">{o.order_id}</td>
                  <td className="p-3 text-white">{o.trader_name}</td>
                  <td className="p-3 text-[#D4AF37]">{Number(o.amount).toLocaleString()} ₽</td>
                  <td className="p-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${o.status === "pending" ? "bg-yellow-500/20 text-yellow-400" : o.status === "confirmed" ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>
                      {o.status === "pending" ? "Ожидание" : o.status === "confirmed" ? "Подтверждён" : "Отклонён"}
                    </span>
                  </td>
                  <td className="p-3 text-gray-400 text-xs">{o.created_at ? new Date(o.created_at).toLocaleString() : "—"}</td>
                  <td className="p-3">
                    {o.status === "pending" && (
                      <div className="flex gap-1">
                        <button onClick={() => confirm(o.id)} className="p-1.5 bg-green-500/10 text-green-400 rounded-lg"><Check className="w-3 h-3" /></button>
                        <button onClick={() => reject(o.id)} className="p-1.5 bg-red-500/10 text-red-400 rounded-lg"><X className="w-3 h-3" /></button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── Cards Tab ─────────────────────────────────────────────────────────────

function CardsTab() {
  const [cards, setCards] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [countryFilter, setCountryFilter] = useState("all");

  const load = () => {
    apiFetch("/cards").then(r => r.json()).then(d => { setCards(Array.isArray(d) ? d : []); setLoading(false); }).catch(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const disableCard = async (id: number) => {
    await apiFetch(`/cards/${id}/disable`, { method: "POST" });
    load();
  };

  const filtered = cards.filter(c => !search || c.card_number?.includes(search) || c.bank_name?.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <SectionHeader title="Карты трейдеров" subtitle="Просмотр и управление всеми картами" />
      <div className="flex gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Поиск по карте или банку..." className="w-full pl-9 pr-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm" />
        </div>
      </div>
      <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-900/50">
            <tr className="text-xs text-gray-400 text-left">
              <th className="p-3">Карта</th><th className="p-3">Банк</th><th className="p-3">Трейдер</th><th className="p-3">Статус</th><th className="p-3">Действия</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800">
            {loading ? <tr><td colSpan={5} className="p-6 text-center text-gray-500">Загрузка...</td></tr>
            : filtered.length === 0 ? <tr><td colSpan={5} className="p-6 text-center text-gray-500">Нет карт</td></tr>
            : filtered.map(c => (
              <tr key={c.id} className="hover:bg-gray-800/30">
                <td className="p-3 font-mono text-gray-300">****{c.card_number?.slice(-4)}</td>
                <td className="p-3 text-white">{c.bank_name}</td>
                <td className="p-3 text-gray-400">{c.trader_name}</td>
                <td className="p-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${c.is_active ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>
                    {c.is_active ? "Активна" : "Отключена"}
                  </span>
                </td>
                <td className="p-3">
                  {c.is_active && (
                    <button onClick={() => disableCard(c.id)} className="p-1.5 bg-red-500/10 text-red-400 rounded-lg text-xs">
                      <Ban className="w-3 h-3" />
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Disputes Tab ──────────────────────────────────────────────────────────

function DisputesTab() {
  const [disputes, setDisputes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  const load = () => {
    apiFetch("/disputes").then(r => r.json()).then(d => { setDisputes(Array.isArray(d) ? d : []); setLoading(false); }).catch(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const resolve = async (id: number, favor: "trader" | "client") => {
    await apiFetch(`/disputes/${id}/resolve`, { method: "POST", body: JSON.stringify({ favor }) });
    load();
  };

  const filtered = disputes.filter(d => filter === "all" || d.status === filter);

  return (
    <div>
      <SectionHeader title="Диспуты" subtitle="Рассмотрение и разрешение апелляций" />
      <div className="flex gap-3 mb-6">
        <select value={filter} onChange={e => setFilter(e.target.value)} className="px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm">
          <option value="all">Все</option>
          <option value="open">Открыты</option>
          <option value="resolved">Разрешены</option>
        </select>
      </div>
      <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-900/50">
            <tr className="text-xs text-gray-400 text-left">
              <th className="p-3">ID</th><th className="p-3">Трейдер</th><th className="p-3">Сумма</th><th className="p-3">Статус</th><th className="p-3">Действия</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800">
            {loading ? <tr><td colSpan={5} className="p-6 text-center text-gray-500">Загрузка...</td></tr>
            : filtered.length === 0 ? <tr><td colSpan={5} className="p-6 text-center text-gray-500">Нет диспутов</td></tr>
            : filtered.map(d => (
              <tr key={d.id} className="hover:bg-gray-800/30">
                <td className="p-3 font-mono text-xs text-gray-300">{d.order_id}</td>
                <td className="p-3 text-white">{d.trader_name}</td>
                <td className="p-3 text-[#D4AF37]">{Number(d.amount ?? 0).toLocaleString()} ₽</td>
                <td className="p-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${d.status === "open" ? "bg-yellow-500/20 text-yellow-400" : "bg-green-500/20 text-green-400"}`}>
                    {d.status === "open" ? "Открыт" : "Разрешён"}
                  </span>
                </td>
                <td className="p-3">
                  {d.status === "open" && (
                    <div className="flex gap-1">
                      <button onClick={() => resolve(d.id, "trader")} className="px-2 py-1 text-xs bg-green-500/10 text-green-400 rounded-lg">В пользу трейдера</button>
                      <button onClick={() => resolve(d.id, "client")} className="px-2 py-1 text-xs bg-red-500/10 text-red-400 rounded-lg">В пользу клиента</button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Config Tab ────────────────────────────────────────────────────────────

function ConfigTab() {
  const [config, setConfig] = useState({
    global_commission: 5,
    min_payment: 100,
    max_payment: 500000,
    withdrawal_start: "10:00",
    withdrawal_end: "00:00",
    dispute_time: 30,
    maintenance_mode: false,
  });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    apiFetch("/config").then(r => r.json()).then(d => { if (d && typeof d === "object") setConfig(prev => ({...prev, ...d})); }).catch(() => {});
  }, []);

  const save = async () => {
    await apiFetch("/config", { method: "POST", body: JSON.stringify(config) });
    setSaved(true); setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div>
      <SectionHeader title="Настройки платформы" subtitle="Глобальные параметры и лимиты" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 p-5">
          <h3 className="font-bold text-white mb-4">Комиссия и лимиты</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-sm text-gray-300 mb-1">Глобальная комиссия (%)</label>
              <input type="number" value={config.global_commission} onChange={e => setConfig({...config, global_commission: parseFloat(e.target.value)})} className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
            </div>
            <div>
              <label className="block text-sm text-gray-300 mb-1">Мин. сумма платежа (₽)</label>
              <input type="number" value={config.min_payment} onChange={e => setConfig({...config, min_payment: parseInt(e.target.value)})} className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
            </div>
            <div>
              <label className="block text-sm text-gray-300 mb-1">Макс. сумма платежа (₽)</label>
              <input type="number" value={config.max_payment} onChange={e => setConfig({...config, max_payment: parseInt(e.target.value)})} className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
            </div>
          </div>
        </div>

        <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 p-5">
          <h3 className="font-bold text-white mb-4">Время и диспуты</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-sm text-gray-300 mb-1">Окно вывода — начало</label>
              <input type="time" value={config.withdrawal_start} onChange={e => setConfig({...config, withdrawal_start: e.target.value})} className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
            </div>
            <div>
              <label className="block text-sm text-gray-300 mb-1">Окно вывода — конец</label>
              <input type="time" value={config.withdrawal_end} onChange={e => setConfig({...config, withdrawal_end: e.target.value})} className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
            </div>
            <div>
              <label className="block text-sm text-gray-300 mb-1">Время разрешения диспута (мин)</label>
              <input type="number" value={config.dispute_time} onChange={e => setConfig({...config, dispute_time: parseInt(e.target.value)})} className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Режим обслуживания */}
      <div className="bg-[#0f0f0f] rounded-xl border border-red-500/20 p-5 mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-white">Режим обслуживания</h3>
            <p className="text-gray-500 text-sm mt-1">Отключает доступ для всех, кроме владельца</p>
          </div>
          <button
            onClick={() => setConfig({...config, maintenance_mode: !config.maintenance_mode})}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${config.maintenance_mode ? "bg-red-500" : "bg-gray-600"}`}
          >
            <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${config.maintenance_mode ? "translate-x-6" : "translate-x-1"}`} />
          </button>
        </div>
        {config.maintenance_mode && (
          <div className="mt-3 p-3 bg-red-500/10 rounded-lg">
            <p className="text-red-400 text-sm">⚠️ Режим обслуживания активен. Трейдеры и администраторы не могут войти.</p>
          </div>
        )}
      </div>

      <button onClick={save} className={`px-6 py-2 rounded-lg font-bold text-sm transition-all ${saved ? "bg-green-500 text-white" : "bg-[#D4AF37] text-black hover:bg-[#c4a030]"}`}>
        {saved ? "✓ Сохранено" : "Сохранить настройки"}
      </button>
    </div>
  );
}

// ─── Security Tab ──────────────────────────────────────────────────────────

function SecurityTab() {
  const [blacklist, setBlacklist] = useState<string[]>([]);
  const [whitelist, setWhitelist] = useState<string[]>([]);
  const [newBlackIP, setNewBlackIP] = useState("");
  const [newWhiteIP, setNewWhiteIP] = useState("");
  const [sessions, setSessions] = useState<any[]>([]);
  const [apiKeys, setApiKeys] = useState<any[]>([]);

  useEffect(() => {
    apiFetch("/ip-blacklist").then(r => r.json()).then(d => setBlacklist(Array.isArray(d) ? d : [])).catch(() => {});
    apiFetch("/ip-whitelist").then(r => r.json()).then(d => setWhitelist(Array.isArray(d) ? d : [])).catch(() => {});
    apiFetch("/admin-sessions").then(r => r.json()).then(d => setSessions(Array.isArray(d) ? d : [])).catch(() => {});
    apiFetch("/merchant-api-keys").then(r => r.json()).then(d => setApiKeys(Array.isArray(d) ? d : [])).catch(() => {});
  }, []);

  const addBlackIP = async () => {
    if (!newBlackIP) return;
    await apiFetch("/ip-blacklist", { method: "POST", body: JSON.stringify({ ip: newBlackIP }) });
    setBlacklist([...blacklist, newBlackIP]); setNewBlackIP("");
  };

  const removeBlackIP = async (ip: string) => {
    await apiFetch("/ip-blacklist/remove", { method: "POST", body: JSON.stringify({ ip }) });
    setBlacklist(blacklist.filter(i => i !== ip));
  };

  const addWhiteIP = async () => {
    if (!newWhiteIP) return;
    await apiFetch("/ip-whitelist", { method: "POST", body: JSON.stringify({ ip: newWhiteIP }) });
    setWhitelist([...whitelist, newWhiteIP]); setNewWhiteIP("");
  };

  const removeWhiteIP = async (ip: string) => {
    await apiFetch("/ip-whitelist/remove", { method: "POST", body: JSON.stringify({ ip }) });
    setWhitelist(whitelist.filter(i => i !== ip));
  };

  const terminateSession = async (id: number) => {
    await apiFetch(`/admin-sessions/${id}`, { method: "DELETE" });
    setSessions(sessions.filter(s => s.id !== id));
  };

  const revokeApiKey = async (id: number) => {
    await apiFetch(`/merchant-api-keys/${id}/revoke`, { method: "POST" });
    setApiKeys(apiKeys.filter(k => k.id !== id));
  };

  return (
    <div className="space-y-6">
      <SectionHeader title="Безопасность" subtitle="IP-листы, сессии, ключи API" />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Blacklist */}
        <div className="bg-[#0f0f0f] rounded-xl border border-red-500/20 p-5">
          <h3 className="font-bold text-white mb-3">IP Blacklist</h3>
          <div className="flex gap-2 mb-3">
            <input value={newBlackIP} onChange={e => setNewBlackIP(e.target.value)} placeholder="192.168.1.1" className="flex-1 px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm" />
            <button onClick={addBlackIP} className="px-3 py-2 bg-red-500/20 text-red-400 rounded-lg text-sm">Добавить</button>
          </div>
          <div className="space-y-1 max-h-40 overflow-y-auto">
            {blacklist.length === 0 ? <p className="text-gray-500 text-sm">Пусто</p> : blacklist.map(ip => (
              <div key={ip} className="flex justify-between items-center p-2 bg-black/40 rounded-lg">
                <span className="font-mono text-sm text-gray-300">{ip}</span>
                <button onClick={() => removeBlackIP(ip)} className="text-red-400 hover:text-red-300"><X className="w-3 h-3" /></button>
              </div>
            ))}
          </div>
        </div>

        {/* Whitelist */}
        <div className="bg-[#0f0f0f] rounded-xl border border-green-500/20 p-5">
          <h3 className="font-bold text-white mb-3">IP Whitelist (владелец)</h3>
          <div className="flex gap-2 mb-3">
            <input value={newWhiteIP} onChange={e => setNewWhiteIP(e.target.value)} placeholder="192.168.1.1" className="flex-1 px-3 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm" />
            <button onClick={addWhiteIP} className="px-3 py-2 bg-green-500/20 text-green-400 rounded-lg text-sm">Добавить</button>
          </div>
          <div className="space-y-1 max-h-40 overflow-y-auto">
            {whitelist.length === 0 ? <p className="text-gray-500 text-sm">Пусто (доступ отовсюду)</p> : whitelist.map(ip => (
              <div key={ip} className="flex justify-between items-center p-2 bg-black/40 rounded-lg">
                <span className="font-mono text-sm text-gray-300">{ip}</span>
                <button onClick={() => removeWhiteIP(ip)} className="text-red-400 hover:text-red-300"><X className="w-3 h-3" /></button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Активные сессии администраторов */}
      <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 overflow-hidden">
        <div className="p-4 border-b border-gray-800">
          <h3 className="font-bold text-white">Активные сессии администраторов</h3>
        </div>
        <div className="divide-y divide-gray-800">
          {sessions.length === 0 ? <p className="p-4 text-center text-gray-500">Нет активных сессий</p> : sessions.map(s => (
            <div key={s.id} className="p-3 flex justify-between items-center">
              <div>
                <p className="text-white text-sm">{s.admin_name}</p>
                <p className="text-gray-500 text-xs">{s.ip} • {s.user_agent?.slice(0, 40)}</p>
              </div>
              <button onClick={() => terminateSession(s.id)} className="px-2 py-1 text-xs bg-red-500/10 text-red-400 rounded-lg">Завершить</button>
            </div>
          ))}
        </div>
      </div>

      {/* Ключи API мерчантов */}
      <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 overflow-hidden">
        <div className="p-4 border-b border-gray-800">
          <h3 className="font-bold text-white">API-ключи мерчантов</h3>
        </div>
        <div className="divide-y divide-gray-800">
          {apiKeys.length === 0 ? <p className="p-4 text-center text-gray-500">Нет ключей</p> : apiKeys.map(k => (
            <div key={k.id} className="p-3 flex justify-between items-center">
              <div>
                <p className="text-white text-sm">{k.merchant_name}</p>
                <p className="font-mono text-xs text-gray-500">{k.api_key?.slice(0, 20)}...</p>
              </div>
              <button onClick={() => revokeApiKey(k.id)} className="px-2 py-1 text-xs bg-red-500/10 text-red-400 rounded-lg">Отозвать</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── System Tab ────────────────────────────────────────────────────────────

function SystemTab() {
  const [health, setHealth] = useState<any>(null);
  const [backupLoading, setBackupLoading] = useState(false);

  useEffect(() => {
    apiFetch("/server-health").then(r => r.json()).then(d => setHealth(d)).catch(() => {});
    const interval = setInterval(() => {
      apiFetch("/server-health").then(r => r.json()).then(d => setHealth(d)).catch(() => {});
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const downloadBackup = async () => {
    setBackupLoading(true);
    try {
      const r = await apiFetch("/backup");
      const blob = await r.blob();
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `backup_${Date.now()}.json`; a.click();
    } catch {}
    setBackupLoading(false);
  };

  const h = health || {};

  return (
    <div className="space-y-6">
      <SectionHeader title="Система" subtitle="Мониторинг сервера и резервное копирование" />

      {/* Здоровье сервера */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="CPU" value={h.cpu !== undefined ? `${h.cpu}%` : "—"} icon={<Cpu className="w-4 h-4 text-[#D4AF37]" />} color={h.cpu > 80 ? "red" : "gold"} />
        <StatCard label="RAM" value={h.ram !== undefined ? `${h.ram}%` : "—"} icon={<Server className="w-4 h-4 text-[#D4AF37]" />} color={h.ram > 80 ? "red" : "gold"} />
        <StatCard label="Диск" value={h.disk !== undefined ? `${h.disk}%` : "—"} icon={<HardDrive className="w-4 h-4 text-[#D4AF37]" />} color={h.disk > 90 ? "red" : "gold"} />
        <StatCard label="Статус" value={h.online ? "Онлайн" : "—"} icon={<Activity className="w-4 h-4 text-green-400" />} color="green" />
      </div>

      {/* Резервное копирование */}
      <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 p-5">
        <h3 className="font-bold text-white mb-4">Резервное копирование</h3>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={downloadBackup}
            disabled={backupLoading}
            className="flex items-center gap-2 px-4 py-2 bg-[#D4AF37] text-black rounded-lg font-bold text-sm disabled:opacity-50"
          >
            <Download className="w-4 h-4" /> {backupLoading ? "Создание..." : "Скачать резервную копию"}
          </button>
          <label className="flex items-center gap-2 px-4 py-2 bg-gray-800 text-white rounded-lg font-bold text-sm cursor-pointer">
            <Upload className="w-4 h-4" /> Восстановить из файла
            <input type="file" className="hidden" accept=".json" onChange={async e => {
              const file = e.target.files?.[0]; if (!file) return;
              const text = await file.text();
              await apiFetch("/restore", { method: "POST", body: text, headers: {"Content-Type": "application/json"} });
              alert("Восстановление завершено");
            }} />
          </label>
        </div>
      </div>

      {/* Смена URL владельца */}
      <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 p-5">
        <h3 className="font-bold text-white mb-2">Сменить URL входа владельца</h3>
        <p className="text-gray-500 text-sm mb-4">Текущий URL: <span className="font-mono text-[#D4AF37]">/owner</span></p>
        <div className="flex gap-3">
          <input type="text" placeholder="Новый путь (например: /secret-admin-2026)" className="flex-1 px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white font-mono text-sm" />
          <button className="px-4 py-2 bg-[#D4AF37] text-black rounded-lg font-bold text-sm">Применить</button>
        </div>
        <p className="text-yellow-500 text-xs mt-2">⚠️ После смены URL необходимо перезапустить сервер.</p>
      </div>

      {/* Фейковые домены */}
      <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 p-5">
        <h3 className="font-bold text-white mb-4">Фейковые домены</h3>
        <div className="flex gap-3 mb-3">
          <input type="text" placeholder="example.com" className="flex-1 px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm" />
          <button className="px-4 py-2 bg-gray-800 text-white rounded-lg text-sm">Добавить</button>
        </div>
        <p className="text-gray-500 text-xs">Домены-маскировки для скрытия реального назначения платформы</p>
      </div>

      {/* Кастомизация страницы входа */}
      <div className="bg-[#0f0f0f] rounded-xl border border-[#D4AF37]/20 p-5">
        <h3 className="font-bold text-white mb-4">Кастомизация страницы входа</h3>
        <div className="space-y-3">
          <div>
            <label className="block text-sm text-gray-300 mb-1">Логотип (URL или base64)</label>
            <input type="text" placeholder="https://..." className="w-full px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm" />
          </div>
          <div>
            <label className="block text-sm text-gray-300 mb-1">Фоновый цвет</label>
            <div className="flex gap-2">
              <input type="color" defaultValue="#000000" className="h-10 w-16 rounded-lg border border-gray-700 bg-transparent cursor-pointer" />
              <input type="text" defaultValue="#000000" className="flex-1 px-4 py-2 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white font-mono text-sm" />
            </div>
          </div>
          <button className="px-4 py-2 bg-[#D4AF37] text-black rounded-lg font-bold text-sm">Сохранить вид</button>
        </div>
      </div>
    </div>
  );
}

// ─── Main Owner Panel ───────────────────────────────────────────────────────

export default function OwnerPanel() {
  const [authenticated, setAuthenticated] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [masterToken, setMasterToken] = useState("");
  const [twoFa, setTwoFa] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loginStep, setLoginStep] = useState<"credentials" | "2fa">("credentials");
  const [loginError, setLoginError] = useState("");
  const [loginLoading, setLoginLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(OWNER_TOKEN_KEY);
    if (stored) setAuthenticated(true);
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    setLoginLoading(true);
    try {
      const res = await fetch("/api/owner/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, token: masterToken }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Неверные данные");
      if (data.requiresTwoFactor) {
        setLoginStep("2fa");
        setLoginLoading(false);
        return;
      }
      localStorage.setItem(OWNER_TOKEN_KEY, masterToken);
      setAuthenticated(true);
    } catch (err: any) {
      setLoginError(err.message);
    } finally {
      setLoginLoading(false);
    }
  };

  const handleTwoFaLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    setLoginLoading(true);
    try {
      const res = await fetch("/api/owner/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, token: masterToken, twoFactorCode: twoFa }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Неверный код 2FA");
      localStorage.setItem(OWNER_TOKEN_KEY, masterToken);
      setAuthenticated(true);
    } catch (err: any) {
      setLoginError(err.message);
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem(OWNER_TOKEN_KEY);
    setAuthenticated(false);
    setMasterToken("");
    setEmail("");
    setPassword("");
  };

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center px-4">
        <div className="bg-[#0f0f0f] p-8 rounded-2xl border border-red-500/20 w-full max-w-md shadow-2xl shadow-red-500/5">
          <div className="text-center mb-8">
            <div className="w-12 h-12 bg-red-500 rounded-lg mx-auto mb-4 flex items-center justify-center shadow-lg shadow-red-500/30">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white font-mono">OWNER PANEL</h1>
          </div>

          {loginStep === "credentials" ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">✉</span>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="Email"
                  className="w-full pl-9 pr-4 py-3 bg-[#1a1a1a] border border-red-500/30 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-red-500 transition-colors"
                  required
                  autoFocus
                />
              </div>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">🔒</span>
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Пароль"
                  className="w-full pl-9 pr-10 py-3 bg-[#1a1a1a] border border-red-500/30 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-red-500 transition-colors"
                  required
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 text-xs">
                  {showPassword ? "скрыть" : "показать"}
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">🔑</span>
                <input
                  type="password"
                  value={masterToken}
                  onChange={e => setMasterToken(e.target.value)}
                  placeholder="Мастер-токен"
                  className="w-full pl-9 pr-4 py-3 bg-[#1a1a1a] border border-red-500/30 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-red-500 transition-colors font-mono text-sm"
                  required
                />
              </div>
              {loginError && (
                <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                  <p className="text-red-400 text-sm text-center">{loginError}</p>
                </div>
              )}
              <button
                type="submit"
                disabled={loginLoading}
                className="w-full py-3 bg-red-500 text-white font-bold rounded-lg hover:bg-red-600 transition-all disabled:opacity-50"
              >
                {loginLoading ? "Проверка..." : "Войти"}
              </button>
            </form>
          ) : (
            <form onSubmit={handleTwoFaLogin} className="space-y-4">
              <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-lg text-center">
                <p className="text-white text-sm font-medium">📱 Google Authenticator</p>
                <p className="text-gray-400 text-xs mt-1">Введите 6-значный код из приложения</p>
              </div>
              <input
                type="text"
                value={twoFa}
                onChange={e => setTwoFa(e.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder="000000"
                maxLength={6}
                className="w-full px-4 py-3 bg-[#1a1a1a] border border-red-500/30 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-red-500 transition-colors font-mono text-2xl text-center tracking-widest"
                required
                autoFocus
              />
              {loginError && (
                <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                  <p className="text-red-400 text-sm text-center">{loginError}</p>
                </div>
              )}
              <button
                type="submit"
                disabled={loginLoading || twoFa.length < 6}
                className="w-full py-3 bg-red-500 text-white font-bold rounded-lg hover:bg-red-600 transition-all disabled:opacity-50"
              >
                {loginLoading ? "Проверка..." : "Подтвердить"}
              </button>
              <button type="button" onClick={() => { setLoginStep("credentials"); setLoginError(""); setTwoFa(""); }} className="w-full py-2 text-gray-500 hover:text-gray-300 text-sm">
                ← Назад
              </button>
            </form>
          )}
        </div>
      </div>
    );
  }

  const activeTabObj = tabs.find(t => t.id === activeTab);

  return (
    <div className="flex min-h-screen bg-black">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? "translate-x-0" : "-translate-x-full"} md:translate-x-0 fixed md:relative z-50 w-64 border-r border-red-500/20 bg-[#080808] flex flex-col flex-shrink-0 h-screen transition-transform`}>
        <div className="flex items-center gap-2 px-4 py-5 border-b border-red-500/20">
          <div className="w-8 h-8 bg-red-500 rounded-md flex items-center justify-center">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <span className="text-white font-bold tracking-wider font-mono text-sm">OWNER PANEL</span>
        </div>
        <nav className="flex-1 overflow-y-auto py-3 px-3 space-y-1">
          {tabs.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-left ${activeTab === tab.id ? "bg-red-500/10 text-red-400 border-l-2 border-red-500" : "text-gray-400 hover:bg-gray-800/50 hover:text-white"}`}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span className="text-sm">{tab.label}</span>
              </button>
            );
          })}
        </nav>
        <div className="p-3 border-t border-red-500/20">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-gray-400 hover:bg-red-500/10 hover:text-red-400 transition-all w-full"
          >
            <LogOut className="w-4 h-4" />
            <span className="text-sm">Выйти</span>
          </button>
        </div>
      </aside>

      {/* Overlay mobile */}
      {sidebarOpen && <div className="fixed inset-0 bg-black/60 z-40 md:hidden" onClick={() => setSidebarOpen(false)} />}

      {/* Main content */}
      <main className="flex-1 overflow-auto min-w-0">
        {/* Top bar */}
        <div className="sticky top-0 z-30 flex items-center gap-4 px-4 md:px-6 py-4 bg-black/90 backdrop-blur border-b border-red-500/20">
          <button onClick={() => setSidebarOpen(true)} className="md:hidden p-2 rounded-lg hover:bg-gray-800">
            <Shield className="w-5 h-5 text-red-400" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-bold text-white font-mono">{activeTabObj?.label ?? ""}</h1>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-xs text-gray-400 hidden sm:inline">Владелец</span>
          </div>
        </div>

        <div className="p-4 md:p-6">
          {activeTab === "dashboard" && <DashboardTab />}
          {activeTab === "admins" && <AdminsTab />}
          {activeTab === "traders" && <TradersTab />}
          {activeTab === "orders" && <OrdersTab />}
          {activeTab === "cards" && <CardsTab />}
          {activeTab === "disputes" && <DisputesTab />}
          {activeTab === "config" && <ConfigTab />}
          {activeTab === "security" && <SecurityTab />}
          {activeTab === "system" && <SystemTab />}
        </div>
      </main>
    </div>
  );
}
