import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  ArrowUpRight, Clock, CreditCard, Activity,
  TrendingUp, Calendar, Download, Eye, Smartphone, ChevronRight,
  BarChart2, Wallet, Shield, Play, Pause
} from "lucide-react";
import { format } from "date-fns";
import { AppLayout } from "@/components/AppLayout";
import { usePlatformStore } from "@/context/PlatformStore";

interface Order {
  id: number;
  orderId: string;
  order_id: string;
  amount: number;
  status: string;
  createdAt?: string;
  created_at?: string;
}

interface Stats {
  activeCards?: number;
  active_cards?: number;
  balance?: number;
  today_profit?: number;
  today_count?: number;
}

interface DeviceInfo {
  total: number;
  active: number;
  offline: number;
  lastActive: Date;
}

interface BalanceInfo {
  total: number;
  working: number;
  security: number;
}

const USDT_TO_RUB = 85;
const SECURITY_DEPOSIT = 85000;

const DAILY_BARS = [
  { label: "Пн", pct: 42, val: "13.6к" },
  { label: "Вт", pct: 61, val: "21.2к" },
  { label: "Ср", pct: 54, val: "17.5к" },
  { label: "Чт", pct: 73, val: "25.2к" },
  { label: "Пт", pct: 88, val: "31.8к" },
  { label: "Сб", pct: 67, val: "23.1к" },
  { label: "Вс", pct: 52, val: "17.7к" },
];

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [stats, setStats] = useState<Stats | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [statsLoading, setStatsLoading] = useState(true);
  const [ordersLoading, setOrdersLoading] = useState(true);
  const [balance, setBalance] = useState<BalanceInfo>({ total: 0, working: 0, security: SECURITY_DEPOSIT });
  const [trafficEnabled, setTrafficEnabled] = useState(false);
  const [trafficLoading, setTrafficLoading] = useState(false);
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [weeklyProfit, setWeeklyProfit] = useState(150100);
  const [monthlyProfit, setMonthlyProfit] = useState(620500);
  const [commissionByMethod, setCommissionByMethod] = useState([
    { method: "Карты РФ", percent: 10 },
    { method: "СБП", percent: 12 },
    { method: "Мобильная коммерция", percent: 17 },
  ]);

  const {
    activeCardCount,
    activeDeviceCount,
    totalDeviceCount,
    offlineDeviceCount,
    devices: storeDevices,
  } = usePlatformStore();

  const lastActiveDevice = storeDevices
    .filter(d => d.isActive)
    .sort((a, b) => b.lastActive.getTime() - a.lastActive.getTime())[0];

  // Получаем sessionToken из localStorage
  useEffect(() => {
    const token = localStorage.getItem("sessionToken");
    if (token) setSessionToken(token);
  }, []);

  // Загрузка баланса
  const fetchBalance = useCallback(async () => {
    if (!sessionToken) return;
    try {
      const res = await fetch("/api/balance", {
        headers: { "x-session-token": sessionToken }
      });
      const data = await res.json();
      setBalance(data);
    } catch (err) {
      console.error(err);
    }
  }, [sessionToken]);

  // Загрузка статуса трафика
  const fetchTrafficStatus = useCallback(async () => {
    if (!sessionToken) return;
    try {
      const res = await fetch("/api/traffic/status", {
        headers: { "x-session-token": sessionToken }
      });
      const data = await res.json();
      setTrafficEnabled(data.enabled);
    } catch (err) {
      console.error(err);
    }
  }, [sessionToken]);

  // Переключение трафика
  const toggleTraffic = async () => {
    if (!sessionToken) return;
    setTrafficLoading(true);
    try {
      const res = await fetch("/api/traffic/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-session-token": sessionToken },
        body: JSON.stringify({ enabled: !trafficEnabled })
      });
      const data = await res.json();
      setTrafficEnabled(data.enabled);
    } catch (err) {
      console.error(err);
    } finally {
      setTrafficLoading(false);
    }
  };

  const fetchStats = useCallback(async () => {
    if (!sessionToken) { setStatsLoading(false); return; }
    try {
      const res = await fetch("/api/trader/stats", {
        headers: { "x-session-token": sessionToken }
      });
      const data = await res.json();
      setStats(data);
    } catch (err) {
      setStats(null);
    } finally {
      setStatsLoading(false);
    }
  }, [sessionToken]);

  const fetchOrders = useCallback(async () => {
    if (!sessionToken) { setOrdersLoading(false); return; }
    try {
      const res = await fetch("/api/orders/recent", {
        headers: { "x-session-token": sessionToken }
      });
      const data = await res.json();
      setOrders(Array.isArray(data) ? data : []);
    } catch (err) {
      setOrders([]);
    } finally {
      setOrdersLoading(false);
    }
  }, [sessionToken]);

  useEffect(() => {
    if (!sessionToken) return;
    fetchBalance();
    fetchTrafficStatus();
    fetchStats();
    fetchOrders();
    const interval = setInterval(() => {
      fetchBalance();
      fetchTrafficStatus();
      fetchStats();
      fetchOrders();
    }, 15000);
    return () => clearInterval(interval);
  }, [sessionToken, fetchBalance, fetchTrafficStatus, fetchStats, fetchOrders]);

  const recentOrders = orders.slice(0, 5);
  const activeOrders = Number(stats?.today_count ?? 0);
  const todayProfit = Number(stats?.today_profit ?? 0) * USDT_TO_RUB;

  const fmtRub = (v: number) =>
    new Intl.NumberFormat("ru-RU", { style: "currency", currency: "RUB", minimumFractionDigits: 0 }).format(v);

  return (
    <AppLayout>
      <div className="space-y-6 p-4 md:p-6 page-transition">

        {/* Header */}
        <div className="flex justify-between items-center gap-3">
          <div>
            <h1 className="text-xl md:text-2xl font-bold tracking-tight font-mono uppercase flex items-center gap-2">
              <Activity className="w-5 h-5 md:w-6 md:h-6 text-[#D4AF37]" />
              Системная панель
            </h1>
            <p className="text-xs md:text-sm text-muted-foreground mt-1">Реальная статистика и прогнозы</p>
          </div>
          <button className="gradient-btn px-3 py-2 rounded-lg text-xs md:text-sm flex items-center gap-1.5 flex-shrink-0">
            <Download className="w-3.5 h-3.5 md:w-4 md:h-4" />
            <span className="hidden sm:inline">Экспорт</span>
          </button>
        </div>

        {/* Баланс (три виджета) + Тумблер Трафик */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 md:gap-4">
          <div className="bg-gradient-to-r from-[#D4AF37]/10 to-transparent rounded-2xl p-4 border border-[#D4AF37]/20">
            <p className="text-gray-400 text-xs font-mono">Общий баланс</p>
            <p className="text-xl md:text-2xl font-bold text-[#D4AF37] font-mono">{fmtRub(balance.total)}</p>
          </div>
          <div className="bg-[#0f0f0f] rounded-2xl p-4 border border-gray-800">
            <p className="text-gray-400 text-xs font-mono">Рабочий баланс</p>
            <p className="text-xl md:text-2xl font-bold text-white font-mono">{fmtRub(balance.working)}</p>
          </div>
          <div className="bg-[#0f0f0f] rounded-2xl p-4 border border-gray-800">
            <p className="text-gray-400 text-xs font-mono">Страховой депозит</p>
            <p className="text-xl md:text-2xl font-bold text-white font-mono">{fmtRub(balance.security)}</p>
          </div>
          <div className="bg-[#0f0f0f] rounded-2xl p-4 border border-gray-800 flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-xs font-mono">Трафик</p>
              <p className={`text-lg font-bold font-mono ${trafficEnabled ? "text-green-500" : "text-red-500"}`}>
                {trafficEnabled ? "Активен" : "Остановлен"}
              </p>
            </div>
            <button
              onClick={toggleTraffic}
              disabled={trafficLoading}
              className={`relative w-12 h-6 rounded-full transition-colors ${trafficEnabled ? "bg-[#D4AF37]" : "bg-gray-600"}`}
            >
              <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${trafficEnabled ? "translate-x-6" : "translate-x-0.5"}`} />
            </button>
          </div>
        </div>

        {/* Stat cards — clickable */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
          <StatCard
            title="Прибыль сегодня"
            value={fmtRub(todayProfit)}
            icon={<TrendingUp className="h-4 w-4 text-green-500" />}
            loading={statsLoading}
            color="gold"
          />
          <StatCard
            title="Активных ордеров"
            value={String(activeOrders)}
            icon={<Calendar className="h-4 w-4 text-[#D4AF37]" />}
            loading={statsLoading}
            color="gold"
            onClick={() => setLocation("/orders")}
          />
          <StatCard
            title="Активных карт"
            value={String(activeCardCount)}
            icon={<CreditCard className="h-4 w-4 text-[#D4AF37]" />}
            loading={false}
            onClick={() => setLocation("/cards")}
          />
        </div>

        {/* Комиссия по методам (мини-виджет) */}
        <div className="glass-premium rounded-xl p-4">
          <h3 className="text-sm font-mono text-gray-400 mb-2">Комиссия по методам</h3>
          <div className="flex flex-wrap gap-3">
            {commissionByMethod.map(c => (
              <div key={c.method} className="bg-black/40 rounded-lg px-3 py-1.5">
                <span className="text-white text-xs">{c.method}</span>
                <span className="text-[#D4AF37] text-xs ml-2 font-mono">{c.percent}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Devices + Daily Income */}
        <div className="grid md:grid-cols-2 gap-4 md:gap-6">

          {/* Devices widget */}
          <button
            className="glass-premium rounded-xl p-4 md:p-6 text-left w-full hover:border-[#D4AF37]/50 transition-colors"
            onClick={() => setLocation("/devices")}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base md:text-lg font-bold font-mono text-white flex items-center gap-2">
                <Smartphone className="w-4 h-4 md:w-5 md:h-5 text-[#D4AF37]" />
                Устройства
              </h2>
              <div className="flex items-center gap-2">
                {activeDeviceCount > 0 && <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />}
                <span className="text-xs text-gray-400">
                  {activeDeviceCount > 0 ? `Онлайн: ${activeDeviceCount}` : "Нет онлайн"}
                </span>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="bg-black/40 rounded-lg p-3">
                <p className="text-xl md:text-2xl font-bold text-white font-mono">{totalDeviceCount}</p>
                <p className="text-xs text-gray-500 mt-0.5">Всего</p>
              </div>
              <div className="bg-black/40 rounded-lg p-3">
                <p className={`text-xl md:text-2xl font-bold font-mono ${activeDeviceCount > 0 ? "text-green-500" : "text-gray-500"}`}>{activeDeviceCount}</p>
                <p className="text-xs text-gray-500 mt-0.5">Активны</p>
              </div>
              <div className="bg-black/40 rounded-lg p-3">
                <p className={`text-xl md:text-2xl font-bold font-mono ${offlineDeviceCount > 0 ? "text-red-500" : "text-gray-500"}`}>{offlineDeviceCount}</p>
                <p className="text-xs text-gray-500 mt-0.5">Офлайн</p>
              </div>
            </div>
            <div className="flex items-center justify-between mt-4">
              <p className="text-xs text-gray-500">
                {lastActiveDevice
                  ? `Активность: ${lastActiveDevice.lastActive.toLocaleString("ru-RU", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}`
                  : totalDeviceCount > 0 ? "Все устройства офлайн" : "Нет устройств"}
              </p>
              <span className="text-[#D4AF37] text-xs flex items-center gap-1">
                Управление <ChevronRight className="w-3 h-3" />
              </span>
            </div>
          </button>

          {/* Daily Income */}
          <div className="glass-premium rounded-xl p-4 md:p-6">
            <h2 className="text-base md:text-lg font-bold font-mono text-white flex items-center gap-2 mb-5">
              <BarChart2 className="w-4 h-4 md:w-5 md:h-5 text-[#D4AF37]" />
              Доход по дням
            </h2>
            <div className="flex items-end justify-between gap-1.5 h-28">
              {DAILY_BARS.map((bar, i) => (
                <div key={i} className="flex flex-col items-center gap-1 flex-1">
                  <span className="text-[9px] text-gray-500 font-mono">{bar.val}₽</span>
                  <div
                    className="w-full rounded-t-md bg-[#D4AF37]/80 hover:bg-[#D4AF37] transition-colors"
                    style={{ height: `${bar.pct}%` }}
                  />
                  <span className="text-[10px] text-gray-500 font-mono">{bar.label}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-3 border-t border-gray-800 flex items-center justify-between text-xs text-gray-500">
              <span className="font-mono">Неделя: <span className="text-[#D4AF37]">{fmtRub(weeklyProfit)}</span></span>
              <span className="font-mono">Месяц: <span className="text-[#D4AF37]">{fmtRub(monthlyProfit)}</span></span>
            </div>
          </div>
        </div>

        {/* Recent orders (оставляем как есть) */}
        <div className="glass-premium rounded-xl overflow-hidden">
          <div className="p-4 border-b border-gray-800 flex justify-between items-center">
            <h2 className="text-base md:text-lg font-bold font-mono text-white flex items-center gap-2">
              <Clock className="w-4 h-4 md:w-5 md:h-5 text-[#D4AF37]" />
              Последние заказы
            </h2>
            <button
              onClick={() => setLocation("/orders")}
              className="flex items-center gap-1 text-xs text-gray-400 hover:text-[#D4AF37] transition-colors"
            >
              <Eye className="w-4 h-4" />
              <span className="hidden sm:inline">Все заказы</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          </div>

          {/* Desktop table (оставляем твой оригинальный код) */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-800/50">
                <tr className="text-left text-xs text-gray-400 uppercase tracking-wider font-mono">
                  <th className="p-3">Заказ</th>
                  <th className="p-3">Сумма</th>
                  <th className="p-3">Прибыль</th>
                  <th className="p-3">Статус</th>
                  <th className="p-3">Дата</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {ordersLoading
                  ? [...Array(5)].map((_, i) => (
                      <tr key={i}><td colSpan={5} className="p-3"><Skeleton className="h-8 w-full" /></tr>
                    ))
                  : recentOrders.length === 0
                    ? <tr><td colSpan={5} className="p-8 text-center text-gray-500 font-mono text-sm">Нет активных заказов</td></tr>
                    : recentOrders.map((order) => {
                        const dateStr = order.createdAt ?? order.created_at ?? "";
                        const orderId = order.orderId ?? order.order_id;
                        return (
                          <tr key={order.id} className="hover:bg-gray-800/30 transition-colors cursor-pointer" onClick={() => setLocation("/orders")}>
                            <td className="p-3 font-mono text-sm text-gray-300">{orderId}</td>
                            <td className="p-3 text-[#D4AF37] font-bold font-mono">{fmtRub(order.amount)}</td>
                            <td className="p-3 text-green-500 font-mono text-sm">+{fmtRub(order.amount * 0.02)}</td>
                            <td className="p-3">
                              <Badge className={`font-mono text-[10px] uppercase px-2 py-0.5 ${
                                order.status === "pending" ? "bg-yellow-500/10 text-yellow-500 border border-yellow-500/30"
                                : order.status === "confirmed" ? "bg-green-500/10 text-green-500 border border-green-500/30"
                                : "bg-red-500/10 text-red-500 border border-red-500/30"
                              }`}>
                                {order.status === "pending" ? "Ожидание" : order.status === "confirmed" ? "Подтверждён" : "Отклонён"}
                              </Badge>
                            </td>
                            <td className="p-3 text-gray-400 text-sm font-mono">
                              {dateStr ? format(new Date(dateStr), "dd.MM HH:mm") : "—"}
                            </td>
                          </tr>
                        );
                      })
                }
              </tbody>
            </table>
          </div>

          {/* Mobile list (оставляем твой оригинальный код) */}
          <div className="sm:hidden divide-y divide-gray-800">
            {ordersLoading
              ? [...Array(3)].map((_, i) => <div key={i} className="p-4"><Skeleton className="h-12 w-full" /></div>)
              : recentOrders.length === 0
                ? <p className="p-8 text-center text-gray-500 text-sm">Нет активных заказов</p>
                : recentOrders.map((order) => {
                    const dateStr = order.createdAt ?? order.created_at ?? "";
                    return (
                      <div key={order.id} className="p-4 flex items-center justify-between gap-3" onClick={() => setLocation("/orders")}>
                        <div>
                          <p className="text-white font-mono text-sm">{order.orderId ?? order.order_id}</p>
                          <p className="text-gray-500 text-xs mt-0.5 font-mono">{dateStr ? format(new Date(dateStr), "dd.MM HH:mm") : "—"}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[#D4AF37] font-bold text-sm font-mono">{fmtRub(order.amount)}</p>
                          <Badge className={`font-mono text-[10px] uppercase px-2 py-0.5 mt-1 ${
                            order.status === "pending" ? "bg-yellow-500/10 text-yellow-500"
                            : order.status === "confirmed" ? "bg-green-500/10 text-green-500"
                            : "bg-red-500/10 text-red-500"
                          }`}>
                            {order.status === "pending" ? "Ожидание" : order.status === "confirmed" ? "Подтверждён" : "Отклонён"}
                          </Badge>
                        </div>
                      </div>
                    );
                  })
            }
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function StatCard({
  title, value, icon, loading, color = "default", onClick
}: {
  title: string;
  value: string;
  icon: React.ReactNode;
  loading: boolean;
  color?: string;
  onClick?: () => void;
}) {
  return (
    <Card
      className={`border-border/50 transition-all ${color === "gold" ? "bg-gradient-to-r from-[#D4AF37]/10 to-transparent" : "bg-card/50"} ${onClick ? "cursor-pointer hover:border-[#D4AF37]/50 hover:shadow-lg" : ""}`}
      onClick={onClick}
    >
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1 pt-3 px-3 md:px-6 md:pt-6 md:pb-2">
        <CardTitle className="text-[10px] md:text-xs font-medium tracking-wider text-muted-foreground uppercase leading-tight font-mono">
          {title}
        </CardTitle>
        <div className="flex items-center gap-1">
          {icon}
          {onClick && <ArrowUpRight className="w-3 h-3 text-gray-600" />}
        </div>
      </CardHeader>
      <CardContent className="px-3 pb-3 md:px-6 md:pb-6">
        {loading
          ? <Skeleton className="h-6 w-20 md:h-7 md:w-24" />
          : <div className="text-lg md:text-2xl font-bold text-[#D4AF37] font-mono">{value}</div>
        }
      </CardContent>
    </Card>
  );
}
