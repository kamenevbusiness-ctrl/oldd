import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import {
  ArrowDownLeft, ArrowUpRight, History, Clock, Lock,
  AlertTriangle, Coins, User, QrCode, X, Copy, Check
} from "lucide-react";
import { AppLayout } from "@/components/AppLayout";

const USDT_TO_RUB = 85;
const SECURITY_DEPOSIT_USDT = 1000;
const MIN_WITHDRAWAL_USDT = 500;
const MIN_DEPOSIT_USDT = 50;

interface Transaction {
  id: string;
  type: "deposit" | "withdraw";
  amount: number;
  currency: "RUB" | "USDT";
  status: "completed" | "pending" | "failed";
  createdAt: string;
  destination?: string;
}

export default function Wallet() {
  const [, setLocation] = useLocation();
  const [totalUSDT, setTotalUSDT] = useState<number | null>(null);
  const [loadingBalance, setLoadingBalance] = useState(true);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [sessionToken, setSessionToken] = useState<string | null>(null);

  const workingUSDT = totalUSDT !== null ? Math.max(0, totalUSDT - SECURITY_DEPOSIT_USDT) : 0;
  const workingRUB = workingUSDT * USDT_TO_RUB;
  const securityUSDT = totalUSDT !== null ? Math.min(SECURITY_DEPOSIT_USDT, totalUSDT) : 0;

  // ─── Withdraw modal state ────────────────────────────────────────────────
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawMethod, setWithdrawMethod] = useState<"trc20" | "bybit_uid">("trc20");
  const [withdrawAddress, setWithdrawAddress] = useState("");
  const [withdrawError, setWithdrawError] = useState("");
  const [withdrawSuccess, setWithdrawSuccess] = useState("");

  // ─── Top-up modal state ──────────────────────────────────────────────────
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [depositAmount, setDepositAmount] = useState("");
  const [depositMethod, setDepositMethod] = useState<"trc20" | "bybit_uid" | "bybit_qr">("trc20");
  const [depositStep, setDepositStep] = useState<"form" | "instructions">("form");
  const [copied, setCopied] = useState(false);

  // Placeholder payment details (заглушки, будут заменены реальными)
  const DEPOSIT_WALLET_TRC20 = "TRwBqR6S5MvK9XpL2NcFjH7YtG8kVbD3eW";
  const DEPOSIT_BYBIT_UID = "123456789";

  useEffect(() => {
    const token = localStorage.getItem("sessionToken");
    if (token) setSessionToken(token);
  }, []);

  // Загрузка баланса и транзакций
  const fetchBalance = useCallback(async () => {
    if (!sessionToken) {
      setLoadingBalance(false);
      return;
    }
    try {
      const res = await fetch("/api/balance", {
        headers: { "x-session-token": sessionToken }
      });
      const data = await res.json();
      setTotalUSDT(data.total / USDT_TO_RUB);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingBalance(false);
    }
  }, [sessionToken]);

  const fetchTransactions = useCallback(async () => {
    if (!sessionToken) return;
    try {
      const res = await fetch("/api/transactions", {
        headers: { "x-session-token": sessionToken }
      });
      const data = await res.json();
      setTransactions(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
      setTransactions([]);
    }
  }, [sessionToken]);

  useEffect(() => {
    fetchBalance();
    fetchTransactions();
    const interval = setInterval(() => {
      fetchBalance();
      fetchTransactions();
    }, 15000);
    return () => clearInterval(interval);
  }, [fetchBalance, fetchTransactions]);

  const canWithdraw = () => {
    const hours = new Date().getHours();
    return hours >= 10 && hours < 24;
  };

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawError("");
    setWithdrawSuccess("");

    if (!canWithdraw()) {
      setWithdrawError("Вывод средств доступен только с 10:00 до 00:00");
      return;
    }
    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) { setWithdrawError("Введите корректную сумму"); return; }
    if (amount < MIN_WITHDRAWAL_USDT) { setWithdrawError(`Минимальная сумма вывода: ${MIN_WITHDRAWAL_USDT} USDT`); return; }
    if (amount > workingUSDT) { setWithdrawError(`Недостаточно рабочего баланса. Доступно: ${workingUSDT.toFixed(2)} USDT`); return; }
    if (!withdrawAddress.trim()) { setWithdrawError(withdrawMethod === "trc20" ? "Введите TRC-20 адрес кошелька" : "Введите Bybit UID"); return; }

    try {
      const res = await fetch("/api/withdraw", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-session-token": sessionToken || "" },
        body: JSON.stringify({ amount, address: withdrawAddress, method: withdrawMethod })
      });
      const data = await res.json();
      if (res.ok) {
        setTotalUSDT(prev => (prev ?? 0) - amount);
        setWithdrawSuccess(`Заявка на вывод ${amount} USDT создана`);
        setWithdrawAmount("");
        setWithdrawAddress("");
        setShowWithdrawModal(false);
        fetchTransactions();
        setTimeout(() => setWithdrawSuccess(""), 4000);
      } else {
        setWithdrawError(data.error || "Ошибка при создании заявки");
      }
    } catch (err) {
      setWithdrawError("Ошибка сети");
    }
  };

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(depositAmount);
    if (isNaN(amount) || amount < MIN_DEPOSIT_USDT) {
      alert(`Минимальная сумма пополнения: ${MIN_DEPOSIT_USDT} USDT`);
      return;
    }
    setDepositStep("instructions");
  };

  const copyText = (text: string) => {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatAmount = (amount: number, currency: "RUB" | "USDT") =>
    currency === "RUB" ? `${amount.toLocaleString()} ₽` : `${amount.toFixed(2)} USDT`;

  const balanceDisplay = loadingBalance ? "..." : totalUSDT !== null ? `${totalUSDT.toFixed(2)} USDT` : "—";

  return (
    <AppLayout>
      <div className="space-y-6 p-4 md:p-6">

        {withdrawSuccess && (
          <div className="bg-green-500/20 border border-green-500 rounded-lg p-3 text-green-400 text-sm">
            {withdrawSuccess}
          </div>
        )}

        {/* Total balance */}
        <div className="bg-gradient-to-r from-[#D4AF37]/10 to-transparent rounded-2xl p-6 border border-[#D4AF37]/20">
          <p className="text-gray-400 text-sm mb-1">Итого на счету</p>
          <p className="text-4xl font-bold text-[#D4AF37] font-mono">
            {loadingBalance ? "..." : totalUSDT !== null ? totalUSDT.toFixed(2) : "—"} USDT
          </p>
          <p className="text-gray-500 text-xs mt-2">
            Рабочий: {workingUSDT.toFixed(2)} USDT &nbsp;•&nbsp; Страховой: {securityUSDT.toFixed(2)} USDT
          </p>
        </div>

        {/* Security deposit info */}
        <div className="bg-[#0f0f0f] rounded-2xl p-4 border border-yellow-500/30">
          <div className="flex items-center gap-3">
            <Lock className="w-5 h-5 text-yellow-500 flex-shrink-0" />
            <div>
              <p className="text-yellow-400 text-sm font-medium">Страховой депозит (заблокировано)</p>
              <p className="text-2xl font-bold text-white mt-0.5">{securityUSDT.toFixed(2)} USDT</p>
              <p className="text-gray-500 text-xs mt-1">
                ≈ {(securityUSDT * USDT_TO_RUB).toLocaleString()} ₽ &nbsp;•&nbsp; Не подлежит выводу
              </p>
            </div>
          </div>
        </div>

        {/* Rub working balance */}
        <div className="bg-[#0f0f0f] rounded-2xl p-4 border border-green-500/20">
          <p className="text-gray-400 text-xs mb-1">Рабочий баланс (RUB)</p>
          <p className="text-3xl font-bold text-green-400">{Math.round(workingRUB).toLocaleString()} ₽</p>
          <p className="text-gray-500 text-xs mt-1">≈ {workingUSDT.toFixed(2)} USDT • Курс: 1 USDT = {USDT_TO_RUB} ₽</p>
        </div>

        {workingUSDT <= 0 && totalUSDT !== null && (
          <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/50 rounded-lg">
            <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0" />
            <p className="text-red-400 text-xs">Рабочий баланс исчерпан. Трафик автоматически остановлен. Пополните баланс для возобновления работы.</p>
          </div>
        )}

        {/* Action buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => { setShowDepositModal(true); setDepositStep("form"); setDepositAmount(""); }}
            className="flex items-center justify-center gap-2 p-3 bg-[#D4AF37] text-black font-bold rounded-xl hover:bg-[#c4a030] transition-colors"
          >
            <ArrowUpRight className="w-4 h-4" />
            Пополнить
          </button>
          <button
            onClick={() => setShowWithdrawModal(true)}
            className="flex items-center justify-center gap-2 p-3 bg-[#1a1a1a] border border-gray-700 rounded-xl text-white hover:border-[#D4AF37] transition-colors"
          >
            <ArrowDownLeft className="w-4 h-4" />
            Вывести USDT
          </button>
        </div>

        {!canWithdraw() && (
          <div className="flex items-center gap-2 p-3 bg-yellow-500/10 border border-yellow-500/50 rounded-lg">
            <Clock className="w-4 h-4 text-yellow-500" />
            <p className="text-yellow-500 text-xs">Вывод средств доступен только с 10:00 до 00:00</p>
          </div>
        )}

        {/* Transaction history */}
        <div>
          <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
            <History className="w-4 h-4 text-[#D4AF37]" />
            История транзакций
          </h2>
          <div className="space-y-2">
            {transactions.length === 0 ? (
              <p className="text-gray-500 text-sm text-center py-8">Нет транзакций</p>
            ) : (
              transactions.map((tx) => (
                <div key={tx.id} className="flex items-center justify-between p-3 bg-[#0f0f0f] rounded-lg border border-gray-800">
                  <div>
                    <p className="text-white text-sm">{tx.type === "deposit" ? "Пополнение" : "Вывод"}</p>
                    <p className="text-gray-500 text-xs">
                      {new Date(tx.createdAt).toLocaleString()}
                      {tx.destination && ` • ${tx.destination}`}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${tx.type === "deposit" ? "text-green-500" : "text-red-500"}`}>
                      {tx.type === "deposit" ? "+" : "-"}{formatAmount(tx.amount, tx.currency)}
                    </p>
                    <p className={`text-xs ${tx.status === "completed" ? "text-green-500" : tx.status === "pending" ? "text-yellow-500" : "text-red-500"}`}>
                      {tx.status === "completed" ? "Выполнено" : tx.status === "pending" ? "В обработке" : "Ошибка"}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* ── TOP-UP MODAL ─────────────────────────────────────────────────────── */}
        {showDepositModal && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={() => setShowDepositModal(false)}>
            <div className="bg-[#0f0f0f] rounded-2xl p-6 w-full max-w-md border border-[#D4AF37]/20" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-white">Пополнение баланса</h2>
                <button onClick={() => setShowDepositModal(false)} className="p-1 rounded-lg hover:bg-gray-800">
                  <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              {depositStep === "form" ? (
                <form onSubmit={handleDepositSubmit} className="space-y-4">
                  {/* Method selector */}
                  <div>
                    <label className="block text-sm text-gray-300 mb-2">Метод пополнения</label>
                    <div className="grid grid-cols-3 gap-2">
                      {(["trc20", "bybit_uid", "bybit_qr"] as const).map((m) => (
                        <button
                          key={m}
                          type="button"
                          onClick={() => setDepositMethod(m)}
                          className={`p-3 rounded-lg text-xs border transition-all flex flex-col items-center gap-1 ${depositMethod === m ? "bg-[#D4AF37]/10 border-[#D4AF37] text-[#D4AF37]" : "bg-gray-800 border-gray-700 text-gray-400"}`}
                        >
                          {m === "trc20" && <Coins className="w-4 h-4" />}
                          {m === "bybit_uid" && <User className="w-4 h-4" />}
                          {m === "bybit_qr" && <QrCode className="w-4 h-4" />}
                          {m === "trc20" ? "USDT TRC-20" : m === "bybit_uid" ? "Bybit UID" : "Bybit QR"}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Amount */}
                  <div>
                    <label className="block text-sm text-gray-300 mb-1">Сумма пополнения (USDT)</label>
                    <input
                      type="number"
                      value={depositAmount}
                      onChange={e => setDepositAmount(e.target.value)}
                      placeholder={`Минимум ${MIN_DEPOSIT_USDT} USDT`}
                      min={MIN_DEPOSIT_USDT}
                      step={1}
                      className="w-full px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white focus:outline-none focus:border-[#D4AF37]"
                      required
                    />
                    {depositAmount && parseFloat(depositAmount) >= MIN_DEPOSIT_USDT && (
                      <p className="text-xs text-gray-500 mt-1">
                        ≈ {(parseFloat(depositAmount) * USDT_TO_RUB).toLocaleString()} ₽ по курсу {USDT_TO_RUB} ₽/USDT
                      </p>
                    )}
                  </div>

                  <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                    <p className="text-blue-400 text-xs">ℹ️ После отправки средств баланс пополнится автоматически в течение нескольких минут.</p>
                  </div>

                  <div className="flex gap-3">
                    <button type="button" onClick={() => setShowDepositModal(false)} className="flex-1 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700">Отмена</button>
                    <button type="submit" className="flex-1 py-2 bg-[#D4AF37] text-black rounded-lg font-bold hover:bg-[#c4a030]">Продолжить</button>
                  </div>
                </form>
              ) : (
                <div className="space-y-4">
                  <div className="p-4 bg-green-500/10 border border-green-500 rounded-lg text-center">
                    <p className="text-green-400 text-sm font-medium">✅ Заявка на пополнение создана</p>
                    <p className="text-gray-400 text-xs mt-1">
                      Сумма: <span className="text-[#D4AF37] font-bold">{depositAmount} USDT</span>
                      &nbsp;≈&nbsp;{(parseFloat(depositAmount || "0") * USDT_TO_RUB).toLocaleString()} ₽
                    </p>
                  </div>

                  {depositMethod === "trc20" && (
                    <div>
                      <label className="block text-sm text-gray-300 mb-1">Кошелёк для перевода (USDT TRC-20)</label>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={DEPOSIT_WALLET_TRC20}
                          readOnly
                          className="flex-1 px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-gray-300 font-mono text-sm"
                        />
                        <button onClick={() => copyText(DEPOSIT_WALLET_TRC20)} className="p-3 rounded-lg bg-gray-800 text-[#D4AF37] hover:bg-gray-700 transition-colors">
                          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        </button>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Отправьте ровно <span className="text-[#D4AF37] font-bold">{depositAmount} USDT</span> на указанный адрес в сети TRC-20.
                      </p>
                    </div>
                  )}

                  {depositMethod === "bybit_uid" && (
                    <div>
                      <label className="block text-sm text-gray-300 mb-1">UID получателя (Bybit)</label>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={DEPOSIT_BYBIT_UID}
                          readOnly
                          className="flex-1 px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-[#D4AF37] font-mono text-sm"
                        />
                        <button onClick={() => copyText(DEPOSIT_BYBIT_UID)} className="p-3 rounded-lg bg-gray-800 text-[#D4AF37] hover:bg-gray-700 transition-colors">
                          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        </button>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        В Bybit: Активы → P2P → Перевод по UID → укажите <span className="text-[#D4AF37] font-bold">{depositAmount} USDT</span> и UID выше.
                      </p>
                    </div>
                  )}

                  {depositMethod === "bybit_qr" && (
                    <div className="text-center">
                      <div className="bg-white p-4 rounded-xl inline-block mx-auto mb-3">
                        <div className="w-48 h-48 bg-gray-200 flex items-center justify-center text-gray-400 text-sm rounded">
                          QR-код появится здесь
                        </div>
                      </div>
                      <p className="text-xs text-gray-500">
                        Отсканируйте QR-код в приложении Bybit и оплатите <span className="text-[#D4AF37] font-bold">{depositAmount} USDT</span>
                      </p>
                    </div>
                  )}

                  <div className="p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                    <p className="text-yellow-400 text-xs">⚠️ Отправляйте ТОЛЬКО USDT (TRC-20). Переводы в других сетях приведут к потере средств.</p>
                  </div>

                  <button
                    onClick={() => { setDepositStep("form"); setDepositAmount(""); }}
                    className="w-full py-2 text-gray-500 hover:text-gray-300 text-sm transition-colors"
                  >
                    ← Новая заявка
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── WITHDRAW MODAL ───────────────────────────────────────────────────── */}
        {showWithdrawModal && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={() => setShowWithdrawModal(false)}>
            <div className="bg-[#0f0f0f] rounded-2xl p-6 w-full max-w-md border border-[#D4AF37]/20" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-xl font-bold text-white">Вывод USDT</h2>
                <button onClick={() => setShowWithdrawModal(false)} className="p-1 rounded-lg hover:bg-gray-800">
                  <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>
              <p className="text-gray-500 text-xs mb-4">Минимальная сумма: {MIN_WITHDRAWAL_USDT} USDT • Доступно: {workingUSDT.toFixed(2)} USDT</p>

              <form onSubmit={handleWithdraw} className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-300 mb-2">Метод вывода</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(["trc20", "bybit_uid"] as const).map((m) => (
                      <button
                        key={m}
                        type="button"
                        onClick={() => setWithdrawMethod(m)}
                        className={`p-3 rounded-lg text-sm border transition-all ${withdrawMethod === m ? "bg-[#D4AF37]/10 border-[#D4AF37] text-[#D4AF37]" : "bg-gray-800 border-gray-700 text-gray-400"}`}
                      >
                        {m === "trc20" ? "USDT TRC-20" : "Bybit UID"}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-gray-300 mb-1">
                    {withdrawMethod === "trc20" ? "Адрес кошелька TRC-20" : "Bybit UID"}
                  </label>
                  <input
                    type="text"
                    value={withdrawAddress}
                    onChange={e => setWithdrawAddress(e.target.value)}
                    placeholder={withdrawMethod === "trc20" ? "T... (TRC-20 адрес)" : "Ваш Bybit UID"}
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white font-mono text-sm focus:outline-none focus:border-[#D4AF37]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-300 mb-1">Сумма (USDT)</label>
                  <input
                    type="number"
                    value={withdrawAmount}
                    onChange={e => setWithdrawAmount(e.target.value)}
                    placeholder={`Минимум ${MIN_WITHDRAWAL_USDT} USDT`}
                    min={MIN_WITHDRAWAL_USDT}
                    step={1}
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white focus:outline-none focus:border-[#D4AF37]"
                    required
                  />
                  {withdrawAmount && parseFloat(withdrawAmount) >= MIN_WITHDRAWAL_USDT && (
                    <p className="text-xs text-gray-500 mt-1">≈ {(parseFloat(withdrawAmount) * USDT_TO_RUB).toLocaleString()} ₽</p>
                  )}
                </div>

                {withdrawError && <p className="text-red-500 text-sm">{withdrawError}</p>}

                <div className="p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                  <p className="text-yellow-400 text-xs">⚠️ Вывод только через Bybit (TRC-20 или UID). Страховой депозит {SECURITY_DEPOSIT_USDT} USDT не выводится.</p>
                </div>

                <div className="flex gap-3">
                  <button type="button" onClick={() => setShowWithdrawModal(false)} className="flex-1 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700">Отмена</button>
                  <button type="submit" className="flex-1 py-2 bg-[#D4AF37] text-black rounded-lg font-bold hover:bg-[#c4a030]">Вывести</button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </AppLayout>
  );
}
