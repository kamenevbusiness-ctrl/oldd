import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Eye, EyeOff, Shield, Lock, Key, Smartphone, User } from "lucide-react";

export default function Login() {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");
  const [twoFa, setTwoFa] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [step, setStep] = useState<"credentials" | "2fa">("credentials");
  const [pendingUserId, setPendingUserId] = useState<number | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [, setLocation] = useLocation();
  const [theme, setTheme] = useState<"dark" | "light">("dark");

  // Автоматическое определение темы
  useEffect(() => {
    const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    setTheme(isDark ? "dark" : "light");
    const observer = (e: MediaQueryListEvent) => setTheme(e.matches ? "dark" : "light");
    window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", observer);
    return () => window.matchMedia("(prefers-color-scheme: dark)").removeEventListener("change", observer);
  }, []);

  const bgClass = theme === "dark" ? "bg-black" : "bg-gray-100";
  const cardClass = theme === "dark" ? "bg-[#0f0f0f] border-[#D4AF37]/20" : "bg-white border-[#D4AF37]/40";
  const inputClass = theme === "dark"
    ? "bg-[#1a1a1a] border-[#D4AF37]/30 text-white placeholder:text-gray-600"
    : "bg-gray-100 border-gray-300 text-black placeholder:text-gray-500";

  const handleCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ login, password, token }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Ошибка входа");

      if (data.requiresTwoFactor) {
        setPendingUserId(data.userId);
        setStep("2fa");
        return;
      }

      localStorage.setItem("sessionToken", data.sessionToken);
      localStorage.setItem("userRole", data.role);
      setLocation("/dashboard");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleTwoFa = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/verify-2fa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: pendingUserId, code: twoFa }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Неверный код 2FA");

      localStorage.setItem("sessionToken", data.sessionToken);
      setLocation("/dashboard");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`min-h-screen flex items-center justify-center px-4 transition-colors duration-300 ${bgClass}`}>
      <div className={`p-8 rounded-2xl border shadow-2xl shadow-[#D4AF37]/5 w-full max-w-md transition-colors duration-300 ${cardClass}`}>
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-[#D4AF37] rounded-lg mx-auto mb-4 shadow-lg shadow-[#D4AF37]/30 flex items-center justify-center">
            <Shield className="w-6 h-6 text-black" />
          </div>
          <h1 className="text-2xl font-bold font-mono text-white dark:text-white text-gray-900">PLAYERS2</h1>
          {step === "2fa" && (
            <p className="text-gray-500 text-sm mt-1">Подтверждение личности</p>
          )}
        </div>

        {step === "credentials" ? (
          <form onSubmit={handleCredentials} className="space-y-4">
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="text"
                value={login}
                onChange={(e) => setLogin(e.target.value)}
                placeholder="Логин"
                className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:border-[#D4AF37] transition-colors ${inputClass}`}
                required
                autoFocus
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Пароль"
                className={`w-full pl-10 pr-10 py-3 border rounded-lg focus:outline-none focus:border-[#D4AF37] transition-colors ${inputClass}`}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            <div className="relative">
              <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="text"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                placeholder="Токен доступа"
                className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:border-[#D4AF37] transition-colors font-mono text-sm ${inputClass}`}
                required
              />
            </div>

            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                <p className="text-red-400 text-sm text-center">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-[#D4AF37] text-black font-bold rounded-lg hover:bg-[#c4a030] transition-all disabled:opacity-50"
            >
              {loading ? "Проверка..." : "Войти"}
            </button>
          </form>
        ) : (
          <form onSubmit={handleTwoFa} className="space-y-4">
            <div className="p-4 bg-[#D4AF37]/10 border border-[#D4AF37]/30 rounded-lg text-center">
              <Smartphone className="w-8 h-8 text-[#D4AF37] mx-auto mb-2" />
              <p className="text-white font-medium">Google Authenticator</p>
              <p className="text-gray-400 text-xs mt-1">Введите 6-значный код из приложения</p>
            </div>

            <input
              type="text"
              value={twoFa}
              onChange={(e) => setTwoFa(e.target.value.replace(/\D/g, "").slice(0, 6))}
              placeholder="000000"
              maxLength={6}
              className={`w-full px-4 py-3 border rounded-lg text-center text-2xl tracking-widest font-mono focus:outline-none focus:border-[#D4AF37] transition-colors ${inputClass}`}
              required
              autoFocus
            />

            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                <p className="text-red-400 text-sm text-center">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading || twoFa.length < 6}
              className="w-full py-3 bg-[#D4AF37] text-black font-bold rounded-lg hover:bg-[#c4a030] transition-all disabled:opacity-50"
            >
              {loading ? "Проверка..." : "Подтвердить"}
            </button>

            <button
              type="button"
              onClick={() => { setStep("credentials"); setError(""); setTwoFa(""); }}
              className="w-full py-2 text-gray-500 hover:text-gray-300 text-sm transition-colors"
            >
              ← Назад
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
