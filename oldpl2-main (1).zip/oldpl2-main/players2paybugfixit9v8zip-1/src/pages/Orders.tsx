import { useState, useEffect, useCallback } from "react";
import { AppLayout } from "@/components/AppLayout";
import { 
  Search, Clock, CheckCircle, XCircle, AlertCircle,
  Eye, ArrowUpRight, ArrowDownLeft, Download
} from "lucide-react";

interface Order {
  id: string;
  orderId: string;
  type: "incoming" | "outgoing";
  amount: number;
  currency: string;
  status: "pending" | "confirmed" | "rejected";
  method: string;
  details: string;
  customerName?: string;
  createdAt: string;
  confirmedAt?: string;
}

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState<"incoming" | "outgoing">("incoming");
  const [period, setPeriod] = useState<"today" | "yesterday" | "week" | "lastWeek">("today");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sessionToken, setSessionToken] = useState<string | null>(null);

  useEffect(() => {
    const token = localStorage.getItem("sessionToken");
    if (token) setSessionToken(token);
  }, []);

  const fetchOrders = useCallback(async () => {
    if (!sessionToken) {
      setLoading(false);
      return;
    }
    try {
      const res = await fetch(`/api/orders?type=${activeTab}&period=${period}`, {
        headers: { "x-session-token": sessionToken }
      });
      const data = await res.json();
      setOrders(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
      setOrders([]);
    } finally {
      setLoading(false);
    }
  }, [sessionToken, activeTab, period]);

  useEffect(() => {
    fetchOrders();
    const interval = setInterval(fetchOrders, 15000);
    return () => clearInterval(interval);
  }, [fetchOrders]);

  const filterByPeriod = (order: Order) => {
    const now = new Date();
    const orderDate = new Date(order.createdAt);
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const weekStart = new Date(today);
    weekStart.setDate(weekStart.getDate() - 7);
    const lastWeekStart = new Date(weekStart);
    lastWeekStart.setDate(lastWeekStart.getDate() - 7);

    switch(period) {
      case "today": return orderDate >= today;
      case "yesterday": return orderDate >= yesterday && orderDate < today;
      case "week": return orderDate >= weekStart;
      case "lastWeek": return orderDate >= lastWeekStart && orderDate < weekStart;
      default: return true;
    }
  };

  const filteredOrders = orders
    .filter(order => order.type === activeTab)
    .filter(order => filterByPeriod(order))
    .filter(order => 
      order.orderId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (order.customerName && order.customerName.toLowerCase().includes(searchQuery.toLowerCase()))
    );

  const exportToCSV = () => {
    const headers = ["ID заказа", "Тип", "Сумма", "Валюта", "Статус", "Метод", "Реквизит", "Плательщик", "Дата создания", "Дата подтверждения"];
    const rows = filteredOrders.map(order => [
      order.orderId,
      order.type === "incoming" ? "Входящий" : "Исходящий",
      order.amount.toString(),
      order.currency,
      order.status === "pending" ? "Ожидание" : order.status === "confirmed" ? "Подтверждён" : "Отклонён",
      order.method,
      order.details,
      order.customerName || "",
      new Date(order.createdAt).toLocaleString(),
      order.confirmedAt ? new Date(order.confirmedAt).toLocaleString() : ""
    ]);
    const csvContent = [headers, ...rows].map(row => row.join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `orders_${activeTab}_${period}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const getStatusIcon = (status: string) => {
    switch(status) {
      case "pending": return <Clock className="w-3.5 h-3.5 text-yellow-500" />;
      case "confirmed": return <CheckCircle className="w-3.5 h-3.5 text-green-500" />;
      case "rejected": return <XCircle className="w-3.5 h-3.5 text-red-500" />;
      default: return <AlertCircle className="w-3.5 h-3.5 text-gray-500" />;
    }
  };

  const getStatusText = (status: string) => {
    switch(status) {
      case "pending": return "Ожидание";
      case "confirmed": return "Подтверждён";
      case "rejected": return "Отклонён";
      default: return status;
    }
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case "pending": return "bg-yellow-500/10 text-yellow-500";
      case "confirmed": return "bg-green-500/10 text-green-500";
      case "rejected": return "bg-red-500/10 text-red-500";
      default: return "bg-gray-500/10 text-gray-500";
    }
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  if (loading) {
    return (
      <AppLayout>
        <div className="p-6 text-white">Загрузка...</div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-4 p-4 md:p-6">
        <div className="flex justify-between items-center gap-3">
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-white font-mono">Ордеры</h1>
            <p className="text-gray-500 text-xs md:text-sm mt-0.5">Все входящие и исходящие транзакции</p>
          </div>
          <button
            onClick={exportToCSV}
            className="flex items-center gap-1.5 px-3 py-2 bg-[#D4AF37] text-black rounded-lg font-bold hover:bg-[#c4a030] transition-colors text-sm flex-shrink-0"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">CSV</span>
          </button>
        </div>

        <div className="flex gap-2 border-b border-gray-800">
          <button
            onClick={() => setActiveTab("incoming")}
            className={`px-4 py-2 text-sm font-medium transition-all ${activeTab === "incoming" ? "text-[#D4AF37] border-b-2 border-[#D4AF37]" : "text-gray-500 hover:text-gray-300"}`}
          >
            Входящие
          </button>
          <button
            onClick={() => setActiveTab("outgoing")}
            className={`px-4 py-2 text-sm font-medium transition-all ${activeTab === "outgoing" ? "text-[#D4AF37] border-b-2 border-[#D4AF37]" : "text-gray-500 hover:text-gray-300"}`}
          >
            Исходящие
          </button>
        </div>

        <div className="space-y-3">
          <div className="flex gap-2 flex-wrap">
            {[
              { value: "today", label: "Сегодня" },
              { value: "yesterday", label: "Вчера" },
              { value: "week", label: "Неделя" },
              { value: "lastWeek", label: "Прош. неделя" },
            ].map((p) => (
              <button
                key={p.value}
                onClick={() => setPeriod(p.value as any)}
                className={`px-3 py-1.5 text-xs md:text-sm rounded-lg transition-all ${period === p.value ? "bg-[#D4AF37] text-black" : "bg-gray-800 text-gray-400 hover:bg-gray-700"}`}
              >
                {p.label}
              </button>
            ))}
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ID заказа, телефон, карта..."
              className="pl-9 pr-4 py-2.5 bg-[#1a1a1a] border border-gray-700 rounded-lg text-white text-sm w-full focus:outline-none focus:border-[#D4AF37]"
            />
          </div>
        </div>

        <div className="space-y-2">
          {filteredOrders.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">Нет заказов за выбранный период</p>
            </div>
          ) : (
            filteredOrders.map((order) => (
              <div key={order.id} className="bg-[#0f0f0f] rounded-xl border border-gray-800 p-3 md:p-4 hover:border-[#D4AF37]/30 transition-all">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 md:gap-3 min-w-0">
                    {order.type === "incoming" ? (
                      <ArrowUpRight className="w-4 h-4 text-green-500 flex-shrink-0" />
                    ) : (
                      <ArrowDownLeft className="w-4 h-4 text-red-500 flex-shrink-0" />
                    )}
                    <div className="min-w-0">
                      <p className="text-white font-mono text-xs md:text-sm truncate">{order.orderId}</p>
                      <p className="text-gray-500 text-xs">{formatDate(order.createdAt)}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 md:gap-4 flex-shrink-0">
                    <div className="text-right">
                      <p className="text-white font-bold text-sm">{order.amount.toLocaleString()} {order.currency}</p>
                      <p className="text-gray-500 text-xs hidden md:block">{order.method} • {order.details}</p>
                    </div>
                    <div className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(order.status)} flex items-center gap-1 hidden sm:flex`}>
                      {getStatusIcon(order.status)}
                      <span className="hidden md:inline">{getStatusText(order.status)}</span>
                    </div>
                    <button
                      onClick={() => {
                        setSelectedOrder(order);
                        setShowDetails(true);
                      }}
                      className="p-1.5 md:p-2 hover:bg-gray-800 rounded-lg transition-colors"
                    >
                      <Eye className="w-4 h-4 text-gray-500 hover:text-[#D4AF37]" />
                    </button>
                  </div>
                </div>

                <div className="sm:hidden flex items-center justify-between mt-2 pt-2 border-t border-gray-800/50">
                  <p className="text-gray-500 text-xs">{order.method} • {order.details}</p>
                  <div className={`px-2 py-0.5 rounded text-xs font-medium ${getStatusColor(order.status)} flex items-center gap-1`}>
                    {getStatusIcon(order.status)}
                    {getStatusText(order.status)}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {showDetails && selectedOrder && (
          <div className="fixed inset-0 bg-black/80 flex items-end sm:items-center justify-center z-50 p-0 sm:p-4" onClick={() => setShowDetails(false)}>
            <div className="bg-[#0f0f0f] rounded-t-2xl sm:rounded-2xl p-6 w-full sm:max-w-md border border-[#D4AF37]/20 max-h-[85vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
              <div className="w-10 h-1 bg-gray-700 rounded-full mx-auto mb-4 sm:hidden" />
              <h2 className="text-xl font-bold text-white mb-4">Детали заказа</h2>
              <div className="space-y-3">
                <div className="flex justify-between"><span className="text-gray-500">ID заказа:</span><span className="text-white font-mono text-sm">{selectedOrder.orderId}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Тип:</span><span className={selectedOrder.type === "incoming" ? "text-green-500" : "text-red-500"}>{selectedOrder.type === "incoming" ? "Входящий" : "Исходящий"}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Сумма:</span><span className="text-white font-bold">{selectedOrder.amount.toLocaleString()} {selectedOrder.currency}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Метод:</span><span className="text-white">{selectedOrder.method}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Реквизит:</span><span className="text-white">{selectedOrder.details}</span></div>
                {selectedOrder.customerName && (
                  <div className="flex justify-between"><span className="text-gray-500">Плательщик:</span><span className="text-white">{selectedOrder.customerName}</span></div>
                )}
                <div className="flex justify-between"><span className="text-gray-500">Создан:</span><span className="text-white">{formatDate(selectedOrder.createdAt)}</span></div>
                {selectedOrder.confirmedAt && (
                  <div className="flex justify-between"><span className="text-gray-500">Подтверждён:</span><span className="text-white">{formatDate(selectedOrder.confirmedAt)}</span></div>
                )}
                <div className="flex justify-between"><span className="text-gray-500">Статус:</span>
                  <span className={`flex items-center gap-1 ${getStatusColor(selectedOrder.status)}`}>
                    {getStatusIcon(selectedOrder.status)}{getStatusText(selectedOrder.status)}
                  </span>
                </div>
              </div>
              <button onClick={() => setShowDetails(false)} className="w-full mt-6 py-3 bg-[#D4AF37] text-black rounded-lg font-bold">Закрыть</button>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
