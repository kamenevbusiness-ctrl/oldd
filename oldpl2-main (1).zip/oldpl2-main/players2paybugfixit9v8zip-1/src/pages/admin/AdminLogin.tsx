import { useState } from "react";
import { useLocation } from "wouter";
import { Shield, Eye, EyeOff, Mail, Lock, Key, Smartphone } from "lucide-react";

export default function AdminLogin() {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");
  const [twoFa, setTwoFa] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [step, setStep] = useState<"credentials" | "2fa">("credentials");
  const [pendingUserId, setPendingUserId] = useState<number | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [, setLocation] = useLocation();

  const handleCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ login, password, token }),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Ошибка входа");
      }

      if (data.requiresTwoFactor) {
        setPendingUserId(data.userId);
        setStep("2fa");
        setLoading(false);
        return;
      }

      localStorage.setItem("sessionToken", data.sessionToken);
      localStorage.setItem("userRole", data.role);
      setLocation("/admin/dashboard");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleTwoFa = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/auth/verify-2fa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: pendingUserId, code: twoFa }),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Неверный код 2FA");
      }

      localStorage.setItem("sessionToken", data.sessionToken);
      localStorage.setItem("userRole", data.role);
      setLocation("/admin/dashboard");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4">
      <div className="bg-[#0f0f0f] p-8 rounded-2xl border border-red-500/20 w-full max-w-md shadow-2xl shadow-red-500/5">
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-red-600 rounded-lg mx-auto mb-4 shadow-lg shadow-red-600/30 flex items-center justify-center">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white font-mono">ADMIN PANEL</h1>
          <p className="text-gray-500 text-sm mt-2">
            {step === "credentials" ? "Вход для администраторов" : "Двухфакторная аутентификация"}
          </p>
        </div>

        {step === "credentials" ? (
          <form onSubmit={handleCredentials} className="space-y-4">
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="text"
                value={login}
                onChange={(e) => setLogin(e.target.value)}
                placeholder="Логин"
                className="w-full pl-10 pr-4 py-3 bg-[#1a1a1a] border border-red-500/30 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-red-500 transition-colors"
                required
                autoFocus
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Пароль"
                className="w-full pl-10 pr-10 py-3 bg-[#1a1a1a] border border-red-500/30 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-red-500 transition-colors"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            <div className="relative">
              <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="text"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                placeholder="Токен доступа"
                className="w-full pl-10 pr-4 py-3 bg-[#1a1a1a] border border-red-500/30 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-red-500 transition-colors font-mono text-sm"
                required
              />
            </div>

            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                <p className="text-red-400 text-sm text-center">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700 transition-all disabled:opacity-50"
            >
              {loading ? "Проверка..." : "Войти"}
            </button>
          </form>
        ) : (
          <form onSubmit={handleTwoFa} className="space-y-4">
            <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-lg text-center">
              <Smartphone className="w-8 h-8 text-red-400 mx-auto mb-2" />
              <p className="text-white text-sm font-medium">Google Authenticator</p>
              <p className="text-gray-400 text-xs mt-1">Введите 6-значный код из приложения</p>
            </div>

            <input
              type="text"
              value={twoFa}
              onChange={(e) => setTwoFa(e.target.value.replace(/\D/g, "").slice(0, 6))}
              placeholder="000000"
              maxLength={6}
              className="w-full px-4 py-3 bg-[#1a1a1a] border border-red-500/30 rounded-lg text-white placeholder:text-gray-600 focus:outline-none focus:border-red-500 transition-colors font-mono text-2xl text-center tracking-widest"
              required
              autoFocus
            />

            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                <p className="text-red-400 text-sm text-center">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading || twoFa.length < 6}
              className="w-full py-3 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700 transition-all disabled:opacity-50"
            >
              {loading ? "Проверка..." : "Подтвердить"}
            </button>

            <button
              type="button"
              onClick={() => { setStep("credentials"); setError(""); setTwoFa(""); }}
              className="w-full py-2 text-gray-500 hover:text-gray-300 text-sm transition-colors"
            >
              ← Назад
            </button>
          </form>
        )}

        <p className="text-center text-gray-600 text-xs mt-6">
          Доступ только для администраторов
        </p>
      </div>
    </div>
  );
}
