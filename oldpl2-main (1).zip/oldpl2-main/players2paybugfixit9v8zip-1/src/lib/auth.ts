export const auth = {
  // Установка сессии после успешного входа
  setSession(sessionToken: string, role: string) {
    localStorage.setItem("sessionToken", sessionToken);
    localStorage.setItem("userRole", role);
  },

  // Получение сессионного токена
  getSessionToken(): string | null {
    return localStorage.getItem("sessionToken");
  },

  // Получение роли пользователя (L1, L2, L3, M)
  getUserRole(): string | null {
    return localStorage.getItem("userRole");
  },

  // Проверка, авторизован ли пользователь
  isLoggedIn(): boolean {
    return !!localStorage.getItem("sessionToken");
  },

  // Проверка конкретной роли
  isTrader(): boolean {
    return localStorage.getItem("userRole") === "L1";
  },

  isAdmin(): boolean {
    return localStorage.getItem("userRole") === "L2";
  },

  isOwner(): boolean {
    return localStorage.getItem("userRole") === "L3";
  },

  isMerchant(): boolean {
    return localStorage.getItem("userRole") === "M";
  },

  // Выход (удаление сессии)
  logout() {
    localStorage.removeItem("sessionToken");
    localStorage.removeItem("userRole");
    // Также удаляем старые токены для очистки
    localStorage.removeItem("traderId");
    localStorage.removeItem("traderName");
    localStorage.removeItem("traderToken");
    localStorage.removeItem("adminName");
    localStorage.removeItem("adminToken");
    localStorage.removeItem("merchantToken");
  },
};
