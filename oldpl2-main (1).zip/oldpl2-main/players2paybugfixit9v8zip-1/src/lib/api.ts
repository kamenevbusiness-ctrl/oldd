const BASE = "";

function getHeaders(): Record<string, string> {
  const sessionToken = localStorage.getItem("sessionToken");
  return {
    "Content-Type": "application/json",
    ...(sessionToken ? { "x-session-token": sessionToken } : {}),
  };
}

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: { ...getHeaders(), ...(options?.headers ?? {}) },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error ?? "Request failed");
  }
  return res.json() as Promise<T>;
}

export const api = {
  // Auth
  login: (login: string, password: string, token: string) =>
    request<{ sessionToken: string; role: string }>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ login, password, token }),
    }),

  verify2FA: (userId: number, code: string) =>
    request<{ sessionToken: string }>("/api/auth/verify-2fa", {
      method: "POST",
      body: JSON.stringify({ userId, code }),
    }),

  logout: () =>
    request("/api/auth/logout", { method: "POST" }),

  // Balance
  getBalance: () =>
    request<{ total: number; working: number; security: number }>("/api/balance"),

  withdraw: (amount: number, address: string) =>
    request("/api/withdraw", {
      method: "POST",
      body: JSON.stringify({ amount, address }),
    }),

  // Traffic
  getTrafficStatus: () =>
    request<{ enabled: boolean }>("/api/traffic/status"),

  toggleTraffic: (enabled: boolean) =>
    request("/api/traffic/toggle", {
      method: "POST",
      body: JSON.stringify({ enabled }),
    }),

  // Cards / Rekvizity
  getCards: () =>
    request<any[]>("/api/cards"),

  addCard: (card: Record<string, unknown>) =>
    request("/api/cards", {
      method: "POST",
      body: JSON.stringify(card),
    }),

  updateCard: (id: number, updates: Record<string, unknown>) =>
    request(`/api/cards/${id}`, {
      method: "PATCH",
      body: JSON.stringify(updates),
    }),

  deleteCard: (id: number) =>
    request(`/api/cards/${id}`, { method: "DELETE" }),

  // Orders
  getRecentOrders: () =>
    request<any[]>("/api/orders/recent"),

  getActiveOrders: () =>
    request<any[]>("/api/orders/active"),

  confirmOrder: (orderId: string) =>
    request(`/api/orders/${orderId}/confirm`, { method: "POST" }),

  rejectOrder: (orderId: string) =>
    request(`/api/orders/${orderId}/reject`, { method: "POST" }),

  // Disputes
  getDisputes: () =>
    request<any[]>("/api/disputes"),

  resolveDispute: (disputeId: number, inFavorOf: "trader" | "client") =>
    request("/api/disputes/resolve", {
      method: "POST",
      body: JSON.stringify({ disputeId, inFavorOf }),
    }),

  // Devices
  getDevices: () =>
    request<any[]>("/api/devices"),

  addDevice: (name: string, brand: string, model: string) =>
    request("/api/devices", {
      method: "POST",
      body: JSON.stringify({ name, brand, model }),
    }),

  deleteDevice: (id: string) =>
    request(`/api/devices/${id}`, { method: "DELETE" }),
};
