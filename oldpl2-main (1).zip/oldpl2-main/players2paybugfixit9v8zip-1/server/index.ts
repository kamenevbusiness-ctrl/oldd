import express from "express";
import cors from "cors";
import bcrypt from "bcrypt";
import speakeasy from "speakeasy";
import crypto from "crypto";
import { pool } from "./db";

const app = express();
app.use(cors());
app.use(express.json());

// ============================================
// ГЕНЕРАТОРЫ
// ============================================
function generateSessionToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

// ============================================
// MIDDLEWARE: ПРОВЕРКА СЕССИИ
// ============================================
async function requireAuth(req: any, res: any, next: any) {
  const sessionToken = req.headers["x-session-token"];
  if (!sessionToken) return res.status(401).json({ error: "Session required" });
  const sessionRes = await pool.query(
    `SELECT user_id, expires_at FROM user_sessions WHERE token = $1`,
    [sessionToken]
  );
  if (sessionRes.rows.length === 0) return res.status(401).json({ error: "Invalid session" });
  const session = sessionRes.rows[0];
  if (new Date() > session.expires_at) return res.status(401).json({ error: "Session expired" });
  const userRes = await pool.query(
    `SELECT id, login, role, is_active FROM users WHERE id = $1`,
    [session.user_id]
  );
  if (userRes.rows.length === 0) return res.status(401).json({ error: "User not found" });
  req.user = userRes.rows[0];
  if (!req.user.is_active) return res.status(403).json({ error: "Account blocked" });
  next();
}

// ============================================
// НОВАЯ АУТЕНТИФИКАЦИЯ
// ============================================
app.post("/api/auth/login", async (req, res) => {
  const { login, password, token } = req.body;
  if (!login || !password || !token) {
    return res.status(400).json({ error: "Login, password and token required" });
  }
  const userRes = await pool.query(
    `SELECT id, login, password_hash, role, two_factor_secret, is_active FROM users WHERE login = $1`,
    [login]
  );
  if (userRes.rows.length === 0) {
    return res.status(401).json({ error: "Invalid login, password or token" });
  }
  const user = userRes.rows[0];
  if (!user.is_active) return res.status(403).json({ error: "Account blocked" });
  const passwordValid = await bcrypt.compare(password, user.password_hash);
  if (!passwordValid) return res.status(401).json({ error: "Invalid login, password or token" });

  let tokenValid = false;
  if (user.role === 'L1' || user.role === 'L2' || user.role === 'L3') {
    tokenValid = user.token === token;
  } else if (user.role === 'M') {
    const merchantRes = await pool.query(`SELECT id FROM merchants WHERE api_key = $1`, [token]);
    tokenValid = merchantRes.rows.length > 0;
  }
  if (!tokenValid) return res.status(401).json({ error: "Invalid login, password or token" });

  if (user.two_factor_secret) {
    return res.json({ requiresTwoFactor: true, userId: user.id });
  }

  const sessionToken = generateSessionToken();
  const expiresAt = new Date();
  expiresAt.setHours(expiresAt.getHours() + 6);
  await pool.query(
    `INSERT INTO user_sessions (user_id, token, expires_at, ip, user_agent) VALUES ($1, $2, $3, $4, $5)`,
    [user.id, sessionToken, expiresAt, req.ip, req.headers["user-agent"]]
  );
  res.json({ sessionToken, role: user.role });
});

app.post("/api/auth/verify-2fa", async (req, res) => {
  const { userId, code } = req.body;
  if (!userId || !code) return res.status(400).json({ error: "User ID and 2FA code required" });
  const userRes = await pool.query(`SELECT two_factor_secret FROM users WHERE id = $1`, [userId]);
  if (userRes.rows.length === 0) return res.status(404).json({ error: "User not found" });
  const secret = userRes.rows[0].two_factor_secret;
  if (!secret) return res.status(400).json({ error: "2FA not enabled" });
  const verified = speakeasy.totp.verify({ secret, encoding: 'base32', token: code, window: 1 });
  if (!verified) return res.status(401).json({ error: "Invalid 2FA code" });
  const sessionToken = generateSessionToken();
  const expiresAt = new Date();
  expiresAt.setHours(expiresAt.getHours() + 6);
  await pool.query(
    `INSERT INTO user_sessions (user_id, token, expires_at, ip, user_agent) VALUES ($1, $2, $3, $4, $5)`,
    [userId, sessionToken, expiresAt, req.ip, req.headers["user-agent"]]
  );
  res.json({ sessionToken });
});

app.post("/api/auth/logout", async (req, res) => {
  const sessionToken = req.headers["x-session-token"];
  if (sessionToken) await pool.query(`DELETE FROM user_sessions WHERE token = $1`, [sessionToken]);
  res.json({ success: true });
});

// ============================================
// ТУМБЛЕР «ТРАФИК»
// ============================================
app.post("/api/traffic/toggle", requireAuth, async (req: any, res) => {
  const { enabled } = req.body;
  await pool.query(`UPDATE users SET traffic_enabled = $1 WHERE id = $2`, [enabled, req.user.id]);
  res.json({ success: true, enabled });
});

app.get("/api/traffic/status", requireAuth, async (req: any, res) => {
  const userRes = await pool.query(`SELECT traffic_enabled FROM users WHERE id = $1`, [req.user.id]);
  res.json({ enabled: userRes.rows[0]?.traffic_enabled || false });
});

// ============================================
// БАЛАНС И ВЫВОД
// ============================================
app.get("/api/balance", requireAuth, async (req: any, res) => {
  const userRes = await pool.query(`SELECT total_balance FROM users WHERE id = $1`, [req.user.id]);
  const total = parseFloat(userRes.rows[0].total_balance);
  const securityDeposit = 85000;
  const workingBalance = total - securityDeposit;
  res.json({ total, working: workingBalance, security: securityDeposit });
});

app.post("/api/withdraw", requireAuth, async (req: any, res) => {
  if (req.user.role !== 'L1') return res.status(403).json({ error: "Only traders can withdraw" });
  const { amount, address } = req.body;
  if (!amount || amount < 500) return res.status(400).json({ error: "Minimum 500 USDT" });
  if (!address) return res.status(400).json({ error: "Address required" });
  const userRes = await pool.query(`SELECT total_balance FROM users WHERE id = $1`, [req.user.id]);
  const total = parseFloat(userRes.rows[0].total_balance);
  const security = 85000;
  const working = total - security;
  const amountRub = amount * 85;
  if (working < amountRub) return res.status(400).json({ error: "Insufficient working balance" });
  await pool.query(`UPDATE users SET total_balance = total_balance - $1 WHERE id = $2`, [amountRub, req.user.id]);
  await pool.query(
    `INSERT INTO transactions (user_id, type, amount, currency, status, created_at) VALUES ($1, 'withdraw', $2, 'USDT', 'pending', NOW())`,
    [req.user.id, amount]
  );
  res.json({ success: true, newBalance: total - amountRub });
});

// ============================================
// КАРТЫ / РЕКВИЗИТЫ
// ============================================
app.get("/api/cards", requireAuth, async (req: any, res) => {
  if (req.user.role !== 'L1') return res.status(403).json({ error: "Only traders" });
  const cards = await pool.query(`SELECT * FROM cards WHERE user_id = $1 ORDER BY created_at DESC`, [req.user.id]);
  res.json(cards.rows);
});

app.post("/api/cards", requireAuth, async (req: any, res) => {
  if (req.user.role !== 'L1') return res.status(403).json({ error: "Only traders" });
  const { type, currency, details, bank, minAmount, maxAmount, dailyLimit, minuteLimit, intervalMin, intervalMax, scheduleEnabled, scheduleStart, scheduleEnd } = req.body;
  if (!type || !details) return res.status(400).json({ error: "Type and details required" });
  await pool.query(
    `INSERT INTO cards (user_id, type, currency, details, bank, min_amount, max_amount, daily_limit, minute_limit, interval_min, interval_max, schedule_enabled, schedule_start, schedule_end)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
    [req.user.id, type, currency || 'RUB', details, bank, minAmount, maxAmount, dailyLimit, minuteLimit, intervalMin, intervalMax, scheduleEnabled, scheduleStart, scheduleEnd]
  );
  res.status(201).json({ success: true });
});

app.patch("/api/cards/:id", requireAuth, async (req: any, res) => {
  if (req.user.role !== 'L1') return res.status(403).json({ error: "Only traders" });
  const { id } = req.params;
  const { minAmount, maxAmount, dailyLimit, minuteLimit, intervalMin, intervalMax, scheduleEnabled, scheduleStart, scheduleEnd, isActive } = req.body;
  await pool.query(
    `UPDATE cards SET min_amount=$1, max_amount=$2, daily_limit=$3, minute_limit=$4, interval_min=$5, interval_max=$6, schedule_enabled=$7, schedule_start=$8, schedule_end=$9, is_active=$10 WHERE id=$11 AND user_id=$12`,
    [minAmount, maxAmount, dailyLimit, minuteLimit, intervalMin, intervalMax, scheduleEnabled, scheduleStart, scheduleEnd, isActive, id, req.user.id]
  );
  res.json({ success: true });
});

app.delete("/api/cards/:id", requireAuth, async (req: any, res) => {
  if (req.user.role !== 'L1') return res.status(403).json({ error: "Only traders" });
  const { id } = req.params;
  const orders = await pool.query(`SELECT id FROM orders WHERE card_id = $1 AND status = 'pending'`, [id]);
  if (orders.rows.length > 0) return res.status(400).json({ error: "Cannot delete card with pending orders" });
  await pool.query(`DELETE FROM cards WHERE id=$1 AND user_id=$2`, [id, req.user.id]);
  res.json({ success: true });
});

// ============================================
// ОРДЕРЫ
// ============================================
app.get("/api/orders/recent", requireAuth, async (req: any, res) => {
  const orders = await pool.query(
    `SELECT o.id, o.order_id, o.amount, o.currency, o.status, c.name as method, o.created_at
     FROM orders o
     LEFT JOIN cards c ON o.card_id = c.id
     WHERE o.user_id = $1
     ORDER BY o.created_at DESC LIMIT 10`,
    [req.user.id]
  );
  res.json(orders.rows);
});

// ============================================
// УСТРОЙСТВА
// ============================================
app.get("/api/devices", requireAuth, async (req: any, res) => {
  const devices = await pool.query(
    `SELECT id, name, brand, model, last_active, is_online, battery, network FROM devices WHERE user_id = $1 ORDER BY created_at DESC`,
    [req.user.id]
  );
  res.json(devices.rows);
});

app.post("/api/devices", requireAuth, async (req: any, res) => {
  const { name, brand, model } = req.body;
  if (!name || !brand || !model) return res.status(400).json({ error: "Name, brand and model required" });
  const result = await pool.query(
    `INSERT INTO devices (user_id, name, brand, model, last_active, is_online) VALUES ($1, $2, $3, $4, NOW(), true) RETURNING *`,
    [req.user.id, name, brand, model]
  );
  res.status(201).json(result.rows[0]);
});

app.delete("/api/devices/:id", requireAuth, async (req: any, res) => {
  await pool.query(`DELETE FROM devices WHERE id=$1 AND user_id=$2`, [req.params.id, req.user.id]);
  res.json({ success: true });
});

// ============================================
// СПОРЫ
// ============================================
app.get("/api/disputes", requireAuth, async (req: any, res) => {
  const disputes = await pool.query(
    `SELECT d.id, d.order_id, d.amount, d.currency, d.card_last4, d.card_bank, d.customer_name, d.reason, d.status, d.time_left, d.created_at
     FROM disputes d
     WHERE d.user_id = $1
     ORDER BY d.created_at DESC`,
    [req.user.id]
  );
  res.json(disputes.rows);
});

app.post("/api/disputes/resolve", requireAuth, async (req: any, res) => {
  if (req.user.role !== 'L2' && req.user.role !== 'L3') return res.status(403).json({ error: "Only admins" });
  const { disputeId, inFavorOf } = req.body;
  const disputeRes = await pool.query(`SELECT order_id, user_id, amount FROM disputes WHERE id = $1`, [disputeId]);
  if (disputeRes.rows.length === 0) return res.status(404).json({ error: "Dispute not found" });
  const dispute = disputeRes.rows[0];
  if (inFavorOf === 'client') {
    await pool.query(`UPDATE users SET total_balance = total_balance - $1 WHERE id = $2`, [dispute.amount, dispute.user_id]);
  }
  await pool.query(
    `UPDATE disputes SET status = $1, resolved_by = $2, resolved_at = NOW() WHERE id = $3`,
    [inFavorOf === 'trader' ? 'resolved_trader' : 'resolved_client', req.user.role === 'L3' ? 'L3' : 'L2', disputeId]
  );
  res.json({ success: true });
});

// ============================================
// СТАРЫЕ РОУТЫ (ОБРАТНАЯ СОВМЕСТИМОСТЬ)
// ============================================
app.post("/api/auth/trader-login", async (req, res) => {
  const { token } = req.body;
  if (!token) return res.status(400).json({ error: "Token required" });
  const result = await pool.query("SELECT id, name, is_active FROM traders WHERE token = $1", [token]);
  if (result.rows.length === 0) return res.status(401).json({ error: "Invalid token" });
  const trader = result.rows[0];
  if (!trader.is_active) return res.status(403).json({ error: "Account is blocked" });
  return res.json({ traderId: trader.id, traderName: trader.name });
});

app.get("/api/traders/:id/active-orders", async (req, res) => {
  const traderId = parseInt(req.params.id);
  const result = await pool.query(
    `SELECT o.id, o.order_id, o.amount, o.customer_name, o.profit, o.profit_percent, o.status,
            COALESCE(RIGHT(c.card_number, 4), '0000') AS card_last4,
            COALESCE(c.bank_name, 'Unknown') AS card_bank
     FROM orders o
     LEFT JOIN cards c ON o.card_id = c.id
     WHERE o.trader_id = $1 AND o.status = 'pending'
     ORDER BY o.created_at DESC`,
    [traderId]
  );
  res.json(result.rows);
});

app.get("/api/traders/:id/stats", async (req, res) => {
  const traderId = parseInt(req.params.id);
  const result = await pool.query(
    `SELECT
       COALESCE(SUM(amount) FILTER (WHERE created_at >= CURRENT_DATE), 0) AS today_volume,
       COALESCE(SUM(profit) FILTER (WHERE created_at >= CURRENT_DATE), 0) AS today_profit,
       COALESCE(COUNT(*) FILTER (WHERE status = 'confirmed' AND created_at >= CURRENT_DATE), 0) AS today_count,
       (SELECT balance FROM traders WHERE id = $1) AS balance,
       (SELECT is_active FROM traders WHERE id = $1) AS is_active
     FROM orders
     WHERE trader_id = $1`,
    [traderId]
  );
  res.json(result.rows[0]);
});

app.get("/api/traders/:id/traffic-status", async (req, res) => {
  const traderId = parseInt(req.params.id);
  const result = await pool.query("SELECT is_active FROM traders WHERE id = $1", [traderId]);
  if (result.rows.length === 0) return res.status(404).json({ error: "Not found" });
  res.json({ enabled: result.rows[0].is_active });
});

app.post("/api/traders/:id/traffic-toggle", async (req, res) => {
  const traderId = parseInt(req.params.id);
  const { enabled } = req.body;
  await pool.query("UPDATE traders SET is_active = $1 WHERE id = $2", [enabled, traderId]);
  res.json({ enabled });
});

app.get("/api/traders/:id/cards", async (req, res) => {
  const traderId = parseInt(req.params.id);
  const result = await pool.query("SELECT * FROM cards WHERE trader_id = $1 ORDER BY created_at DESC", [traderId]);
  res.json(result.rows);
});

app.post("/api/traders/cards", async (req, res) => {
  const { traderId, cardNumber, holderName, bankName, minAmount, maxAmount, totalPaymentsLimit, paymentsPerMinute } = req.body;
  const result = await pool.query(
    `INSERT INTO cards (trader_id, card_number, holder_name, bank_name, min_amount, max_amount, total_payments_limit, payments_per_minute)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
    [traderId, cardNumber, holderName, bankName, minAmount, maxAmount, totalPaymentsLimit, paymentsPerMinute]
  );
  res.status(201).json(result.rows[0]);
});

app.delete("/api/traders/cards/:cardId", async (req, res) => {
  const cardId = parseInt(req.params.cardId);
  await pool.query("UPDATE cards SET is_active = false WHERE id = $1", [cardId]);
  res.json({ success: true });
});

app.get("/api/traders/:id/history", async (req, res) => {
  const traderId = parseInt(req.params.id);
  const result = await pool.query(
    `SELECT o.id, o.order_id, o.amount, o.customer_name, o.profit, o.profit_percent, o.status, o.created_at,
            COALESCE(RIGHT(c.card_number, 4), '0000') AS card_last4,
            COALESCE(c.bank_name, 'Unknown') AS card_bank
     FROM orders o
     LEFT JOIN cards c ON o.card_id = c.id
     WHERE o.trader_id = $1 AND o.status != 'pending'
     ORDER BY o.created_at DESC
     LIMIT 100`,
    [traderId]
  );
  res.json(result.rows);
});

async function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const token = req.headers["x-admin-token"] as string;
  if (!token) return res.status(401).json({ error: "Admin token required" });
  const result = await pool.query("SELECT id FROM admins WHERE token = $1", [token]);
  if (result.rows.length === 0) return res.status(403).json({ error: "Invalid admin token" });
  next();
}

app.post("/api/admin/login", async (req, res) => {
  const { token } = req.body;
  if (!token) return res.status(400).json({ error: "Token required" });
  const result = await pool.query("SELECT id, name FROM admins WHERE token = $1", [token]);
  if (result.rows.length === 0) return res.status(401).json({ error: "Invalid admin token" });
  res.json({ adminName: result.rows[0].name });
});

app.get("/api/admin/stats", requireAdmin, async (_req, res) => {
  const result = await pool.query(`
    SELECT
      (SELECT COUNT(*) FROM traders) AS total_traders,
      (SELECT COUNT(*) FROM traders WHERE is_active = true) AS active_traders,
      COALESCE(SUM(amount) FILTER (WHERE created_at >= CURRENT_DATE), 0) AS today_volume,
      COUNT(*) FILTER (WHERE created_at >= CURRENT_DATE) AS today_orders
    FROM orders
  `);
  res.json(result.rows[0]);
});

app.get("/api/admin/traders", requireAdmin, async (_req, res) => {
  const result = await pool.query(`
    SELECT
      t.id, t.name, t.token, t.is_active, t.profit_percent, t.balance, t.created_at,
      COUNT(o.id) AS order_count,
      COALESCE(SUM(o.amount) FILTER (WHERE o.created_at >= CURRENT_DATE), 0) AS today_volume
    FROM traders t
    LEFT JOIN orders o ON o.trader_id = t.id
    GROUP BY t.id
    ORDER BY t.created_at DESC
  `);
  res.json(result.rows);
});

app.post("/api/admin/traders", requireAdmin, async (req, res) => {
  const { name, profit_percent } = req.body;
  if (!name) return res.status(400).json({ error: "Name required" });
  const token = "tr_" + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
  const result = await pool.query(
    "INSERT INTO traders (name, token, profit_percent) VALUES ($1, $2, $3) RETURNING *",
    [name, token, profit_percent ?? 5]
  );
  res.status(201).json(result.rows[0]);
});

app.post("/api/admin/traders/:id/toggle", requireAdmin, async (req, res) => {
  const traderId = parseInt(req.params.id);
  const { is_active } = req.body;
  await pool.query("UPDATE traders SET is_active = $1 WHERE id = $2", [is_active, traderId]);
  res.json({ success: true });
});

app.get("/api/admin/orders", requireAdmin, async (_req, res) => {
  const result = await pool.query(`
    SELECT
      o.id, o.order_id, o.amount, o.customer_name, o.status, o.created_at,
      t.name AS trader_name,
      COALESCE(RIGHT(c.card_number, 4), '0000') AS card_last4,
      COALESCE(c.bank_name, 'Unknown') AS card_bank
    FROM orders o
    JOIN traders t ON o.trader_id = t.id
    LEFT JOIN cards c ON o.card_id = c.id
    WHERE o.status = 'pending'
    ORDER BY o.created_at DESC
  `);
  res.json(result.rows);
});

app.get("/api/health", (_req, res) => res.json({ ok: true }));

const PORT = 3001;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`API server running on port ${PORT}`);
});
