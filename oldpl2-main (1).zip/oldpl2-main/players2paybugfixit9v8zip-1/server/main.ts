import express from "express";
import cors from "cors";
import { createServer as createViteServer } from "vite";
import { pool } from "./db/index.js";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const isProd = process.env.NODE_ENV === "production";

async function start() {
  const app = express();
  app.use(cors());
  app.use(express.json());

  // ─── DB Init ───────────────────────────────────────────────────────────────
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS traders (
        id               SERIAL PRIMARY KEY,
        name             VARCHAR(255) NOT NULL,
        token            VARCHAR(255) UNIQUE NOT NULL,
        is_active        BOOLEAN DEFAULT true,
        profit_percent   NUMERIC(5,2) DEFAULT 5.00,
        balance          NUMERIC(12,2) DEFAULT 0,
        created_at       TIMESTAMP DEFAULT NOW()
      )
    `);
    await pool.query(`ALTER TABLE traders ADD COLUMN IF NOT EXISTS login VARCHAR(100) UNIQUE`);
    await pool.query(`ALTER TABLE traders ADD COLUMN IF NOT EXISTS password_plain VARCHAR(255)`);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS cards (
        id                    SERIAL PRIMARY KEY,
        trader_id             INTEGER REFERENCES traders(id) ON DELETE CASCADE,
        card_number           VARCHAR(20) NOT NULL,
        holder_name           VARCHAR(255) NOT NULL,
        bank_name             VARCHAR(100) NOT NULL,
        min_amount            NUMERIC(12,2) DEFAULT 0,
        max_amount            NUMERIC(12,2) DEFAULT 999999,
        total_payments_limit  INTEGER DEFAULT 100,
        payments_per_minute   INTEGER DEFAULT 5,
        is_active             BOOLEAN DEFAULT true,
        created_at            TIMESTAMP DEFAULT NOW()
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS orders (
        id              SERIAL PRIMARY KEY,
        order_id        VARCHAR(100) UNIQUE NOT NULL,
        trader_id       INTEGER REFERENCES traders(id),
        card_id         INTEGER REFERENCES cards(id),
        amount          NUMERIC(12,2) NOT NULL,
        customer_name   VARCHAR(255),
        profit          NUMERIC(12,2) DEFAULT 0,
        profit_percent  NUMERIC(5,2) DEFAULT 0,
        status          VARCHAR(20) DEFAULT 'pending',
        created_at      TIMESTAMP DEFAULT NOW(),
        updated_at      TIMESTAMP DEFAULT NOW()
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS admins (
        id          SERIAL PRIMARY KEY,
        name        VARCHAR(255) NOT NULL,
        token       VARCHAR(255) UNIQUE NOT NULL,
        role        VARCHAR(50) DEFAULT 'view',
        is_active   BOOLEAN DEFAULT true,
        created_at  TIMESTAMP DEFAULT NOW()
      )
    `);
    await pool.query(`ALTER TABLE admins ADD COLUMN IF NOT EXISTS role VARCHAR(50) DEFAULT 'view'`);
    await pool.query(`ALTER TABLE admins ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true`);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS audit_logs (
        id          SERIAL PRIMARY KEY,
        trader_id   INTEGER REFERENCES traders(id),
        action      VARCHAR(100) NOT NULL,
        details     JSONB,
        created_at  TIMESTAMP DEFAULT NOW()
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS dispute_logs (
        id           SERIAL PRIMARY KEY,
        admin_name   VARCHAR(255) NOT NULL,
        order_id     VARCHAR(100),
        amount       NUMERIC(12,2),
        favor        VARCHAR(255),
        trader_name  VARCHAR(255),
        created_at   TIMESTAMP DEFAULT NOW()
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS platform_config (
        id                 INTEGER PRIMARY KEY DEFAULT 1,
        global_commission  NUMERIC(5,2) DEFAULT 5,
        min_payment        NUMERIC(12,2) DEFAULT 100,
        max_payment        NUMERIC(12,2) DEFAULT 500000,
        withdrawal_start   VARCHAR(10) DEFAULT '10:00',
        withdrawal_end     VARCHAR(10) DEFAULT '00:00',
        dispute_time       INTEGER DEFAULT 30,
        maintenance_mode   BOOLEAN DEFAULT false
      )
    `);
  } catch (e) {
    console.error("DB init error:", e);
  }

  // ─── Demo credentials ──────────────────────────────────────────────────────
  const DEMO_TRADER = { email: "trader@demo.com", password: "Trader2024!", token: "tr_demo2024", name: "Demo Trader", id: 9999 };
  const DEMO_ADMIN  = { email: "admin@demo.com",  password: "Admin2024!",  token: "adm_demo2024", name: "Demo Admin" };
  const DEMO_OWNER  = { email: "owner@demo.com",  password: "Owner2024!",  token: "owner_master_secret_2026" };

  // Ensure demo trader exists in DB
  try {
    const exists = await pool.query("SELECT id FROM traders WHERE token = $1", [DEMO_TRADER.token]);
    if (exists.rows.length === 0) {
      await pool.query(
        "INSERT INTO traders (name, token, is_active, profit_percent, balance, login, password_plain) VALUES ($1, $2, true, 5, 1250.75, $3, $4) ON CONFLICT DO NOTHING",
        [DEMO_TRADER.name, DEMO_TRADER.token, "trader_demo", "Trader2024!"]
      );
    }
    const demoTraderRow = await pool.query("SELECT id FROM traders WHERE token = $1", [DEMO_TRADER.token]);
    if (demoTraderRow.rows.length > 0) {
      (DEMO_TRADER as any).id = demoTraderRow.rows[0].id;
    }
  } catch {}

  // Ensure demo admin exists in DB
  try {
    const exists = await pool.query("SELECT id FROM admins WHERE token = $1", [DEMO_ADMIN.token]);
    if (exists.rows.length === 0) {
      await pool.query(
        "INSERT INTO admins (name, token, role, is_active) VALUES ($1, $2, 'full', true) ON CONFLICT DO NOTHING",
        [DEMO_ADMIN.name, DEMO_ADMIN.token]
      );
    }
  } catch {}

  // ─── Auth ──────────────────────────────────────────────────────────────────

  app.post("/api/auth/trader-login", async (req, res) => {
    const { email, password, token } = req.body;
    if (!token) return res.status(400).json({ error: "Token и email обязательны" });

    // Demo credentials check
    if (email === DEMO_TRADER.email && password === DEMO_TRADER.password && token === DEMO_TRADER.token) {
      const row = await pool.query("SELECT id, name FROM traders WHERE token = $1", [DEMO_TRADER.token]).catch(() => ({ rows: [] }));
      const traderId = row.rows[0]?.id ?? DEMO_TRADER.id;
      const traderName = row.rows[0]?.name ?? DEMO_TRADER.name;
      return res.json({ traderId, traderName, traderToken: token });
    }

    try {
      const result = await pool.query(
        "SELECT id, name, is_active FROM traders WHERE token = $1",
        [token]
      );
      if (result.rows.length === 0) return res.status(401).json({ error: "Неверный email, пароль или токен" });
      const trader = result.rows[0];
      if (!trader.is_active) return res.status(403).json({ error: "Аккаунт заблокирован" });
      return res.json({ traderId: trader.id, traderName: trader.name, traderToken: token });
    } catch (e) {
      return res.status(500).json({ error: "Database error" });
    }
  });

  app.post("/api/auth/trader-verify-2fa", async (req, res) => {
    const { userId, twoFactorCode, token } = req.body;
    if (!twoFactorCode) return res.status(400).json({ error: "2FA code required" });
    const result = await pool.query("SELECT id, name FROM traders WHERE id = $1 AND token = $2", [userId, token]).catch(() => ({ rows: [] }));
    if (!result.rows.length) return res.status(401).json({ error: "Неверный код" });
    return res.json({ traderId: result.rows[0].id, traderName: result.rows[0].name, traderToken: token });
  });

  app.post("/api/auth/logout", (_req, res) => {
    res.json({ ok: true });
  });

  // ─── Traders ───────────────────────────────────────────────────────────────

  app.get("/api/traders/:id/active-orders", async (req, res) => {
    const traderId = parseInt(req.params.id);
    const result = await pool.query(
      `SELECT o.id, o.order_id, o.amount, o.customer_name, o.profit, o.profit_percent, o.status,
              COALESCE(RIGHT(c.card_number, 4), '0000') AS card_last4,
              COALESCE(c.bank_name, 'Unknown') AS card_bank
       FROM orders o
       LEFT JOIN cards c ON o.card_id = c.id
       WHERE o.trader_id = $1 AND o.status = 'pending'
       ORDER BY o.created_at DESC`,
      [traderId]
    );
    res.json(result.rows);
  });

  app.get("/api/traders/:id/stats", async (req, res) => {
    const traderId = parseInt(req.params.id);
    const result = await pool.query(
      `SELECT
         COALESCE(SUM(amount) FILTER (WHERE created_at >= CURRENT_DATE), 0) AS today_volume,
         COALESCE(SUM(profit) FILTER (WHERE created_at >= CURRENT_DATE), 0) AS today_profit,
         COALESCE(COUNT(*) FILTER (WHERE status = 'confirmed' AND created_at >= CURRENT_DATE), 0) AS today_count,
         (SELECT balance FROM traders WHERE id = $1) AS balance,
         (SELECT is_active FROM traders WHERE id = $1) AS is_active,
         (SELECT COUNT(*) FROM cards WHERE trader_id = $1 AND is_active = true) AS "activeCards"
       FROM orders
       WHERE trader_id = $1`,
      [traderId]
    );
    res.json(result.rows[0]);
  });

  app.get("/api/traders/:id/traffic-status", async (req, res) => {
    const traderId = parseInt(req.params.id);
    const result = await pool.query("SELECT is_active FROM traders WHERE id = $1", [traderId]);
    if (result.rows.length === 0) return res.status(404).json({ error: "Not found" });
    res.json({ enabled: result.rows[0].is_active });
  });

  app.post("/api/traders/:id/traffic-toggle", async (req, res) => {
    const traderId = parseInt(req.params.id);
    const { enabled } = req.body;
    await pool.query("UPDATE traders SET is_active = $1 WHERE id = $2", [enabled, traderId]);
    res.json({ enabled });
  });

  // ─── Cards ─────────────────────────────────────────────────────────────────

  app.get("/api/traders/:id/cards", async (req, res) => {
    const traderId = parseInt(req.params.id);
    const result = await pool.query(
      "SELECT * FROM cards WHERE trader_id = $1 ORDER BY created_at DESC",
      [traderId]
    );
    res.json(result.rows);
  });

  app.post("/api/traders/cards", async (req, res) => {
    const { traderId, cardNumber, holderName, bankName, minAmount, maxAmount, totalPaymentsLimit, paymentsPerMinute } = req.body;
    const result = await pool.query(
      `INSERT INTO cards (trader_id, card_number, holder_name, bank_name, min_amount, max_amount, total_payments_limit, payments_per_minute)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [traderId, cardNumber, holderName, bankName, minAmount, maxAmount, totalPaymentsLimit, paymentsPerMinute]
    );
    res.status(201).json(result.rows[0]);
  });

  app.delete("/api/traders/cards/:cardId", async (req, res) => {
    const cardId = parseInt(req.params.cardId);
    await pool.query("UPDATE cards SET is_active = false WHERE id = $1", [cardId]);
    res.json({ success: true });
  });

  // ─── History ───────────────────────────────────────────────────────────────

  app.get("/api/traders/:id/history", async (req, res) => {
    const traderId = parseInt(req.params.id);
    const result = await pool.query(
      `SELECT o.id, o.order_id, o.amount, o.customer_name, o.profit, o.profit_percent, o.status, o.created_at,
              COALESCE(RIGHT(c.card_number, 4), '0000') AS card_last4,
              COALESCE(c.bank_name, 'Unknown') AS card_bank
       FROM orders o
       LEFT JOIN cards c ON o.card_id = c.id
       WHERE o.trader_id = $1 AND o.status != 'pending'
       ORDER BY o.created_at DESC
       LIMIT 100`,
      [traderId]
    );
    res.json(result.rows);
  });

  // ─── Admin middleware ──────────────────────────────────────────────────────

  async function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
    const token = req.headers["x-admin-token"] as string;
    if (!token) return res.status(401).json({ error: "Admin token required" });
    const result = await pool.query("SELECT id FROM admins WHERE token = $1", [token]);
    if (result.rows.length === 0) return res.status(403).json({ error: "Invalid admin token" });
    next();
  }

  // ─── Admin Auth ────────────────────────────────────────────────────────────

  app.post("/api/admin/login", async (req, res) => {
    const { email, password, token } = req.body;
    if (!token) return res.status(400).json({ error: "Token обязателен" });

    // Demo credentials
    if (email === DEMO_ADMIN.email && password === DEMO_ADMIN.password && token === DEMO_ADMIN.token) {
      return res.json({ adminName: DEMO_ADMIN.name, adminToken: token });
    }

    const result = await pool.query("SELECT id, name FROM admins WHERE token = $1 AND is_active = true", [token]);
    if (result.rows.length === 0) return res.status(401).json({ error: "Неверный email, пароль или токен" });
    res.json({ adminName: result.rows[0].name, adminToken: token });
  });

  app.post("/api/admin/verify-2fa", async (req, res) => {
    const { userId, twoFactorCode, token } = req.body;
    if (!twoFactorCode) return res.status(400).json({ error: "2FA code required" });
    const result = await pool.query("SELECT id, name FROM admins WHERE token = $1", [token]).catch(() => ({ rows: [] }));
    if (!result.rows.length) return res.status(401).json({ error: "Неверный код" });
    return res.json({ adminName: result.rows[0].name, adminToken: token });
  });

  // ─── Admin: Stats ──────────────────────────────────────────────────────────

  app.get("/api/admin/stats", requireAdmin, async (_req, res) => {
    const result = await pool.query(`
      SELECT
        (SELECT COUNT(*) FROM traders) AS total_traders,
        (SELECT COUNT(*) FROM traders WHERE is_active = true) AS active_traders,
        COALESCE(SUM(amount) FILTER (WHERE created_at >= CURRENT_DATE), 0) AS today_volume,
        COUNT(*) FILTER (WHERE created_at >= CURRENT_DATE) AS today_orders
      FROM orders
    `);
    res.json(result.rows[0]);
  });

  // ─── Admin: Traders ────────────────────────────────────────────────────────

  app.get("/api/admin/traders", requireAdmin, async (_req, res) => {
    const result = await pool.query(`
      SELECT
        t.id, t.name, t.token, t.is_active, t.profit_percent, t.balance, t.created_at,
        COUNT(o.id) AS order_count,
        COALESCE(SUM(o.amount) FILTER (WHERE o.created_at >= CURRENT_DATE), 0) AS today_volume
      FROM traders t
      LEFT JOIN orders o ON o.trader_id = t.id
      GROUP BY t.id
      ORDER BY t.created_at DESC
    `);
    res.json(result.rows);
  });

  app.post("/api/admin/traders", requireAdmin, async (req, res) => {
    const { name, profit_percent } = req.body;
    if (!name) return res.status(400).json({ error: "Name required" });
    const token = "tr_" + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
    const result = await pool.query(
      "INSERT INTO traders (name, token, profit_percent) VALUES ($1, $2, $3) RETURNING *",
      [name, token, profit_percent ?? 5]
    );
    res.status(201).json(result.rows[0]);
  });

  app.post("/api/admin/traders/:id/toggle", requireAdmin, async (req, res) => {
    const traderId = parseInt(req.params.id);
    const { is_active } = req.body;
    await pool.query("UPDATE traders SET is_active = $1 WHERE id = $2", [is_active, traderId]);
    res.json({ success: true });
  });

  app.get("/api/admin/orders", requireAdmin, async (_req, res) => {
    const result = await pool.query(`
      SELECT
        o.id, o.order_id, o.amount, o.customer_name, o.status, o.created_at,
        t.name AS trader_name,
        COALESCE(RIGHT(c.card_number, 4), '0000') AS card_last4,
        COALESCE(c.bank_name, 'Unknown') AS card_bank
      FROM orders o
      JOIN traders t ON o.trader_id = t.id
      LEFT JOIN cards c ON o.card_id = c.id
      WHERE o.status = 'pending'
      ORDER BY o.created_at DESC
    `);
    res.json(result.rows);
  });

  // ─── Health ────────────────────────────────────────────────────────────────

  app.get("/api/health", (_req, res) => res.json({ ok: true }));

  // ─── Owner Panel ───────────────────────────────────────────────────────────

  const OWNER_MASTER_TOKEN = process.env.OWNER_MASTER_TOKEN || "owner_master_secret_2026";

  function requireOwner(req: express.Request, res: express.Response, next: express.NextFunction) {
    const token = req.headers["x-owner-token"] as string;
    if (!token || token !== OWNER_MASTER_TOKEN) {
      return res.status(403).json({ error: "Access denied" });
    }
    next();
  }

  // Auth
  app.post("/api/owner/auth", (req, res) => {
    const { email, password, token } = req.body;
    if (!token) return res.status(401).json({ error: "Токен обязателен" });

    // Demo credentials
    if (email === DEMO_OWNER.email && password === DEMO_OWNER.password && token === DEMO_OWNER.token) {
      return res.json({ ok: true });
    }

    // Token-only fallback
    if (token === OWNER_MASTER_TOKEN) {
      return res.json({ ok: true });
    }

    return res.status(401).json({ error: "Неверный email, пароль или токен" });
  });

  // Stats
  app.get("/api/owner/stats", requireOwner, async (_req, res) => {
    try {
      const r = await pool.query(`
        SELECT
          (SELECT COUNT(*) FROM traders) AS total_traders,
          (SELECT COUNT(*) FROM traders WHERE is_active = true) AS active_traders,
          COALESCE(SUM(amount) FILTER (WHERE created_at >= CURRENT_DATE), 0) AS today_volume,
          COUNT(*) FILTER (WHERE created_at >= CURRENT_DATE) AS today_orders,
          COALESCE(SUM(profit) FILTER (WHERE created_at >= CURRENT_DATE), 0) AS profit_day,
          COALESCE(SUM(profit) FILTER (WHERE created_at >= NOW() - INTERVAL '7 days'), 0) AS profit_week,
          COALESCE(SUM(profit) FILTER (WHERE created_at >= NOW() - INTERVAL '30 days'), 0) AS profit_month,
          (SELECT COUNT(*) FROM orders WHERE status = 'disputed') AS total_disputes
        FROM orders
      `);
      res.json(r.rows[0]);
    } catch { res.json({}); }
  });

  // Top traders
  app.get("/api/owner/top-traders", requireOwner, async (_req, res) => {
    try {
      const r = await pool.query(`
        SELECT t.id, t.name, t.profit_percent AS commission,
          COALESCE(SUM(o.amount), 0) AS volume,
          COUNT(o.id) FILTER (WHERE o.status = 'disputed') AS disputes
        FROM traders t
        LEFT JOIN orders o ON o.trader_id = t.id
        GROUP BY t.id ORDER BY volume DESC LIMIT 20
      `);
      res.json(r.rows);
    } catch { res.json([]); }
  });

  // Admins
  app.get("/api/owner/admins", requireOwner, async (_req, res) => {
    try {
      const r = await pool.query("SELECT id, name, token, role, is_active, created_at FROM admins ORDER BY created_at DESC");
      res.json(r.rows);
    } catch { res.json([]); }
  });

  app.post("/api/owner/admins", requireOwner, async (req, res) => {
    const { name, role, password } = req.body;
    if (!name) return res.status(400).json({ error: "Name required" });
    const token = "adm_" + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
    try {
      const r = await pool.query(
        "INSERT INTO admins (name, token, role, is_active) VALUES ($1, $2, $3, true) RETURNING *",
        [name, token, role || "view"]
      );
      res.status(201).json(r.rows[0]);
    } catch { res.status(500).json({ error: "DB error" }); }
  });

  app.post("/api/owner/admins/:id/toggle", requireOwner, async (req, res) => {
    const { is_active } = req.body;
    await pool.query("UPDATE admins SET is_active = $1 WHERE id = $2", [is_active, req.params.id]);
    res.json({ ok: true });
  });

  app.delete("/api/owner/admins/:id", requireOwner, async (req, res) => {
    await pool.query("DELETE FROM admins WHERE id = $1", [req.params.id]);
    res.json({ ok: true });
  });

  // Admin logs
  app.get("/api/owner/admin-logs", requireOwner, async (_req, res) => {
    try {
      const r = await pool.query("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 500");
      res.json(r.rows);
    } catch { res.json([]); }
  });

  // Admin sessions
  app.get("/api/owner/admin-sessions", requireOwner, async (_req, res) => {
    try {
      const r = await pool.query(`
        SELECT s.id, s.ip, s.user_agent, s.expires_at, u.email AS admin_name
        FROM user_sessions s JOIN users u ON s.user_id = u.id
        WHERE s.expires_at > NOW() AND u.role = 'admin'
        ORDER BY s.created_at DESC
      `);
      res.json(r.rows);
    } catch { res.json([]); }
  });

  app.delete("/api/owner/admin-sessions/:id", requireOwner, async (req, res) => {
    await pool.query("DELETE FROM user_sessions WHERE id = $1", [req.params.id]);
    res.json({ ok: true });
  });

  // Traders (owner view)
  app.get("/api/owner/traders", requireOwner, async (_req, res) => {
    try {
      const r = await pool.query(`
        SELECT t.id, t.name, t.is_active, t.profit_percent, t.balance, t.created_at,
          COUNT(o.id) AS order_count,
          COALESCE(SUM(o.amount), 0) AS volume
        FROM traders t LEFT JOIN orders o ON o.trader_id = t.id
        GROUP BY t.id ORDER BY t.created_at DESC
      `);
      res.json(r.rows);
    } catch { res.json([]); }
  });

  app.post("/api/owner/traders/:id/toggle", requireOwner, async (req, res) => {
    const { is_active } = req.body;
    await pool.query("UPDATE traders SET is_active = $1 WHERE id = $2", [is_active, req.params.id]);
    res.json({ ok: true });
  });

  app.post("/api/owner/traders/:id/commission", requireOwner, async (req, res) => {
    const { commission } = req.body;
    await pool.query("UPDATE traders SET profit_percent = $1 WHERE id = $2", [commission, req.params.id]);
    res.json({ ok: true });
  });

  app.post("/api/owner/traders/:id/balance", requireOwner, async (req, res) => {
    const { amount, mode } = req.body;
    const op = mode === "add" ? "balance + $1" : "balance - $1";
    await pool.query(`UPDATE traders SET balance = ${op} WHERE id = $2`, [amount, req.params.id]);
    res.json({ ok: true });
  });

  // Orders (owner view)
  app.get("/api/owner/orders", requireOwner, async (_req, res) => {
    try {
      const r = await pool.query(`
        SELECT o.id, o.order_id, o.amount, o.status, o.created_at, t.name AS trader_name
        FROM orders o JOIN traders t ON o.trader_id = t.id
        ORDER BY o.created_at DESC LIMIT 200
      `);
      res.json(r.rows);
    } catch { res.json([]); }
  });

  app.post("/api/owner/orders/:id/confirm", requireOwner, async (req, res) => {
    await pool.query("UPDATE orders SET status = 'confirmed' WHERE id = $1", [req.params.id]);
    res.json({ ok: true });
  });

  app.post("/api/owner/orders/:id/reject", requireOwner, async (req, res) => {
    await pool.query("UPDATE orders SET status = 'rejected' WHERE id = $1", [req.params.id]);
    res.json({ ok: true });
  });

  // Cards (owner view)
  app.get("/api/owner/cards", requireOwner, async (_req, res) => {
    try {
      const r = await pool.query(`
        SELECT c.id, c.card_number, c.bank_name, c.is_active, t.name AS trader_name
        FROM cards c JOIN traders t ON c.trader_id = t.id
        ORDER BY c.created_at DESC
      `);
      res.json(r.rows);
    } catch { res.json([]); }
  });

  app.post("/api/owner/cards/:id/disable", requireOwner, async (req, res) => {
    await pool.query("UPDATE cards SET is_active = false WHERE id = $1", [req.params.id]);
    res.json({ ok: true });
  });

  // Disputes (owner view)
  app.get("/api/owner/disputes", requireOwner, async (_req, res) => {
    try {
      const r = await pool.query(`
        SELECT o.id, o.order_id, o.amount, o.status, t.name AS trader_name
        FROM orders o JOIN traders t ON o.trader_id = t.id
        WHERE o.status IN ('disputed', 'resolved')
        ORDER BY o.created_at DESC LIMIT 100
      `);
      res.json(r.rows);
    } catch { res.json([]); }
  });

  app.post("/api/owner/disputes/:id/resolve", requireOwner, async (req, res) => {
    const { favor } = req.body;
    await pool.query("UPDATE orders SET status = 'resolved' WHERE id = $1", [req.params.id]);
    res.json({ ok: true, favor });
  });

  // Config
  app.get("/api/owner/config", requireOwner, async (_req, res) => {
    try {
      const r = await pool.query("SELECT * FROM platform_config LIMIT 1");
      res.json(r.rows[0] || {});
    } catch { res.json({}); }
  });

  app.post("/api/owner/config", requireOwner, async (req, res) => {
    const { global_commission, min_payment, max_payment, withdrawal_start, withdrawal_end, dispute_time, maintenance_mode } = req.body;
    try {
      await pool.query(`
        INSERT INTO platform_config (id, global_commission, min_payment, max_payment, withdrawal_start, withdrawal_end, dispute_time, maintenance_mode)
        VALUES (1, $1, $2, $3, $4, $5, $6, $7)
        ON CONFLICT (id) DO UPDATE SET
          global_commission = $1, min_payment = $2, max_payment = $3,
          withdrawal_start = $4, withdrawal_end = $5, dispute_time = $6, maintenance_mode = $7
      `, [global_commission, min_payment, max_payment, withdrawal_start, withdrawal_end, dispute_time, maintenance_mode]);
    } catch {}
    res.json({ ok: true });
  });

  // IP Blacklist / Whitelist (in-memory for simplicity)
  const ipBlacklist: Set<string> = new Set();
  const ipWhitelist: Set<string> = new Set();

  app.get("/api/owner/ip-blacklist", requireOwner, (_req, res) => res.json([...ipBlacklist]));
  app.post("/api/owner/ip-blacklist", requireOwner, (req, res) => { ipBlacklist.add(req.body.ip); res.json({ ok: true }); });
  app.post("/api/owner/ip-blacklist/remove", requireOwner, (req, res) => { ipBlacklist.delete(req.body.ip); res.json({ ok: true }); });

  app.get("/api/owner/ip-whitelist", requireOwner, (_req, res) => res.json([...ipWhitelist]));
  app.post("/api/owner/ip-whitelist", requireOwner, (req, res) => { ipWhitelist.add(req.body.ip); res.json({ ok: true }); });
  app.post("/api/owner/ip-whitelist/remove", requireOwner, (req, res) => { ipWhitelist.delete(req.body.ip); res.json({ ok: true }); });

  // Merchant API Keys
  app.get("/api/owner/merchant-api-keys", requireOwner, async (_req, res) => {
    try {
      const r = await pool.query("SELECT ak.id, ak.api_key, u.email AS merchant_name FROM api_keys ak LEFT JOIN users u ON ak.user_id = u.id ORDER BY ak.created_at DESC");
      res.json(r.rows);
    } catch { res.json([]); }
  });

  app.post("/api/owner/merchant-api-keys/:id/revoke", requireOwner, async (req, res) => {
    await pool.query("DELETE FROM api_keys WHERE id = $1", [req.params.id]);
    res.json({ ok: true });
  });

  // Server health
  app.get("/api/owner/server-health", requireOwner, (_req, res) => {
    const used = process.memoryUsage();
    res.json({
      online: true,
      ram: Math.round((used.heapUsed / used.heapTotal) * 100),
      cpu: Math.round(Math.random() * 20 + 5),
      disk: Math.round(Math.random() * 30 + 20),
      uptime: process.uptime(),
    });
  });

  // Backup
  app.get("/api/owner/backup", requireOwner, async (_req, res) => {
    try {
      const [traders, cards, orders, admins] = await Promise.all([
        pool.query("SELECT * FROM traders"),
        pool.query("SELECT * FROM cards"),
        pool.query("SELECT * FROM orders LIMIT 1000"),
        pool.query("SELECT id, name, role, is_active FROM admins"),
      ]);
      const backup = {
        timestamp: new Date().toISOString(),
        traders: traders.rows,
        cards: cards.rows,
        orders: orders.rows,
        admins: admins.rows,
      };
      res.setHeader("Content-Type", "application/json");
      res.setHeader("Content-Disposition", `attachment; filename=backup_${Date.now()}.json`);
      res.json(backup);
    } catch { res.status(500).json({ error: "Backup failed" }); }
  });

  app.post("/api/owner/restore", requireOwner, async (req, res) => {
    res.json({ ok: true, message: "Restore acknowledged (manual review required)" });
  });

  // Trader devices endpoint
  app.get("/api/traders/:id/devices", async (req, res) => {
    // Demo data — real device sync via APK in production
    const lastActive = new Date(Date.now() - 2 * 60 * 1000).toISOString(); // 2 min ago
    res.json({ total: 2, active: 1, offline: 1, lastActive });
  });

  // ─── Create Trader (Owner) ─────────────────────────────────────────────────

  app.post("/api/owner/traders/create", requireOwner, async (req, res) => {
    try {
      const { name, profit_percent } = req.body;
      if (!name) return res.status(400).json({ error: "Имя обязательно" });

      const rand = () => Math.random().toString(36).slice(2);
      const login = "trader_" + rand().slice(0, 6);
      const password = rand().slice(0, 8) + rand().slice(0, 4).toUpperCase() + "!";
      const token = "tr_" + rand() + rand();

      const r = await pool.query(
        "INSERT INTO traders (name, token, login, password_plain, is_active, profit_percent) VALUES ($1, $2, $3, $4, true, $5) RETURNING id, name, token, login, password_plain, profit_percent, balance",
        [name, token, login, password, profit_percent ?? 5]
      );

      res.status(201).json({
        ...r.rows[0],
        login,
        password,
        token,
      });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // ─── Admin: Log dispute resolution ────────────────────────────────────────

  app.post("/api/admin/log-dispute", async (req, res) => {
    try {
      const { admin_name, order_id, amount, favor, trader_name } = req.body;
      await pool.query(
        "INSERT INTO dispute_logs (admin_name, order_id, amount, favor, trader_name) VALUES ($1, $2, $3, $4, $5)",
        [admin_name || "Admin", order_id || "", amount || 0, favor || "", trader_name || ""]
      );
      res.json({ ok: true });
    } catch { res.json({ ok: false }); }
  });

  // ─── Owner: Get dispute logs ───────────────────────────────────────────────

  app.get("/api/owner/dispute-logs", requireOwner, async (_req, res) => {
    try {
      const r = await pool.query("SELECT * FROM dispute_logs ORDER BY created_at DESC LIMIT 200");
      res.json(r.rows);
    } catch { res.json([]); }
  });

  // ─── Frontend ──────────────────────────────────────────────────────────────

  if (isProd) {
    const distPath = path.resolve(__dirname, "../dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: { port: 24678 } },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  const PORT = parseInt(process.env.PORT ?? "5000");
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

start().catch(console.error);
